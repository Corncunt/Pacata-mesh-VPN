#!/usr/bin/env python3
"""
Test script for Pacata Mesh VPN cryptography functions.

This script tests the core cryptographic functions:
- generate_keys(): Generate cryptographic keys
- encrypt_traffic(): Encrypt data using a key
- decrypt_traffic(): Decrypt encrypted data using a key
"""

import sys
import os
import json
import unittest
from typing import Dict, Any

# Add the src directory to the Python path
sys.path.insert(0, os.path.abspath('src'))

# Import the cryptographic functions from pacata_mesh_vpn
try:
    from pacata_mesh_vpn.cryptography import generate_keys, encrypt_traffic, decrypt_traffic
except ImportError as e:
    print(f"Error importing cryptography functions: {e}")
    print("Make sure you're running this script from the project root directory.")
    sys.exit(1)


class CryptographyTest(unittest.TestCase):
    """Test cases for the cryptography functions."""

    def test_generate_keys(self):
        """Test the generate_keys function to ensure it returns valid keys."""
        print("\n--- Testing generate_keys() ---")
        
        # Generate keys
        keys = generate_keys()
        print(f"Generated keys: {json.dumps(keys, indent=2)}")
        
        # Verify the keys dictionary contains expected fields
        self.assertIsInstance(keys, dict, "generate_keys should return a dictionary")
        self.assertIn('private_key', keys, "Keys should include a private_key")
        self.assertIn('encryption_key', keys, "Keys should include an encryption_key")
        
        # Verify the encryption key is a valid hex string of appropriate length (32 bytes = 64 hex chars)
        self.assertIsInstance(keys['encryption_key'], str, "Encryption key should be a string")
        self.assertTrue(all(c in '0123456789abcdef' for c in keys['encryption_key'].lower()), 
                      "Encryption key should be a hex string")
        self.assertGreaterEqual(len(keys['encryption_key']), 32, 
                             "Encryption key should be at least 32 bytes (64 hex chars)")
        
        print("✓ generate_keys() test passed")
        return keys

    def test_encrypt_decrypt_string(self):
        """Test encryption and decryption of a string."""
        print("\n--- Testing encrypt_traffic() and decrypt_traffic() with string data ---")
        
        # Generate keys for testing
        keys = generate_keys()
        encryption_key = keys['encryption_key']
        
        # Test data
        original_data = "This is a secret message for testing encryption and decryption."
        print(f"Original data: {original_data}")
        
        # Encrypt the data
        encrypted_data = encrypt_traffic(original_data, encryption_key)
        print(f"Encrypted data: {encrypted_data}")
        
        # Verify encrypted data is not the same as the original
        self.assertNotEqual(encrypted_data, original_data, 
                         "Encrypted data should differ from original data")
        
        # Decrypt the data
        decrypted_data = decrypt_traffic(encrypted_data, encryption_key)
        print(f"Decrypted data: {decrypted_data}")
        
        # Verify the decrypted data matches the original
        self.assertEqual(decrypted_data, original_data, 
                      "Decrypted data should match the original data")
        
        print("✓ String encryption/decryption test passed")

    def test_encrypt_decrypt_dict(self):
        """Test encryption and decryption of a dictionary."""
        print("\n--- Testing encrypt_traffic() and decrypt_traffic() with dictionary data ---")
        
        # Generate keys for testing
        keys = generate_keys()
        encryption_key = keys['encryption_key']
        
        # Test data
        original_data = {
            "user_id": 12345,
            "username": "secure_user",
            "roles": ["admin", "user"],
            "metadata": {
                "last_login": "2023-06-15T14:30:00Z",
                "ip_address": "192.168.1.1"
            }
        }
        print(f"Original data: {json.dumps(original_data, indent=2)}")
        
        # Encrypt the data
        encrypted_data = encrypt_traffic(original_data, encryption_key)
        print(f"Encrypted data: {encrypted_data}")
        
        # Verify encrypted data is a string and not the original data
        self.assertIsInstance(encrypted_data, str, 
                           "Encrypted data should be a string")
        self.assertNotEqual(encrypted_data, original_data, 
                         "Encrypted data should differ from original data")
        
        # Decrypt the data
        decrypted_data = decrypt_traffic(encrypted_data, encryption_key)
        print(f"Decrypted data: {json.dumps(decrypted_data, indent=2)}")
        
        # Verify the decrypted data matches the original
        self.assertEqual(decrypted_data, original_data, 
                      "Decrypted data should match the original data")
        
        print("✓ Dictionary encryption/decryption test passed")

    def test_wrong_key_fails(self):
        """Test that decryption with wrong key fails."""
        print("\n--- Testing decryption with wrong key ---")
        
        # Generate keys for testing
        keys1 = generate_keys()
        keys2 = generate_keys()
        
        # Ensure we have different keys
        self.assertNotEqual(keys1['encryption_key'], keys2['encryption_key'], 
                         "Two calls to generate_keys should produce different keys")
        
        # Test data
        original_data = "This is a secret message."
        print(f"Original data: {original_data}")
        
        # Encrypt with first key
        encrypted_data = encrypt_traffic(original_data, keys1['encryption_key'])
        print(f"Encrypted data (using key1): {encrypted_data}")
        
        # Try to decrypt with wrong key
        try:
            decrypted_data = decrypt_traffic(encrypted_data, keys2['encryption_key'])
            self.assertNotEqual(decrypted_data, original_data, 
                             "Decryption with wrong key should not produce the original data")
            print(f"Decrypted with wrong key: {decrypted_data}")
        except Exception as e:
            print(f"Expected error when decrypting with wrong key: {e}")
            
        # Verify correct decryption works
        decrypted_data = decrypt_traffic(encrypted_data, keys1['encryption_key'])
        self.assertEqual(decrypted_data, original_data, 
                      "Decryption with correct key should work")
        
        print("✓ Wrong key test passed")


def run_tests():
    """Run all tests."""
    # Create and run the test suite
    suite = unittest.TestSuite()
    suite.addTest(CryptographyTest('test_generate_keys'))
    suite.addTest(CryptographyTest('test_encrypt_decrypt_string'))
    suite.addTest(CryptographyTest('test_encrypt_decrypt_dict'))
    suite.addTest(CryptographyTest('test_wrong_key_fails'))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Return success/failure
    return result.wasSuccessful()


if __name__ == "__main__":
    print("==================================================")
    print("  PACATA MESH VPN CRYPTOGRAPHY FUNCTIONS TEST")
    print("==================================================")
    
    try:
        success = run_tests()
        if success:
            print("\nAll tests PASSED! The cryptography functions are working correctly.")
            sys.exit(0)
        else:
            print("\nSome tests FAILED! Please check the errors above.")
            sys.exit(1)
    except Exception as e:
        print(f"\nError running tests: {e}")
        sys.exit(1)

