#!/bin/bash
set -e

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Running Pacata Mesh VPN Test Suite...${NC}"

# Create directories for reports if they don't exist
mkdir -p reports/coverage
mkdir -p reports/test_results

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check if pytest is installed
if ! command_exists pytest; then
    echo -e "${RED}Error: pytest is not installed. Please install it with:${NC}"
    echo "pip install pytest pytest-cov pytest-html"
    exit 1
fi

# Display test summary
echo -e "${YELLOW}Running unit and integration tests...${NC}"

# Run tests with coverage and generate reports
pytest tests/ \
    --cov=src \
    --cov-report=term \
    --cov-report=html:reports/coverage \
    --html=reports/test_results/report.html \
    -v

test_exit_code=$?

# Display results
if [ $test_exit_code -eq 0 ]; then
    echo -e "\n${GREEN}All tests passed!${NC}"
else
    echo -e "\n${RED}Some tests failed!${NC}"
fi

echo -e "\n${YELLOW}Test reports:${NC}"
echo -e "  - HTML coverage report: ${GREEN}reports/coverage/index.html${NC}"
echo -e "  - HTML test report: ${GREEN}reports/test_results/report.html${NC}"

# Run security checks if available
if command_exists bandit; then
    echo -e "\n${YELLOW}Running security checks...${NC}"
    bandit -r src/ -f html -o reports/security_report.html
    echo -e "  - Security report: ${GREEN}reports/security_report.html${NC}"
else
    echo -e "\n${YELLOW}Security checker 'bandit' not found. Install with:${NC}"
    echo "pip install bandit"
fi

echo -e "\n${YELLOW}Testing complete!${NC}"

# Return the test exit code
exit $test_exit_code

