"""
Distributed Hash Table (DHT) implementation for peer discovery in Pacata Mesh VPN.

This module provides a simplified implementation of a Kademlia-inspired DHT for
distributed peer discovery. It includes the core functionality needed for nodes
to announce their presence and discover other nodes in the network without
relying on a central server.
"""

import asyncio
import hashlib
import json
import logging
import random
import socket
import struct
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple, Union

logger = logging.getLogger(__name__)

# Constants
K = 20  # Size of k-buckets
ALPHA = 3  # Number of parallel lookups
ID_BITS = 160  # Size of node IDs in bits (SHA-1 hash)
HASH_SIZE = ID_BITS // 8  # Size of node IDs in bytes
REFRESH_INTERVAL = 3600  # Bucket refresh interval in seconds
REPLICATE_INTERVAL = 3600  # Key-value replication interval
REPUBLISH_INTERVAL = 86400  # Key republish interval

def generate_node_id(seed: Optional[str] = None) -> bytes:
    """Generate a random node ID or derive it from a seed."""
    if seed:
        return hashlib.sha1(seed.encode()).digest()
    return hashlib.sha1(str(random.getrandbits(ID_BITS)).encode()).digest()

def calculate_distance(id1: bytes, id2: bytes) -> int:
    """Calculate the XOR distance between two node IDs."""
    return int.from_bytes(bytes(a ^ b for a, b in zip(id1, id2)), 'big')

@dataclass
class Node:
    """Represents a node in the DHT network."""
    id: bytes
    ip: str
    port: int
    last_seen: float = 0.0
    
    def __init__(self, id: bytes, ip: str, port: int):
        self.id = id
        self.ip = ip
        self.port = port
        self.last_seen = time.time()
    
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Node):
            return False
        return self.id == other.id
    
    def __hash__(self) -> int:
        return hash(self.id)
    
    def distance_to(self, other_id: bytes) -> int:
        """Calculate the distance from this node to the specified ID."""
        return calculate_distance(self.id, other_id)
    
    def refresh(self) -> None:
        """Update the last seen timestamp for this node."""
        self.last_seen = time.time()
    
    def is_active(self, max_age: int = 86400) -> bool:
        """Check if the node has been seen recently."""
        return (time.time() - self.last_seen) < max_age
    
    def to_dict(self) -> Dict:
        """Convert node to a dictionary for serialization."""
        return {
            'id': self.id.hex(),
            'ip': self.ip,
            'port': self.port,
            'last_seen': self.last_seen
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Node':
        """Create a node from a dictionary."""
        node = cls(
            bytes.fromhex(data['id']),
            data['ip'],
            data['port']
        )
        node.last_seen = data.get('last_seen', time.time())
        return node


class KBucket:
    """A k-bucket stores up to k nodes that share a region of the ID space."""
    
    def __init__(self, min_range: int, max_range: int, max_size: int = K):
        self.min_range = min_range
        self.max_range = max_range
        self.max_size = max_size
        self.nodes: List[Node] = []
        self.last_updated = time.time()
    
    def __len__(self) -> int:
        return len(self.nodes)
    
    def get_nodes(self) -> List[Node]:
        """Get all active nodes in the bucket."""
        return [node for node in self.nodes if node.is_active()]
    
    def add_node(self, node: Node) -> bool:
        """
        Add a node to the bucket if there is space or if it's already in the bucket.
        Returns True if the node was added/updated.
        """
        # Don't add nodes with IDs outside the bucket's range
        node_int = int.from_bytes(node.id, 'big')
        if node_int < self.min_range or node_int >= self.max_range:
            return False
        
        # If the node is already in the bucket, move it to the end (most recently seen)
        for i, existing_node in enumerate(self.nodes):
            if existing_node == node:
                self.nodes.pop(i)
                self.nodes.append(node)
                node.refresh()
                self.last_updated = time.time()
                return True
        
        # If the bucket is not full, add the node
        if len(self.nodes) < self.max_size:
            self.nodes.append(node)
            self.last_updated = time.time()
            return True
        
        # Bucket is full - in a real implementation, we would ping the least-recently
        # seen node and replace it if it doesn't respond
        return False
    
    def remove_node(self, node_id: bytes) -> bool:
        """Remove a node from the bucket. Returns True if removed."""
        for i, node in enumerate(self.nodes):
            if node.id == node_id:
                self.nodes.pop(i)
                self.last_updated = time.time()
                return True
        return False
    
    def needs_refresh(self, max_age: int = REFRESH_INTERVAL) -> bool:
        """Check if the bucket needs to be refreshed."""
        return (time.time() - self.last_updated) > max_age
    
    def split(self) -> Tuple['KBucket', 'KBucket']:
        """Split the bucket into two equal halves."""
        middle = (self.min_range + self.max_range) // 2
        lower = KBucket(self.min_range, middle, self.max_size)
        upper = KBucket(middle, self.max_range, self.max_size)
        
        # Redistribute nodes between the two new buckets
        for node in self.nodes:
            node_int = int.from_bytes(node.id, 'big')
            if node_int < middle:
                lower.add_node(node)
            else:
                upper.add_node(node)
        
        return lower, upper


class DHTStorage:
    """Storage for key-value pairs in the DHT."""
    
    def __init__(self, max_age: int = 86400):
        self.data: Dict[bytes, Tuple[bytes, float]] = {}
        self.max_age = max_age
    
    def __len__(self) -> int:
        self._expire_old_data()
        return len(self.data)
    
    def _expire_old_data(self) -> None:
        """Remove expired data."""
        now = time.time()
        expired_keys = [k for k, (_, timestamp) in self.data.items() 
                        if now - timestamp > self.max_age]
        for key in expired_keys:
            del self.data[key]
    
    def get(self, key: bytes) -> Optional[bytes]:
        """Get a value for the given key, or None if not found."""
        self._expire_old_data()
        if key in self.data:
            value, _ = self.data[key]
            return value
        return None
    
    def set(self, key: bytes, value: bytes) -> None:
        """Store a key-value pair."""
        self.data[key] = (value, time.time())
    
    def delete(self, key: bytes) -> bool:
        """Delete a key-value pair. Returns True if deleted."""
        if key in self.data:
            del self.data[key]
            return True
        return False
    
    def get_keys(self) -> List[bytes]:
        """Get all keys in storage."""
        self._expire_old_data()
        return list(self.data.keys())


class DistributedHashTable:
    """
    A simplified implementation of a Kademlia-inspired DHT for peer discovery.
    
    This class provides the core functionality needed for nodes to announce
    their presence and discover other nodes in the network.
    """
    
    def __init__(self, ip: str, port: int, node_id: Optional[bytes] = None, 
                 bootstrap_nodes: Optional[List[Tuple[str, int]]] = None):
        """
        Initialize the DHT node.
        
        Args:
            ip: Local IP address to bind to
            port: Local port to bind to
            node_id: Optional node ID, generated randomly if not provided
            bootstrap_nodes: Optional list of (ip, port) tuples for initial connection
        """
        self.ip = ip
        self.port = port
        self.node_id = node_id if node_id else generate_node_id()
        self.node = Node(self.node_id, ip, port)
        
        # Initialize routing table with a single k-bucket
        self.buckets: List[KBucket] = [KBucket(0, 2**ID_BITS, K)]
        
        # Storage for key-value pairs
        self.storage = DHTStorage()
        
        # Set of nodes we've seen recently
        self.seen_nodes: Set[Node] = set()
        
        # Pending requests and responses
        self.pending_requests: Dict[bytes, asyncio.Future] = {}
        
        # Server socket
        self.socket: Optional[socket.socket] = None
        self.running = False
        
        # Bootstrap nodes to connect to
        self.bootstrap_nodes = bootstrap_nodes or []
    
    async def start(self) -> None:
        """Start the DHT node."""
        if self.running:
            return
        
        # Create and bind socket
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind((self.ip, self.port))
        self.socket.setblocking(False)
        
        self.running = True
        logger.info(f"DHT node started with ID {self.node_id.hex()} at {self.ip}:{self.port}")
        
        # Start message handling loop
        asyncio.create_task(self._message_loop())
        
        # Connect to bootstrap nodes if provided
        if self.bootstrap_nodes:
            for ip, port in self.bootstrap_nodes:
                await self.ping_node(ip, port)
    
    async def stop(self) -> None:
        """Stop the DHT node."""
        if not self.running:
            return
        
        self.running = False
        if self.socket:
            self.socket.close()
            self.socket = None
        
        logger.info(f"DHT node stopped: {self.ip}:{self.port}")
    
    async def _message_loop(self) -> None:
        """Main loop for handling incoming messages."""
        while self.running and self.socket:
            try:
                # Wait for data using asyncio
                data, addr = await asyncio.get_event_loop().sock_recvfrom(self.socket, 65536)
                
                # Process the message
                response = await self._handle_message(data, addr)
                
                # Send response if needed
                if response:
                    await asyncio.get_event_loop().sock_sendto(self.socket, response, addr)
            
            except Exception as e:
                logger.error(f"Error in message loop: {e}")
                await asyncio.sleep(0.1)
    
    async def _handle_message(self, data: bytes, addr: Tuple[str, int]) -> Optional[bytes]:
        """
        Process an incoming message and return a response if needed.
        
        This is a simplified message handler that assumes messages are in JSON format.
        """
        try:
            message = json.loads(data.decode())
            message_type = message.get('type')
            
            if 'sender' in message:
                # Update our routing table with the sender info
                sender_id = bytes.fromhex(message['sender']['id'])
                sender_ip = message['sender']['ip']
                sender_port = message['sender']['port']
                sender_node = Node(sender_id, sender_ip, sender_port)
                self._add_node_to_routing_table(sender_node)
            
            # Handle different message types
            if message_type == 'ping':
                return self._create_pong_response(message)
            
            elif message_type == 'pong':
                self._handle_pong_response(message)
                return None
            
            elif message_type == 'find_node':
                return self._handle_find_node(message)
            
            elif message_type == 'find_node_response':
                self._handle_find_node_response(message)
                return None
            
            elif message_type == 'store':
                return self._handle_store(message)
            
            elif message_type == 'find_value':
                return self._handle_find_value(message)
            
            elif message_type == 'find_value_response':
                self._handle_find_value_response(message)
                return None
            
            else:
                logger.warning(f"Unknown message type: {message_type}")
                return None
        
        except Exception as e:
            logger.error(f"Error handling message: {e}")
            return None
    
    def _create_pong_response(self, ping_message: Dict) -> bytes:
        """Create a pong response to a ping message."""
        response = {
            'type': 'pong',
            'id': ping_message.get('id', ''),
            'sender': {
                'id': self.node_id.hex(),
                'ip': self.ip,
                'port': self.port
            }
        }
        return json.dumps(response).encode()
    
    def _handle_pong_response(self, pong_message: Dict) -> None:
        """Handle a pong response."""
        # Check if this is a response to one of our pending requests
        request_id = pong_message.get('id', '')
        if request_id and request_id in self.pending_requests:
            future = self.pending_requests.pop(request_id)
            if not future.done():
                future.set_result(pong_message)
    
    def _handle_find_node(self, message: Dict) -> bytes:
        """Handle a find_node request and return closest nodes."""
        target_id = bytes.fromhex(message['target_id'])
        closest_nodes = self._find_closest_nodes(target_id, K)
        
        response = {
            'type': 'find_node_response',
            'id': message.get('id', ''),
            'sender': {
                'id': self.node_id.hex(),
                'ip': self.ip,
                'port': self.port
            },

#!/usr/bin/env python3
"""
Distributed Hash Table (DHT) implementation for Pacata Mesh VPN.

This module implements a Kademlia-based DHT for decentralized peer discovery in the
Pacata Mesh VPN network. It provides functionality for node lookup, key-value 
storage, and peer announcements.
"""

import asyncio
import hashlib
import json
import logging
import random
import socket
import struct
import time
from collections import defaultdict, OrderedDict
from typing import Dict, List, Optional, Tuple, Set, Any, Callable, Union

logger = logging.getLogger(__name__)

# Constants for Kademlia DHT
K = 20  # Number of nodes in a k-bucket
ALPHA = 3  # Number of parallel lookups
ID_BITS = 160  # Size of node IDs in bits (SHA1 = 160 bits)
BUCKET_REFRESH_INTERVAL = 3600  # 1 hour in seconds
KEY_REPUBLISH_INTERVAL = 86400  # 24 hours in seconds
VALUE_EXPIRE_TIME = 86400 * 2  # 48 hours in seconds
REPLICATE_INTERVAL = 3600  # 1 hour in seconds
RPC_TIMEOUT = 5  # 5 seconds timeout for RPC calls


class Node:
    """
    Represents a node in the Kademlia DHT network.
    
    Each node has an ID, IP address, and port. The ID is a 160-bit (20-byte)
    identifier derived from the node's IP and port.
    """
    
    def __init__(self, id: bytes, ip: str, port: int):
        """
        Initialize a node with its ID, IP address, and port.
        
        Args:
            id: 20-byte node ID (SHA1 hash)
            ip: IP address as string
            port: UDP port number
        """
        self.id = id
        self.ip = ip
        self.port = port
        self.last_seen = time.time()
    
    @classmethod
    def from_host_port(cls, ip: str, port: int):
        """
        Create a node with ID derived from its IP and port.
        
        Args:
            ip: IP address as string
            port: UDP port number
            
        Returns:
            A new Node instance
        """
        node_id = hashlib.sha1(f"{ip}:{port}".encode()).digest()
        return cls(node_id, ip, port)
    
    def __eq__(self, other):
        if not isinstance(other, Node):
            return False
        return self.id == other.id
    
    def __hash__(self):
        return int.from_bytes(self.id, byteorder='big')
    
    def __repr__(self):
        return f"Node({self.id.hex()[:8]}..., {self.ip}:{self.port})"
    
    def distance(self, other_id: bytes) -> int:
        """
        Calculate the XOR distance between this node and another node ID.
        
        Args:
            other_id: The ID to calculate distance to
            
        Returns:
            XOR distance as an integer
        """
        return int.from_bytes(self.id, byteorder='big') ^ int.from_bytes(other_id, byteorder='big')
    
    def refresh(self):
        """Update the last_seen timestamp for this node."""
        self.last_seen = time.time()
    
    def is_stale(self, stale_time: int = 86400) -> bool:
        """
        Check if the node hasn't been seen for a while.
        
        Args:
            stale_time: Time in seconds after which a node is considered stale
            
        Returns:
            True if node is stale, False otherwise
        """
        return (time.time() - self.last_seen) > stale_time


class KBucket:
    """
    K-bucket implementation for the Kademlia routing table.
    
    Each k-bucket stores up to k nodes within a specific distance range.
    Nodes are kept sorted by last seen time, with least-recently seen nodes at the head.
    """
    
    def __init__(self, min_range: int, max_range: int, k: int = K):
        """
        Initialize a k-bucket with its range and maximum size.
        
        Args:
            min_range: Minimum distance range (inclusive)
            max_range: Maximum distance range (exclusive)
            k: Maximum number of nodes in the bucket
        """
        self.min_range = min_range
        self.max_range = max_range
        self.k = k
        self.nodes: List[Node] = []
        self.replacement_cache: List[Node] = []
        self.last_refreshed = time.time()
    
    def __len__(self):
        return len(self.nodes)
    
    def in_range(self, distance: int) -> bool:
        """Check if a distance falls within this bucket's range."""
        return self.min_range <= distance < self.max_range
    
    def get_nodes(self) -> List[Node]:
        """Get a copy of the nodes in this bucket."""
        return self.nodes.copy()
    
    def add_node(self, node: Node) -> bool:
        """
        Try to add a node to this bucket.
        
        If the bucket is full, the node is added to the replacement cache.
        If the node is already in the bucket, it's moved to the end (most recently seen).
        
        Args:
            node: The node to add
            
        Returns:
            True if node was added to the bucket, False otherwise
        """
        # If node is already in the bucket, move it to the end
        for i, existing in enumerate(self.nodes):
            if existing == node:
                self.nodes.pop(i)
                self.nodes.append(node)
                node.refresh()
                return True
        
        # If bucket isn't full, add the node
        if len(self.nodes) < self.k:
            self.nodes.append(node)
            node.refresh()
            return True
        
        # Bucket is full, add to replacement cache
        for i, existing in enumerate(self.replacement_cache):
            if existing == node:
                self.replacement_cache.pop(i)
                break
                
        self.replacement_cache.append(node)
        node.refresh()
        return False
    
    def remove_node(self, node: Node) -> bool:
        """
        Remove a node from this bucket.
        
        If there are nodes in the replacement cache, the least recently
        seen one is added to the bucket.
        
        Args:
            node: The node to remove
            
        Returns:
            True if node was removed, False if not found
        """
        for i, existing in enumerate(self.nodes):
            if existing == node:
                self.nodes.pop(i)
                
                # Add a node from the replacement cache if available
                if self.replacement_cache:
                    self.nodes.append(self.replacement_cache.pop(0))
                    
                return True
        return False
    
    def get_stalest_node(self) -> Optional[Node]:
        """
        Get the least-recently seen node in the bucket.
        
        Returns:
            The stalest node or None if bucket is empty
        """
        if not self.nodes:
            return None
        return self.nodes[0]
    
    def split(self) -> Tuple['KBucket', 'KBucket']:
        """
        Split this bucket into two new buckets with half the range each.
        
        Returns:
            A tuple of two new KBucket instances
        """
        mid = self.min_range + (self.max_range - self.min_range) // 2
        lower = KBucket(self.min_range, mid, self.k)
        upper = KBucket(mid, self.max_range, self.k)
        
        # Distribute nodes between the two new buckets
        for node in self.nodes:
            distance = node.distance(node.id)
            if distance < mid:
                lower.add_node(node)
            else:
                upper.add_node(node)
                
        # Also distribute replacement nodes
        for node in self.replacement_cache:
            distance = node.distance(node.id)
            if distance < mid:
                lower.replacement_cache.append(node)
            else:
                upper.replacement_cache.append(node)
                
        return lower, upper
    
    def needs_refresh(self) -> bool:
        """Check if this bucket needs refreshing (hasn't been refreshed recently)."""
        return (time.time() - self.last_refreshed) > BUCKET_REFRESH_INTERVAL
    
    def mark_refreshed(self):
        """Mark this bucket as refreshed."""
        self.last_refreshed = time.time()


class RoutingTable:
    """
    Kademlia routing table implementation.
    
    The routing table consists of k-buckets organized by the distance from the local node.
    Each k-bucket covers a specific range of the 160-bit ID space.
    """
    
    def __init__(self, local_node: Node, k: int = K):
        """
        Initialize a routing table for a local node.
        
        Args:
            local_node: The local node this routing table belongs to
            k: The maximum size of each k-bucket
        """
        self.local_node = local_node
        self.k = k
        # Start with a single bucket covering the entire range
        self.buckets = [KBucket(0, 2**ID_BITS, k)]
    
    def get_bucket_for_node(self, node: Node) -> KBucket:
        """
        Find the appropriate bucket for a given node.
        
        Args:
            node: The node to find a bucket for
            
        Returns:
            The appropriate KBucket for this node
        """
        distance = self.local_node.distance(node.id)
        for bucket in self.buckets:
            if bucket.in_range(distance):
                return bucket
        
        # This should never happen with a properly initialized routing table
        raise ValueError(f"No bucket found for node {node}")
    
    def add_node(self, node: Node) -> bool:
        """
        Add a node to the routing table.
        
        If the node's bucket is full, it may trigger a bucket split if the bucket
        contains the local node's ID range. Otherwise, the node is added to the
        bucket's replacement cache.
        
        Args:
            node: The node to add
            
        Returns:
            True if the node was added to a bucket, False otherwise
        """
        # Don't add the local node to the routing table
        if node == self.local_node:
            return False
            
        bucket = self.get_bucket_for_node(node)
        
        # Try to add the node to its bucket
        if bucket.add_node(node):
            return True
            
        # If bucket is full, check if it can be split
        distance = self.local_node.distance(node.id)
        if bucket.in_range(int.from_bytes(self.local_node.id, byteorder='big')):
            # Split the bucket
            index = self.buckets.index(bucket)
            lower, upper = bucket.split()
            self.buckets[index] = lower
            self.buckets.insert(index + 1, upper)
            
            # Try adding the node again to one of the new buckets
            return self.add_node(node)
            
        # Bucket is full and can't be split, node is in replacement cache
        return False
    
    def remove_node(self, node: Node) -> bool:
        """
        Remove a node from the routing table.
        
        Args:
            node: The node to remove
            
        Returns:
            True if the node was removed, False if not found
        """
        bucket = self.get_bucket_for_node(node)
        return bucket.remove_node(node)
    
    def get_closest_nodes(self, target_id: bytes, k: int = K) -> List[Node]:
        """
        Find the k closest nodes to a target ID.
        
        Args:
            target_id: The target ID to find closest nodes to
            k: Maximum number of nodes to return
            
        Returns:
            List of up to k closest nodes, sorted by distance
        """
        nodes = []
        target_int = int.from_bytes(target_id, byteorder='big')
        
        # Collect all nodes from all buckets
        for bucket in self.buckets:
            nodes.extend(bucket.nodes)
            
        # Sort by distance to target ID
        nodes.sort(key=lambda node: node.distance(target_id))
        
        # Return k closest nodes
        return nodes[:k]
    
    def get_refresh_list(self, force: bool = False) -> List[Tuple[int, int]]:
        """
        Get a list of bucket ranges that need refreshing.
        
        Args:
            force: If True, include all buckets regardless of last refresh time
            
        Returns:
            List of (min_range, max_range) tuples for buckets to refresh
        """
        refresh_list = []
        for bucket in self.buckets:
            if force or bucket.needs_refresh():
                refresh_list.append((bucket.min_range, bucket.max_range))
                if not force:
                    bucket.mark_refreshed()
        return refresh_list
    
    def get_node(self, node_id: bytes) -> Optional[Node]:
        """
        Find a specific node in the routing table by its ID.
        
        Args:
            node_id: The ID of the node to find
            
        Returns:
            The node if found, None otherwise
        """
        distance = self.local_node.distance(node_id)
        for bucket in self.buckets:
            if bucket.in_range(distance):
                for node in bucket.nodes:
                    if node.id == node_id:
                        return node
        return None
    
    def bucket_stats(self) -> Dict[str, int]:
        """
        Get statistics about the routing table buckets.
        
        Returns:
            Dictionary with bucket statistics
        """
        stats = {
            'total_buckets': len(self.buckets),
            'total_nodes': sum(len(bucket) for bucket in self.buckets),
            'empty_buckets': sum(1 for bucket in self.buckets if len(bucket) == 0),
            'full_buckets': sum(1 for bucket in self.buckets if len(bucket) == self.k),
        }
        return stats


class Storage:
    """
    Storage for the DHT key-value pairs.
    
    Handles expiration of values and tracks publishers for republishing.
    """
    
    def __init__(self, expiry_time: int = VALUE_EXPIRE_TIME):
        """
        Initialize the storage with an expiry time.
        
        Args:
            expiry_time: Time in seconds after which values expire
        """
        self.data = {}  # {key: (value, timestamp, original_publisher_id, original_signature)}
        self.expiry_time = expiry_time
        self.publishers = defaultdict(set)  # {key: {(publisher_id, timestamp)}}
        
    def __contains__(self, key: bytes) -> bool:
        """Check if a key exists in storage and hasn't expired."""
        self._expire_check(key)
        return key in self.data
    
    def get(self,

