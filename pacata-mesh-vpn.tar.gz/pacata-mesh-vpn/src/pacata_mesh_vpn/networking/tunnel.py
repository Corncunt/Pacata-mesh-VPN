#!/usr/bin/env python3
"""
Tunnel interface management for Pacata Mesh VPN.

This module provides classes for creating and managing network tunnels
for the VPN. It currently focuses on Linux implementation with the
TunnelManager class handling the lifecycle of tunnel interfaces.
"""

import os
import fcntl
import struct
import socket
import logging
import threading
import subprocess
from typing import Optional, Tuple, Callable, Dict

# Configure logger
logger = logging.getLogger(__name__)

# Constants for TUN/TAP interface
TUNSETIFF = 0x400454ca
IFF_TUN = 0x0001
IFF_TAP = 0x0002
IFF_NO_PI = 0x1000


class LinuxTunnel:
    """
    Implementation of a TUN/TAP interface for Linux systems.
    
    This class handles the creation and management of a TUN device
    that allows the VPN to intercept and inject network packets.
    """
    
    def __init__(self, name: str = "pacata0", is_tap: bool = False):
        """
        Initialize a new Linux tunnel interface.
        
        Args:
            name: Name of the tunnel interface (default: pacata0)
            is_tap: If True, create a TAP (Layer 2) device instead of TUN (Layer 3)
        """
        self.name = name
        self.is_tap = is_tap
        self.fd = None
        self.mtu = 1500
        self.running = False
        self.read_thread = None
        self.packet_handler = None
        
    def open(self) -> bool:
        """
        Open and configure the tunnel interface.
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Open the TUN/TAP device
            self.fd = os.open("/dev/net/tun", os.O_RDWR)
            
            # Prepare the ioctl request
            flags = IFF_TUN
            if self.is_tap:
                flags = IFF_TAP
                
            # Include IFF_NO_PI to exclude packet info
            flags |= IFF_NO_PI
            
            # Configure the TUN/TAP device
            ifr = struct.pack('16sH', self.name.encode(), flags)
            fcntl.ioctl(self.fd, TUNSETIFF, ifr)
            
            # Set the interface up and configure it
            self._configure_interface()
            
            logger.info(f"Tunnel interface {self.name} created successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create tunnel interface: {str(e)}")
            if self.fd:
                os.close(self.fd)
                self.fd = None
            return False
    
    def _configure_interface(self) -> None:
        """Configure the tunnel interface with IP and bring it up."""
        try:
            # Set the interface up
            subprocess.run(["ip", "link", "set", "dev", self.name, "up"], check=True)
            
            # Set MTU
            subprocess.run(["ip", "link", "set", "dev", self.name, "mtu", str(self.mtu)], check=True)
            
            # Assign an IP address (using a default for now)
            # In a real implementation, this should use an address from a dedicated VPN subnet
            subprocess.run(["ip", "addr", "add", "10.7.0.1/24", "dev", self.name], check=True)
            
            logger.info(f"Tunnel interface {self.name} configured with IP 10.7.0.1/24")
        except subprocess.SubprocessError as e:
            logger.error(f"Failed to configure tunnel interface: {str(e)}")
            raise
    
    def close(self) -> None:
        """Close the tunnel interface and clean up resources."""
        self.stop_reading()
        
        if self.fd:
            try:
                # Bring the interface down before closing
                subprocess.run(["ip", "link", "set", "dev", self.name, "down"], check=True)
                os.close(self.fd)
                logger.info(f"Tunnel interface {self.name} closed")
            except Exception as e:
                logger.error(f"Error closing tunnel interface: {str(e)}")
            finally:
                self.fd = None
    
    def register_packet_handler(self, handler: Callable[[bytes], None]) -> None:
        """
        Register a callback function to handle packets received from the tunnel.
        
        Args:
            handler: Callback function that takes a packet (bytes) as argument
        """
        self.packet_handler = handler
    
    def start_reading(self) -> None:
        """Start a background thread to read packets from the tunnel."""
        if not self.fd:
            logger.error("Cannot start reading: tunnel not open")
            return
            
        if self.running:
            logger.warning("Packet reading thread already running")
            return
            
        self.running = True
        self.read_thread = threading.Thread(target=self._read_packets)
        self.read_thread.daemon = True
        self.read_thread.start()
        logger.info(f"Started reading packets from tunnel {self.name}")
    
    def stop_reading(self) -> None:
        """Stop the packet reading thread."""
        self.running = False
        if self.read_thread and self.read_thread.is_alive():
            self.read_thread.join(timeout=2.0)
            logger.info(f"Stopped reading packets from tunnel {self.name}")
    
    def _read_packets(self) -> None:
        """Background thread function to read and process packets."""
        if not self.fd:
            logger.error("Cannot read packets: tunnel not open")
            return
            
        while self.running:
            try:
                # Read a packet from the tunnel
                packet = os.read(self.fd, 2048)  # Adjust buffer size as needed
                
                # Process the packet if we have a handler
                if packet and self.packet_handler:
                    self.packet_handler(packet)
                    
            except Exception as e:
                if self.running:  # Only log if we're still supposed to be running
                    logger.error(f"Error reading packet: {str(e)}")
                    # Brief pause to avoid tight loop on error
                    threading.Event().wait(0.1)
    
    def write(self, packet: bytes) -> int:
        """
        Write a packet to the tunnel interface.
        
        Args:
            packet: The packet data to write
            
        Returns:
            int: Number of bytes written
        """
        if not self.fd:
            logger.error("Cannot write packet: tunnel not open")
            return 0
            
        try:
            return os.write(self.fd, packet)
        except Exception as e:
            logger.error(f"Error writing packet: {str(e)}")
            return 0


class TunnelManager:
    """
    Manages tunnel interfaces and handles packet routing for the VPN.
    
    This class provides a higher-level interface for creating and managing
    tunnel interfaces, routing packets between peers, and handling IP assignments.
    """
    
    def __init__(self):
        """Initialize the tunnel manager."""
        self.tunnel = None
        self.vpn_network = "10.7.0.0/24"  # Default VPN subnet
        self.assigned_ips = {}  # Map of peer_id -> assigned_ip
        self.ip_to_peer = {}    # Reverse mapping of IP -> peer_id
        self.running = False
        self.packet_callbacks = []  # Functions to call when packets are received
    
    def create_tunnel(self, name: str = "pacata0") -> bool:
        """
        Create and initialize a tunnel interface.
        
        Args:
            name: Name for the tunnel interface
            
        Returns:
            bool: True if successful, False otherwise
        """
        # Close any existing tunnel
        if self.tunnel:
            self.close_tunnel()
        
        # Create a new tunnel
        self.tunnel = LinuxTunnel(name=name)
        
        # Open and configure the tunnel
        if not self.tunnel.open():
            self.tunnel = None
            return False
        
        # Set up packet handling
        self.tunnel.register_packet_handler(self._handle_tunnel_packet)
        
        logger.info(f"Tunnel {name} created and configured")
        return True
    
    def close_tunnel(self) -> None:
        """Close the current tunnel interface if it exists."""
        if self.tunnel:
            self.tunnel.close()
            self.tunnel = None
            logger.info("Tunnel closed")
    
    def start(self) -> bool:
        """
        Start the tunnel manager and begin processing packets.
        
        Returns:
            bool: True if successfully started, False otherwise
        """
        if not self.tunnel:
            logger.error("Cannot start: no tunnel created")
            return False
            
        if self.running:
            logger.warning("Tunnel manager already running")
            return True
            
        # Start reading packets
        self.tunnel.start_reading()
        self.running = True
        logger.info("Tunnel manager started")
        return True
    
    def stop(self) -> None:
        """Stop the tunnel manager and clean up resources."""
        self.running = False
        
        if self.tunnel:
            self.tunnel.stop_reading()
            logger.info("Tunnel manager stopped")
    
    def assign_ip(self, peer_id: str) -> Optional[str]:
        """
        Assign an IP address from the VPN subnet to a peer.
        
        Args:
            peer_id: Unique identifier for the peer
            
        Returns:
            Optional[str]: The assigned IP address or None if allocation failed
        """
        # If peer already has an IP, return it
        if peer_id in self.assigned_ips:
            return self.assigned_ips[peer_id]
            
        # Parse the VPN network to get the base address
        network_parts = self.vpn_network.split('/')
        base_ip = network_parts[0]
        base_octets = [int(octet) for octet in base_ip.split('.')]
        
        # Simple allocation strategy: use the 4th octet as host ID
        # In a real implementation, this should be more sophisticated
        for host_id in range(2, 254):  # Skip .0 (network) and .1 (our node)
            candidate_ip = f"{base_octets[0]}.{base_octets[1]}.{base_octets[2]}.{host_id}"
            
            if candidate_ip not in self.ip_to_peer:
                # Assign this IP to the peer
                self.assigned_ips[peer_id] = candidate_ip
                self.ip_to_peer[candidate_ip] = peer_id
                logger.info(f"Assigned IP {candidate_ip} to peer {peer_id}")
                return candidate_ip
        
        logger.error(f"Could not assign IP to peer {peer_id}: subnet full")
        return None
    
    def release_ip(self, peer_id: str) -> None:
        """
        Release an IP address assigned to a peer.
        
        Args:
            peer_id: Unique identifier of the peer
        """
        if peer_id in self.assigned_ips:
            ip = self.assigned_ips[peer_id]
            del self.ip_to_peer[ip]
            del self.assigned_ips[peer_id]
            logger.info(f"Released IP {ip} from peer {peer_id}")
    
    def register_packet_callback(self, callback: Callable[[bytes, str], None]) -> None:
        """
        Register a callback for packet processing.
        
        Args:
            callback: Function to call with (packet_data, source_ip)
        """
        if callback not in self.packet_callbacks:
            self.packet_callbacks.append(callback)
    
    def unregister_packet_callback(self, callback: Callable[[bytes, str], None]) -> None:
        """
        Remove a packet processing callback.
        
        Args:
            callback: The callback to remove
        """
        if callback in self.packet_callbacks:
            self.packet_callbacks.remove(callback)
    
    def _handle_tunnel_packet(self, packet: bytes) -> None:
        """
        Process a packet from the tunnel interface.
        
        This method is called when the tunnel interface receives a packet.
        It extracts the destination IP and routes the packet accordingly.
        
        Args:
            packet: The raw packet data
        """
        if not self.running:
            return
            
        try:
            # Extract IP header (simplified version)
            version_ihl = packet[0]
            ihl = (version_ihl & 0x0F) * 4  # IHL is in 4-byte units
            
            # Get source and destination IPs
            src_ip = socket.inet_ntoa(packet[12:16])
            dst_ip = socket.inet_ntoa(packet[16:20])
            
            logger.debug(f"Packet: {src_ip} -> {dst_ip}, {len(packet)} bytes")
            
            # Find the destination peer
            dst_peer = self.ip_to_peer.get(dst_ip)
            
            # Notify callbacks
            for callback in self.packet_callbacks:
                try:
                    callback(packet, dst_ip)
                except Exception as e:
                    logger.error(f"Error in packet callback: {str(e)}")
                    
        except Exception as e:
            logger.error(f"Error processing packet: {str(e)}")
    
    def send_packet(self, packet: bytes) -> bool:
        """
        Send a packet through the tunnel interface.
        
        Args:
            packet: The packet data to send
            
        Returns:
            bool: True if packet was sent successfully, False otherwise
        """
        if not self.tunnel or not self.running:
            logger.error("Cannot send packet: tunnel not ready")
            return False
            
        try:
            bytes_written = self.tunnel.write(packet)
            return bytes_written > 0
        except Exception as e:
            logger.error(f"Error sending packet: {str(e)}")
            return False

"""
Tunnel interface implementation for Pacata Mesh VPN.

This module provides the implementation for network tunneling in the VPN,
focusing on Linux systems. It includes the LinuxTunnel class for low-level
tunnel operations and a TunnelManager class for handling the tunnel lifecycle.
"""

import os
import fcntl
import struct
import subprocess
import logging
import select
import threading
import ipaddress
from typing import Optional, Tuple, Callable, List

logger = logging.getLogger(__name__)

# Constants for tunnel interface setup
TUNSETIFF = 0x400454ca
IFF_TUN = 0x0001
IFF_NO_PI = 0x1000


class LinuxTunnel:
    """Linux implementation of a TUN interface for VPN tunneling."""
    
    def __init__(self, name: str = "pacata0"):
        """
        Initialize a TUN interface for Linux.
        
        Args:
            name: Name of the TUN interface (default: pacata0)
        """
        self.name = name
        self.tun_fd = None
        self.mtu = 1500
        self._running = False
        
    def open(self) -> bool:
        """
        Open and configure the TUN interface.
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Open the TUN device
            self.tun_fd = os.open("/dev/net/tun", os.O_RDWR)
            
            # Configure it as a TUN device
            ifr = struct.pack('16sH', self.name.encode(), IFF_TUN | IFF_NO_PI)
            fcntl.ioctl(self.tun_fd, TUNSETIFF, ifr)
            
            # Make the file descriptor non-blocking
            flags = fcntl.fcntl(self.tun_fd, fcntl.F_GETFL)
            fcntl.fcntl(self.tun_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
            
            logger.info(f"TUN interface {self.name} created successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to create TUN interface: {str(e)}")
            if self.tun_fd:
                os.close(self.tun_fd)
                self.tun_fd = None
            return False
    
    def close(self):
        """Close the TUN interface and release resources."""
        if self.tun_fd:
            logger.info(f"Closing TUN interface {self.name}")
            os.close(self.tun_fd)
            self.tun_fd = None
            self._running = False

    def set_up(self) -> bool:
        """
        Set the interface status to UP.
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            subprocess.run(
                ["ip", "link", "set", "dev", self.name, "up"],
                check=True
            )
            logger.info(f"TUN interface {self.name} is up")
            return True
        except subprocess.SubprocessError as e:
            logger.error(f"Failed to set TUN interface up: {str(e)}")
            return False
    
    def set_mtu(self, mtu: int = 1500) -> bool:
        """
        Set the MTU of the interface.
        
        Args:
            mtu: MTU value to set (default: 1500)
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            subprocess.run(
                ["ip", "link", "set", "dev", self.name, "mtu", str(mtu)],
                check=True
            )
            self.mtu = mtu
            logger.info(f"Set MTU of {self.name} to {mtu}")
            return True
        except subprocess.SubprocessError as e:
            logger.error(f"Failed to set MTU: {str(e)}")
            return False
    
    def add_address(self, address: str, netmask: int) -> bool:
        """
        Assign an IP address to the interface.
        
        Args:
            address: IP address to assign
            netmask: Netmask prefix length (e.g., 24 for 255.255.255.0)
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            subprocess.run(
                ["ip", "addr", "add", f"{address}/{netmask}", "dev", self.name],
                check=True
            )
            logger.info(f"Added IP {address}/{netmask} to {self.name}")
            return True
        except subprocess.SubprocessError as e:
            logger.error(f"Failed to add IP address: {str(e)}")
            return False
    
    def add_route(self, network: str, netmask: int) -> bool:
        """
        Add a route through the interface.
        
        Args:
            network: Network address to route
            netmask: Netmask prefix length
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            subprocess.run(
                ["ip", "route", "add", f"{network}/{netmask}", "dev", self.name],
                check=True
            )
            logger.info(f"Added route for {network}/{netmask} via {self.name}")
            return True
        except subprocess.SubprocessError as e:
            logger.error(f"Failed to add route: {str(e)}")
            return False
    
    def read_packet(self, timeout: float = 0.1) -> Optional[bytes]:
        """
        Read a packet from the TUN interface.
        
        Args:
            timeout: Timeout in seconds (default: 0.1)
            
        Returns:
            bytes: Packet data if available, None otherwise
        """
        if not self.tun_fd:
            return None
        
        try:
            ready, _, _ = select.select([self.tun_fd], [], [], timeout)
            if ready:
                packet = os.read(self.tun_fd, self.mtu)
                return packet
        except (OSError, select.error) as e:
            logger.error(f"Error reading from TUN: {str(e)}")
        
        return None
    
    def write_packet(self, packet: bytes) -> bool:
        """
        Write a packet to the TUN interface.
        
        Args:
            packet: Packet data to write
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not self.tun_fd:
            return False
            
        try:
            os.write(self.tun_fd, packet)
            return True
        except OSError as e:
            logger.error(f"Error writing to TUN: {str(e)}")
            return False


class TunnelManager:
    """
    Manages the lifecycle of a tunnel interface and handles packet processing.
    
    This class provides high-level management of a tunnel interface, including
    setup, packet processing, and cleanup.
    """
    
    def __init__(
        self, 
        ip_address: str, 
        netmask: int = 24,
        routes: List[Tuple[str, int]] = None,
        mtu: int = 1500,
        interface_name: str = "pacata0"
    ):
        """
        Initialize the TunnelManager.
        
        Args:
            ip_address: IP address to assign to the tunnel
            netmask: Netmask prefix length (default: 24)
            routes: List of (network, netmask) tuples to route (default: None)
            mtu: MTU for the tunnel interface (default: 1500)
            interface_name: Name for the tunnel interface (default: pacata0)
        """
        self.ip_address = ip_address
        self.netmask = netmask
        self.routes = routes or []
        self.mtu = mtu
        self.interface_name = interface_name
        
        self.tunnel = LinuxTunnel(name=interface_name)
        self.packet_handler = None
        
        self._running = False
        self._read_thread = None
    
    def setup(self) -> bool:
        """
        Set up the tunnel interface.
        
        Returns:
            bool: True if successful, False otherwise
        """
        if not self.tunnel.open():
            return False
        
        if not all([
            self.tunnel.set_up(),
            self.tunnel.set_mtu(self.mtu),
            self.tunnel.add_address(self.ip_address, self.netmask)
        ]):
            self.tunnel.close()
            return False
        
        # Add routes
        for network, netmask in self.routes:
            if not self.tunnel.add_route(network, netmask):
                logger.warning(f"Failed to add route for {network}/{netmask}")
        
        return True
    
    def start(self, packet_handler: Callable[[bytes], Optional[bytes]]) -> bool:
        """
        Start the tunnel and packet processing.
        
        Args:
            packet_handler: Callback function to process packets
                           Takes packet bytes as input and returns response bytes or None
        
        Returns:
            bool: True if started successfully, False otherwise
        """
        if self._running:
            logger.warning("Tunnel is already running")
            return False
        
        if not self.tunnel.tun_fd:
            if not self.setup():
                logger.error("Failed to set up tunnel")
                return False
        
        self.packet_handler = packet_handler
        self._running = True
        
        # Start packet reading thread
        self._read_thread = threading.Thread(
            target=self._packet_read_loop,
            daemon=True
        )
        self._read_thread.start()
        
        logger.info(f"Tunnel {self.interface_name} started successfully")
        return True
    
    def stop(self):
        """Stop the tunnel and release resources."""
        if not self._running:
            return
        
        self._running = False
        
        # Wait for read thread to terminate
        if self._read_thread and self._read_thread.is_alive():
            self._read_thread.join(timeout=2.0)
        
        self.tunnel.close()
        logger.info(f"Tunnel {self.interface_name} stopped")
    
    def _packet_read_loop(self):
        """Background thread to read and process packets."""
        while self._running:
            packet = self.tunnel.read_packet(timeout=0.1)
            if not packet:
                continue
            
            try:
                if self.packet_handler:
                    response = self.packet_handler(packet)
                    if response:
                        self.tunnel.write_packet(response)
            except Exception as e:
                logger.error(f"Error in packet handler: {str(e)}")
    
    def inject_packet(self, packet: bytes) -> bool:
        """
        Inject a packet into the tunnel.
        
        Args:
            packet: Packet data to inject
            
        Returns:
            bool: True if successful, False otherwise
        """
        return self.tunnel.write_packet(packet)
    
    def __enter__(self):
        """Context manager entry."""
        self.setup()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.stop()


# Example usage
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    def simple_packet_handler(packet: bytes) -> Optional[bytes]:
        # This is just a demonstration
        # In a real implementation, you would process the packet
        # based on your VPN protocol
        print(f"Received packet: {len(packet)} bytes")
        return None
    
    # Example: Set up a tunnel with IP 10.0.0.1/24
    with TunnelManager(
        ip_address="10.0.0.1",
        netmask=24,
        routes=[("10.0.0.0", 24)]
    ) as manager:
        try:
            manager.start(simple_packet_handler)
            print("Press Ctrl+C to stop...")
            while True:
                # Main thread just waits
                import time
                time.sleep(1)
        except KeyboardInterrupt:
            print("Stopping...")

#!/usr/bin/env python3
"""
Network tunnel implementation for Pacata Mesh VPN.

This module provides the implementation for creating and managing network tunnels
on different platforms (Linux, macOS, Windows) using TUN/TAP interfaces.
"""

import os
import sys
import fcntl
import struct
import socket
import logging
import threading
import subprocess
import ipaddress
from abc import ABC, abstractmethod
from typing import Optional, Tuple, List, Callable, Dict, Any

# Configure logging
logger = logging.getLogger(__name__)

# Constants
TUNSETIFF = 0x400454ca  # From <linux/if_tun.h>
IFF_TUN = 0x0001
IFF_TAP = 0x0002
IFF_NO_PI = 0x1000
PACKET_SIZE = 2048


class Tunnel(ABC):
    """Abstract base class for platform-specific tunnel implementations."""

    def __init__(self, name: str = "", ip_address: str = "10.8.0.1", 
                 netmask: str = "255.255.255.0"):
        """
        Initialize the tunnel with default parameters.
        
        Args:
            name: Name of the tunnel interface
            ip_address: IP address to assign to the tunnel
            netmask: Network mask for the tunnel
        """
        self.name = name
        self.ip_address = ip_address
        self.netmask = netmask
        self.cidr = self._calculate_cidr(netmask)
        self.fd = None  # File descriptor for the tunnel
        self.mtu = 1500
        self.running = False
        self.read_thread = None
        self.callback = None
        
    def _calculate_cidr(self, netmask: str) -> int:
        """Calculate CIDR prefix length from netmask."""
        return sum(bin(int(x)).count('1') for x in netmask.split('.'))
    
    @abstractmethod
    def open(self) -> bool:
        """
        Open and setup the tunnel interface.
        
        Returns:
            bool: True if the tunnel was successfully opened, False otherwise
        """
        pass
    
    @abstractmethod
    def close(self) -> None:
        """Close the tunnel interface and release resources."""
        pass
    
    @abstractmethod
    def configure(self) -> bool:
        """
        Configure the tunnel interface (IP address, routing, etc.).
        
        Returns:
            bool: True if configuration was successful, False otherwise
        """
        pass
    
    @abstractmethod
    def read_packet(self) -> bytes:
        """
        Read a packet from the tunnel.
        
        Returns:
            bytes: The packet data read from the tunnel
        """
        pass
    
    @abstractmethod
    def write_packet(self, packet: bytes) -> int:
        """
        Write a packet to the tunnel.
        
        Args:
            packet: The packet data to write
            
        Returns:
            int: Number of bytes written
        """
        pass
    
    def start_reading(self, callback: Callable[[bytes], None]) -> None:
        """
        Start reading packets in a separate thread.
        
        Args:
            callback: Function to call with each packet read
        """
        if self.running:
            logger.warning("Tunnel read thread already running")
            return
        
        self.callback = callback
        self.running = True
        self.read_thread = threading.Thread(target=self._read_loop)
        self.read_thread.daemon = True
        self.read_thread.start()
        logger.info(f"Started tunnel reading thread for {self.name}")
    
    def stop_reading(self) -> None:
        """Stop the packet reading thread."""
        self.running = False
        if self.read_thread and self.read_thread.is_alive():
            self.read_thread.join(timeout=2.0)
            logger.info(f"Stopped tunnel reading thread for {self.name}")
    
    def _read_loop(self) -> None:
        """Internal method to continuously read packets."""
        while self.running:
            try:
                packet = self.read_packet()
                if packet and self.callback:
                    self.callback(packet)
            except (OSError, IOError) as e:
                if self.running:  # Only log if we're still supposed to be running
                    logger.error(f"Error reading from tunnel: {e}")
                    # Small delay to prevent CPU spinning on errors
                    threading.Event().wait(0.1)
            except Exception as e:
                logger.exception(f"Unexpected error in tunnel read loop: {e}")
                if self.running:
                    threading.Event().wait(0.1)


class LinuxTunnel(Tunnel):
    """Linux platform implementation of a TUN/TAP tunnel."""
    
    def open(self) -> bool:
        """
        Open a TUN device on Linux.
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Open the TUN/TAP device
            self.fd = open("/dev/net/tun", "rb+")
            
            # Generate a name if none provided
            if not self.name:
                self.name = f"tun%d"
            
            # Prepare the ioctl call
            ifr = struct.pack('16sH', self.name.encode(), IFF_TUN | IFF_NO_PI)
            
            # Configure the TUN device
            fcntl.ioctl(self.fd, TUNSETIFF, ifr)
            
            # Get the actual interface name
            ifname = struct.unpack('16sH', ifr)[0].strip(b'\x00').decode()
            self.name = ifname
            
            logger.info(f"Opened TUN device: {self.name}")
            return True
        except Exception as e:
            logger.error(f"Failed to open TUN device: {e}")
            if self.fd:
                self.fd.close()
                self.fd = None
            return False
    
    def close(self) -> None:
        """Close the TUN device."""
        self.stop_reading()
        if self.fd:
            try:
                self.fd.close()
                logger.info(f"Closed TUN device: {self.name}")
            except Exception as e:
                logger.error(f"Error closing TUN device: {e}")
            finally:
                self.fd = None
    
    def configure(self) -> bool:
        """
        Configure the tunnel interface on Linux.
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Set interface up
            subprocess.run(["ip", "link", "set", "dev", self.name, "up"], check=True)
            
            # Set IP address
            subprocess.run(
                ["ip", "addr", "add", f"{self.ip_address}/{self.cidr}", "dev", self.name],
                check=True
            )
            
            # Set MTU
            subprocess.run(
                ["ip", "link", "set", "dev", self.name, "mtu", str(self.mtu)],
                check=True
            )
            
            logger.info(f"Configured TUN device {self.name} with IP {self.ip_address}/{self.cidr}")
            return True
        except subprocess.SubprocessError as e:
            logger.error(f"Failed to configure TUN device: {e}")
            return False
    
    def read_packet(self) -> bytes:
        """
        Read a packet from the tunnel.
        
        Returns:
            bytes: Packet data
        """
        if not self.fd:
            raise IOError("Tunnel not open")
        
        return self.fd.read(PACKET_SIZE)
    
    def write_packet(self, packet: bytes) -> int:
        """
        Write a packet to the tunnel.
        
        Args:
            packet: Packet data to write
            
        Returns:
            int: Number of bytes written
        """
        if not self.fd:
            raise IOError("Tunnel not open")
        
        return self.fd.write(packet)


class DarwinTunnel(Tunnel):
    """macOS (Darwin) platform implementation of a TUN/TAP tunnel."""
    
    def open(self) -> bool:
        """
        Open a TUN device on macOS.
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # On macOS, TUN devices are typically named /dev/tunX
            # Try to find an available one if name not specified
            if not self.name or not self.name.startswith("tun"):
                # Scan for available tun devices
                for i in range(0, 16):
                    tun_name = f"tun{i}"
                    tun_path = f"/dev/{tun_name}"
                    if os.path.exists(tun_path):
                        try:
                            self.fd = open(tun_path, "rb+")
                            self.name = tun_name
                            logger.info(f"Opened TUN device: {self.name}")
                            return True
                        except (IOError, OSError):
                            # Try the next one
                            continue
                
                logger.error("Could not find an available TUN device")
                return False
            else:
                # Use the specified name
                tun_path = f"/dev/{self.name}"
                if not os.path.exists(tun_path):
                    logger.error(f"TUN device {tun_path} does not exist")
                    return False
                
                self.fd = open(tun_path, "rb+")
                logger.info(f"Opened TUN device: {self.name}")
                return True
        except Exception as e:
            logger.error(f"Failed to open TUN device: {e}")
            if self.fd:
                self.fd.close()
                self.fd = None
            return False
    
    def close(self) -> None:
        """Close the TUN device."""
        self.stop_reading()
        if self.fd:
            try:
                self.fd.close()
                logger.info(f"Closed TUN device: {self.name}")
            except Exception as e:
                logger.error(f"Error closing TUN device: {e}")
            finally:
                self.fd = None
    
    def configure(self) -> bool:
        """
        Configure the tunnel interface on macOS.
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Set interface up
            subprocess.run(["ifconfig", self.name, "up"], check=True)
            
            # Set IP address
            subprocess.run(
                ["ifconfig", self.name, "inet", self.ip_address, self.netmask],
                check=True
            )
            
            # Set MTU
            subprocess.run(
                ["ifconfig", self.name, "mtu", str(self.mtu)],
                check=True
            )
            
            logger.info(f"Configured TUN device {self.name} with IP {self.ip_address}")
            return True
        except subprocess.SubprocessError as e:
            logger.error(f"Failed to configure TUN device: {e}")
            return False
    
    def read_packet(self) -> bytes:
        """
        Read a packet from the tunnel.
        
        Returns:
            bytes: Packet data
        """
        if not self.fd:
            raise IOError("Tunnel not open")
        
        # On macOS, the first 4 bytes are the family type (AF_INET, etc.)
        packet = self.fd.read(PACKET_SIZE)
        # Skip the first 4 bytes (header) and return the actual packet
        return packet[4:] if len(packet) > 4 else b''
    
    def write_packet(self, packet: bytes) -> int:
        """
        Write a packet to the tunnel.
        
        Args:
            packet: Packet data to write
            
        Returns:
            int: Number of bytes written
        """
        if not self.fd:
            raise IOError("Tunnel not open")
        
        # On macOS, we need to prepend 4 bytes with the address family
        # Assume IPv4 (AF_INET = 2) for now
        family = 2  # AF_INET for IPv4
        
        # Determine the protocol family from the packet's first byte
        if packet and len(packet) > 0:
            version = (packet[0] >> 4) & 0xF
            if version == 6:
                family = 30  # AF_INET6 for IPv6
        
        header = struct.pack("!I", family)
        return self.fd.write(header + packet)


class WindowsTunnel(Tunnel):
    """Windows platform implementation of a TUN/TAP tunnel using WinTun or TAP-Windows."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.adapter_guid = None  # Needed for Windows TAP adapter identification
        
        # Check if we need to use the pytun library for Windows
        try:
            import pytun
            self.pytun_available = True
        except ImportError:
            self.pytun_available = False
            logger.warning("pytun not available, falling back to wintun or alternate methods")
    
    def open(self) -> bool:
        """
        Open a TUN device on Windows using either pytun or direct WinTun API.
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            if self.pytun_available:
                import pytun
                
                # Create a TUN device using pytun
                self.tun = pytun.TunTapDevice(name=self.name or "PacataVPN")
                self.tun.up()
                self.name = self.tun.name
                self.fd = self.tun  # Use the tun object as our file descriptor
                logger.info(f"Opened TUN device using pytun: {self.name}")
                return True
            else:
                # Fall back to PowerShell commands to manage TAP adapter
                # This is a simplified approach - a real implementation would use
                # the WinTun driver or Windows TAP-Windows adapter more directly
                
                # Check if the TAP adapter exists
                result = subprocess.run(
                    ["powershell", "-Command", "Get-NetAdapter | Where-Object {$_.InterfaceDescription -like '*TAP-Windows*'}"],
                    capture_output=True,
                    text=True,
                    check=False
                )
                
                if "PacataVPN" not in result.stdout:
                    logger.error("TAP-Windows adapter not found. Please install TAP-Windows driver.")
                    return False
                
                self.name = "PacataVPN"
                # This is a placeholder. In a real implementation, we would open a handle to the device
                self.fd = True  # Just to indicate it's open
                logger.info(f"Opened TAP device: {self.name}")
                return True
        except Exception as e:
            logger.error(f"Failed to open TUN device on Windows: {e}")
            self.fd = None
            return False
    
    def close(self) -> None:
        """Close the TUN device."""
        self.stop

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Network tunneling implementation for Pacata Mesh VPN.

This module provides the necessary functionality to create and manage
TUN/TAP interfaces for the VPN, route packets through the tunnel, and
handle IP address assignment and management.
"""

import os
import sys
import fcntl
import socket
import struct
import select
import logging
import ipaddress
import threading
import subprocess
import platform
from enum import Enum
from typing import Optional, Tuple, List, Dict, Union, Callable

# Configure logging
logger = logging.getLogger(__name__)


class TunnelType(Enum):
    """Defines the type of virtual network interface to use."""
    TUN = 1  # Layer 3 tunneling (IP)
    TAP = 2  # Layer 2 tunneling (Ethernet)


class TunnelError(Exception):
    """Exception raised for errors in the Tunnel module."""
    pass


class IPAddressPool:
    """Manages a pool of IP addresses for assignment to VPN clients."""
    
    def __init__(self, network: str = "10.8.0.0/24"):
        """
        Initialize the IP address pool.
        
        Args:
            network: CIDR notation of the network to use (default: 10.8.0.0/24)
        """
        self.network = ipaddress.ip_network(network)
        self.assigned = set()
        # Reserve network address and broadcast address
        self.assigned.add(str(self.network.network_address))
        self.assigned.add(str(self.network.broadcast_address))
        # Reserve first address for the server
        self.server_ip = str(self.network.network_address + 1)
        self.assigned.add(self.server_ip)
        self.lock = threading.Lock()
    
    def get_server_ip(self) -> str:
        """Return the server IP address."""
        return self.server_ip
    
    def assign_ip(self) -> str:
        """
        Assign an available IP address from the pool.
        
        Returns:
            A string containing an available IP address
            
        Raises:
            TunnelError: If no IP addresses are available
        """
        with self.lock:
            for ip in self.network.hosts():
                ip_str = str(ip)
                if ip_str not in self.assigned:
                    self.assigned.add(ip_str)
                    return ip_str
            
            raise TunnelError("No IP addresses available in the pool")
    
    def release_ip(self, ip: str) -> None:
        """
        Release an assigned IP address back to the pool.
        
        Args:
            ip: The IP address to release
        """
        with self.lock:
            if ip in self.assigned and ip != self.server_ip:
                self.assigned.remove(ip)
    
    def is_assigned(self, ip: str) -> bool:
        """
        Check if an IP address is already assigned.
        
        Args:
            ip: The IP address to check
            
        Returns:
            True if the IP is assigned, False otherwise
        """
        with self.lock:
            return ip in self.assigned


class Tunnel:
    """
    Base class for platform-independent tunnel interface operations.
    Specific platform implementations will inherit from this class.
    """
    
    def __init__(
        self, 
        tunnel_type: TunnelType = TunnelType.TUN,
        name: Optional[str] = None,
        mtu: int = 1500,
        address_pool: Optional[IPAddressPool] = None
    ):
        """
        Initialize a new tunnel interface.
        
        Args:
            tunnel_type: Type of the tunnel (TUN or TAP)
            name: Name for the tunnel interface (optional)
            mtu: MTU value for the tunnel interface
            address_pool: IP address pool for assigning addresses
        """
        self.tunnel_type = tunnel_type
        self.name = name
        self.mtu = mtu
        self.fd = None
        self.address_pool = address_pool or IPAddressPool()
        self.running = False
        self.routes = {}
    
    def open(self) -> None:
        """
        Open and configure the tunnel interface.
        Must be implemented by platform-specific subclasses.
        
        Raises:
            NotImplementedError: If the platform doesn't have an implementation
        """
        raise NotImplementedError("Tunnel.open() must be implemented by subclasses")
    
    def close(self) -> None:
        """Close the tunnel interface."""
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None
            self.running = False
            logger.info(f"Tunnel interface {self.name} closed")
    
    def read_packet(self, timeout: Optional[float] = None) -> bytes:
        """
        Read a packet from the tunnel interface.
        
        Args:
            timeout: Read timeout in seconds (None = blocking)
            
        Returns:
            Bytes containing the packet data
            
        Raises:
            TunnelError: If the tunnel is not open or on read error
        """
        if self.fd is None:
            raise TunnelError("Tunnel is not open")
        
        try:
            if timeout is not None:
                ready, _, _ = select.select([self.fd], [], [], timeout)
                if not ready:
                    return b''
            return os.read(self.fd, self.mtu + 64)
        except OSError as e:
            raise TunnelError(f"Error reading from tunnel: {e}")
    
    def write_packet(self, packet: bytes) -> int:
        """
        Write a packet to the tunnel interface.
        
        Args:
            packet: Bytes containing the packet data
            
        Returns:
            Number of bytes written
            
        Raises:
            TunnelError: If the tunnel is not open or on write error
        """
        if self.fd is None:
            raise TunnelError("Tunnel is not open")
        
        try:
            return os.write(self.fd, packet)
        except OSError as e:
            raise TunnelError(f"Error writing to tunnel: {e}")
    
    def add_route(self, network: str, gateway: Optional[str] = None) -> None:
        """
        Add a route to the routing table.
        Must be implemented by platform-specific subclasses.
        
        Args:
            network: Network in CIDR notation
            gateway: Gateway IP address (optional)
            
        Raises:
            NotImplementedError: If the platform doesn't have an implementation
        """
        raise NotImplementedError("Tunnel.add_route() must be implemented by subclasses")
    
    def remove_route(self, network: str) -> None:
        """
        Remove a route from the routing table.
        Must be implemented by platform-specific subclasses.
        
        Args:
            network: Network in CIDR notation
            
        Raises:
            NotImplementedError: If the platform doesn't have an implementation
        """
        raise NotImplementedError("Tunnel.remove_route() must be implemented by subclasses")
    
    def set_up(self) -> None:
        """
        Set the tunnel interface up.
        Must be implemented by platform-specific subclasses.
        
        Raises:
            NotImplementedError: If the platform doesn't have an implementation
        """
        raise NotImplementedError("Tunnel.set_up() must be implemented by subclasses")
    
    def set_down(self) -> None:
        """
        Set the tunnel interface down.
        Must be implemented by platform-specific subclasses.
        
        Raises:
            NotImplementedError: If the platform doesn't have an implementation
        """
        raise NotImplementedError("Tunnel.set_down() must be implemented by subclasses")
    
    def set_mtu(self, mtu: int) -> None:
        """
        Set the MTU for the tunnel interface.
        Must be implemented by platform-specific subclasses.
        
        Args:
            mtu: MTU value to set
            
        Raises:
            NotImplementedError: If the platform doesn't have an implementation
        """
        raise NotImplementedError("Tunnel.set_mtu() must be implemented by subclasses")
    
    def set_ip_address(self, address: str, netmask: str) -> None:
        """
        Set the IP address for the tunnel interface.
        Must be implemented by platform-specific subclasses.
        
        Args:
            address: IP address to set
            netmask: Netmask to set
            
        Raises:
            NotImplementedError: If the platform doesn't have an implementation
        """
        raise NotImplementedError("Tunnel.set_ip_address() must be implemented by subclasses")
    
    def __enter__(self):
        """Context manager entry."""
        self.open()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
    
    @staticmethod
    def create(
        tunnel_type: TunnelType = TunnelType.TUN,
        name: Optional[str] = None,
        mtu: int = 1500,
        address_pool: Optional[IPAddressPool] = None
    ) -> 'Tunnel':
        """
        Factory method to create a platform-specific Tunnel instance.
        
        Args:
            tunnel_type: Type of the tunnel (TUN or TAP)
            name: Name for the tunnel interface (optional)
            mtu: MTU value for the tunnel interface
            address_pool: IP address pool for assigning addresses
            
        Returns:
            A platform-specific Tunnel implementation
            
        Raises:
            TunnelError: If the platform is not supported
        """
        system = platform.system().lower()
        
        if system == 'linux':
            return LinuxTunnel(tunnel_type, name, mtu, address_pool)
        elif system == 'darwin':
            return DarwinTunnel(tunnel_type, name, mtu, address_pool)
        elif system == 'windows':
            return WindowsTunnel(tunnel_type, name, mtu, address_pool)
        else:
            raise TunnelError(f"Unsupported platform: {system}")


class LinuxTunnel(Tunnel):
    """Linux-specific implementation of the Tunnel interface."""
    
    # TUN/TAP device control constants
    TUNSETIFF = 0x400454ca
    IFF_TUN = 0x0001
    IFF_TAP = 0x0002
    IFF_NO_PI = 0x1000
    
    def __init__(
        self,
        tunnel_type: TunnelType = TunnelType.TUN,
        name: Optional[str] = None,
        mtu: int = 1500,
        address_pool: Optional[IPAddressPool] = None
    ):
        """Initialize a new Linux tunnel interface."""
        super().__init__(tunnel_type, name, mtu, address_pool)
        self.tun_device_path = "/dev/net/tun"
    
    def open(self) -> None:
        """
        Open and configure the Linux TUN/TAP interface.
        
        Raises:
            TunnelError: If the tunnel creation fails
        """
        try:
            # Open the TUN/TAP device
            self.fd = os.open(self.tun_device_path, os.O_RDWR)
            
            # Prepare the flag
            if self.tunnel_type == TunnelType.TUN:
                flags = self.IFF_TUN | self.IFF_NO_PI
            else:
                flags = self.IFF_TAP | self.IFF_NO_PI
            
            # Prepare the interface name
            if self.name:
                ifr = struct.pack('16sH', self.name.encode(), flags)
            else:
                ifr = struct.pack('16sH', b'', flags)
            
            # Configure the TUN/TAP device
            ifr = fcntl.ioctl(self.fd, self.TUNSETIFF, ifr)
            
            # Get the interface name
            self.name = ifr[:16].strip(b'\x00').decode()
            
            logger.info(f"Tunnel interface {self.name} created")
            
            # Set MTU and IP address if provided
            self.set_mtu(self.mtu)
            server_ip = self.address_pool.get_server_ip()
            network = str(ipaddress.ip_network(self.address_pool.network.network_address))
            self.set_ip_address(server_ip, str(self.address_pool.network.netmask))
            self.set_up()
            
            self.running = True
        except OSError as e:
            if self.fd is not None:
                os.close(self.fd)
                self.fd = None
            raise TunnelError(f"Failed to create tunnel interface: {e}")
    
    def set_up(self) -> None:
        """Set the Linux tunnel interface up."""
        try:
            subprocess.run(['ip', 'link', 'set', self.name, 'up'], check=True)
            logger.debug(f"Tunnel interface {self.name} set up")
        except subprocess.SubprocessError as e:
            raise TunnelError(f"Failed to set interface up: {e}")
    
    def set_down(self) -> None:
        """Set the Linux tunnel interface down."""
        try:
            subprocess.run(['ip', 'link', 'set', self.name, 'down'], check=True)
            logger.debug(f"Tunnel interface {self.name} set down")
        except subprocess.SubprocessError as e:
            raise TunnelError(f"Failed to set interface down: {e}")
    
    def set_mtu(self, mtu: int) -> None:
        """Set the MTU for the Linux tunnel interface."""
        try:
            subprocess.run(['ip', 'link', 'set', self.name, 'mtu', str(mtu)], check=True)
            self.mtu = mtu
            logger.debug(f"Tunnel interface {self.name} MTU set to {mtu}")
        except subprocess.SubprocessError as e:
            raise TunnelError(f"Failed to set MTU: {e}")
    
    def set_ip_address(self, address: str, netmask: str) -> None:
        """Set the IP address for the Linux tunnel interface."""
        # Convert netmask to CIDR prefix
        prefix_len = sum(bin(int(x)).count('1') for x in netmask.split('.'))
        
        try:
            subprocess.run(['ip', 'addr', 'add', f"{address}/{prefix_len}", 'dev', self.name], check=True)
            logger.debug(f"Tunnel interface {self.name} IP address set to {address}/{prefix_len}")
        except subprocess.SubprocessError as e:
            raise TunnelError(f"Failed to set IP address: {e}")
    
    def add_route(self, network: str, gateway: Optional[str] = None) -> None:
        """Add a route to the Linux routing

