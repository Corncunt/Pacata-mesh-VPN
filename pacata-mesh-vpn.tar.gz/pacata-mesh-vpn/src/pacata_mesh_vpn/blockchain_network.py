"""
Blockchain Network Module

This module provides a high-level interface for integrating the blockchain P2P
functionality with the rest of the Pacata Mesh VPN application. It serves as a
bridge between the blockchain implementation and the VPN components.
"""

import logging
import asyncio
import threading
import time
from typing import Optional, List, Dict, Any, Tuple

from .blockchain import Blockchain, Block, Transaction
from .blockchain import BlockchainP2P, MessageType, ConsensusFactory
from .blockchain import ProofOfWork, ProofOfStake, DelegatedProofOfStake
from .blockchain import PacataWallet
from .networking.dht import DistributedHashTable

logger = logging.getLogger(__name__)

class BlockchainNetwork:
    """
    Integrates the blockchain with the DHT from the networking module and
    provides a high-level interface for the VPN application.
    """
    
    def __init__(self, node_id: str, dht: DistributedHashTable, data_dir: str = "./data", 
                 consensus_type: str = "pow", wallet_path: Optional[str] = None):
        """
        Initialize the blockchain network with the given parameters.
        
        Args:
            node_id: The unique identifier for this node
            dht: The distributed hash table for node discovery
            data_dir: Directory to store blockchain data
            consensus_type: Type of consensus mechanism to use (pow, pos, dpos)
            wallet_path: Path to the wallet file (created if doesn't exist)
        """
        self.node_id = node_id
        self.dht = dht
        self.data_dir = data_dir
        self.consensus_type = consensus_type
        
        # Initialize components
        self.blockchain = Blockchain(data_dir=f"{data_dir}/blockchain")
        
        # Create appropriate consensus mechanism
        consensus_factory = ConsensusFactory()
        self.consensus = consensus_factory.create_consensus(consensus_type, self.blockchain)
        
        # Set the consensus mechanism for the blockchain
        self.blockchain.set_consensus_mechanism(self.consensus)
        
        # Initialize the wallet
        self.wallet = PacataWallet(wallet_path or f"{data_dir}/wallet.json", self.blockchain)
        
        # Initialize P2P network (but don't start it yet)
        self.p2p_network = BlockchainP2P(
            node_id=node_id,
            blockchain=self.blockchain,
            wallet=self.wallet,
            dht=dht,
            consensus=self.consensus
        )
        
        self._running = False
        self._thread = None
        self._lock = threading.RLock()
    
    def start(self) -> None:
        """
        Start the blockchain network.
        
        This method starts the P2P network, synchronizes with other nodes,
        and begins processing transactions and blocks.
        """
        with self._lock:
            if self._running:
                logger.warning("Blockchain network is already running")
                return
                
            logger.info(f"Starting blockchain network with {self.consensus_type} consensus")
            self.p2p_network.start()
            self._running = True
            
            # Start background processing in a separate thread
            self._thread = threading.Thread(
                target=self._run_background_tasks,
                daemon=True,
                name="blockchain-network"
            )
            self._thread.start()
            
            logger.info("Blockchain network started successfully")
    
    def stop(self) -> None:
        """
        Stop the blockchain network.
        
        This method stops the P2P network and saves the blockchain state.
        """
        with self._lock:
            if not self._running:
                logger.warning("Blockchain network is not running")
                return
                
            logger.info("Stopping blockchain network")
            self.p2p_network.stop()
            self._running = False
            
            # Save blockchain state
            self.blockchain.save_to_disk()
            
            # Wait for background thread to finish
            if self._thread:
                self._thread.join(timeout=5.0)
                self._thread = None
                
            logger.info("Blockchain network stopped successfully")
    
    def _run_background_tasks(self) -> None:
        """
        Run background tasks for the blockchain network.
        
        This method runs in a separate thread and handles periodic tasks such as
        synchronization, mining, and transaction processing.
        """
        logger.info("Starting blockchain network background tasks")
        
        while self._running:
            try:
                # Process pending transactions
                self._process_pending_transactions()
                
                # Mine a new block if necessary (based on consensus)
                if self.consensus_type == "pow":
                    self._attempt_mining()
                
                # Sleep to avoid CPU overuse
                time.sleep(5)
                
            except Exception as e:
                logger.error(f"Error in blockchain network background tasks: {e}")
                time.sleep(10)  # Sleep longer on error
    
    def _process_pending_transactions(self) -> None:
        """Process any pending transactions in the mempool."""
        try:
            # Get pending transactions
            pending = self.blockchain.get_pending_transactions()
            if not pending:
                return
                
            logger.info(f"Processing {len(pending)} pending transactions")
            
            # Validate transactions before adding to mempool
            for tx in pending:
                if self.blockchain.validate_transaction(tx):
                    self.p2p_network.broadcast_transaction(tx)
                else:
                    logger.warning(f"Invalid transaction detected: {tx.tx_id}")
        except Exception as e:
            logger.error(f"Error processing pending transactions: {e}")
    
    def _attempt_mining(self) -> None:
        """Attempt to mine a new block if using proof-of-work."""
        try:
            if not self.wallet.addresses:
                logger.warning("No wallet addresses available for mining rewards")
                return
                
            miner_address = self.wallet.addresses[0]
            
            # Check if there are enough transactions to mine a block
            pending = self.blockchain.get_pending_transactions()
            if len(pending) < 1:  # Can adjust this threshold
                return
                
            logger.info(f"Attempting to mine a new block with {len(pending)} transactions")
            
            # Mine the block
            success, new_block = self.blockchain.mine_block(miner_address)
            
            if success and new_block:
                logger.info(f"Successfully mined block #{new_block.index}")
                # Broadcast the new block to the network
                self.p2p_network.broadcast_block(new_block)
        except Exception as e:
            logger.error(f"Error while mining: {e}")
    
    def create_transaction(self, to_address: str, amount: float, fee: float = 0.001) -> Optional[str]:
        """
        Create and broadcast a new transaction.
        
        Args:
            to_address: The recipient's address
            amount: The amount to send
            fee: The transaction fee
            
        Returns:
            The transaction ID if successful, None otherwise
        """
        try:
            if not self.wallet.addresses:
                logger.error("No wallet addresses available to send from")
                return None
                
            from_address = self.wallet.addresses[0]
            
            # Create the transaction
            tx_id = self.wallet.send(from_address, to_address, amount, fee)
            
            if not tx_id:
                logger.error("Failed to create transaction")
                return None
                
            # Get the transaction object
            tx = self.blockchain.get_transaction_by_id(tx_id)
            
            if tx:
                # Broadcast the transaction to the network
                self.p2p_network.broadcast_transaction(tx)
                logger.info(f"Transaction {tx_id} created and broadcasted")
                return tx_id
            else:
                logger.error(f"Transaction {tx_id} created but not found in blockchain")
                return tx_id
        except Exception as e:
            logger.error(f"Error creating transaction: {e}")
            return None
    
    def get_balance(self, address: Optional[str] = None) -> float:
        """
        Get the balance for the given address or the default wallet address.
        
        Args:
            address: The address to check balance for, or None for default
            
        Returns:
            The balance as a float
        """
        if not address and self.wallet.addresses:
            address = self.wallet.addresses[0]
            
        if not address:
            logger.error("No address provided and no default address available")
            return 0.0
            
        return self.blockchain.get_balance(address)
    
    def get_transaction_history(self, address: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get transaction history for the given address or the default wallet address.
        
        Args:
            address: The address to get history for, or None for default
            
        Returns:
            A list of transaction dictionaries
        """
        if not address and self.wallet.addresses:
            address = self.wallet.addresses[0]
            
        if not address:
            logger.error("No address provided and no default address available")
            return []
            
        transactions = self.blockchain.get_transactions_for_address(address)
        
        # Convert to dictionaries for easier handling
        return [
            {
                "tx_id": tx.tx_id,
                "timestamp": tx.timestamp,
                "from_address": tx.from_address,
                "to_address": tx.to_address,
                "amount": tx.amount,
                "fee": tx.fee,
                "signature": tx.signature,
                "is_coinbase": tx.is_coinbase,
                "block_index": tx.block_index if hasattr(tx, 'block_index') else None
            }
            for tx in transactions
        ]
    
    def get_blockchain_status(self) -> Dict[str, Any]:
        """
        Get the current status of the blockchain.
        
        Returns:
            A dictionary with blockchain status information
        """
        chain_length = len(self.blockchain.chain) if hasattr(self.blockchain, 'chain') else 0
        latest_block = self.blockchain.chain[-1] if chain_length > 0 else None
        
        status = {
            "node_id": self.node_id,
            "consensus": self.consensus_type,
            "chain_length": chain_length,
            "connected_peers": len(self.p2p_network.peers) if hasattr(self.p2p_network, 'peers') else 0,
            "pending_transactions": len(self.blockchain.get_pending_transactions()),
            "is_syncing": self.p2p_network.is_syncing if hasattr(self.p2p_network, 'is_syncing') else False,
            "wallet_addresses": self.wallet.addresses,
        }
        
        if latest_block:
            status["latest_block"] = {
                "index": latest_block.index,
                "timestamp": latest_block.timestamp,
                "hash": latest_block.hash,
                "previous_hash": latest_block.previous_hash,
                "transactions": len(latest_block.transactions),
                "difficulty": latest_block.difficulty if hasattr(latest_block, 'difficulty') else None
            }
            
        return status
    
    def create_wallet_address(self) -> Optional[str]:
        """
        Create a new wallet address.
        
        Returns:
            The new address if successful, None otherwise
        """
        try:
            address = self.wallet.create_address()
            logger.info(f"Created new wallet address: {address}")
            return address
        except Exception as e:
            logger.error(f"Error creating wallet address: {e}")
            return None
    
    def import_wallet_key(self, private_key: str) -> Optional[str]:
        """
        Import a wallet using a private key.
        
        Args:
            private_key: The private key to import
            
        Returns:
            The address corresponding to the imported key if successful, None otherwise
        """
        try:
            address = self.wallet.import_key(private_key)
            logger.info(f"Imported wallet address: {address}")
            return address
        except Exception as e:
            logger.error(f"Error importing wallet key: {e}")
            return None
    
    @property
    def is_running(self) -> bool:
        """Check if the blockchain network is running."""
        return self._running


# Example usage of the BlockchainNetwork class
def example_usage():
    # Import required modules
    import time
    from .networking.dht import DistributedHashTable
    
    # Initialize DHT
    dht = DistributedHashTable(node_id="example_node_1", bootstrap_nodes=[])
    
    # Create blockchain network
    network = BlockchainNetwork(
        node_id="example_node_1",
        dht=dht,
        data_dir="./data",
        consensus_type="pow"
    )
    
    try:
        # Start the network
        network.start()
        
        # Create a new wallet address if none exists
        if not network.wallet.addresses:
            address = network.create_wallet_address()
            print(f"Created new wallet address: {address}")
        else:
            address = network.wallet.addresses[0]
            print(f"Using existing wallet address: {address}")
        
        # Get blockchain status
        status = network.get_blockchain_status()
        print("Blockchain Status:")
        for key, value in status.items():
            print(f"  {key}: {value}")
        
        # Mine some initial coins (if using PoW)
        if network.consensus_type == "pow":
            print("Mining initial blocks...")
            time.sleep(60)  # Wait for mining to occur
        
        # Check balance
        balance = network.get_balance(address)
        print(f"Balance for {address}: {balance}")
        
        # Create and broadcast a transaction (if we have funds)
        if balance > 1.0:
            recipient = "example_recipient_address"
            tx_id = network.create_transaction(to_address=recipient, amount=1.0)
            if tx_id:
                print(f"Transaction created: {tx_id}")
            else:
                print("Failed to create transaction")
        
        # Get transaction history
        history = network.get_transaction_history(address)
        print(f"Transaction history for {address}:")
        for tx in history:
            print(f"  {tx['tx_id']}: {tx['amount']} from {tx['from_address']} to {tx['to_address']}")
        
        # Keep the network running for a while
        print("Blockchain network running. Press Ctrl+C to stop.")
        while True:
            time.sleep(10)
            status = network.get_blockchain_status()
            print(f"Chain length: {status['chain_length']}, Peers: {status['connected_peers']}")
    
    except KeyboardInterrupt:
        print("Stopping blockchain network...")
    finally:
        # Stop the network
        network.stop()
        print("Blockchain network stopped")


if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler("blockchain_network.log")
        ]
    )
    
    # Run the example usage function
    example_usage()
