"""
Base Smart Contract Implementation

This module defines the foundation classes for all smart contracts in the system.
It provides the base SmartContract class that all specific contract types will inherit from
and the ContractState enum to track contract lifecycle.
"""

import enum
import uuid
import json
import time
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field


class ContractState(enum.Enum):
    """Enum representing the possible states of a smart contract."""
    DRAFT = "draft"              # Initial state, contract is being defined
    PENDING = "pending"          # Contract is waiting for activation conditions
    ACTIVE = "active"            # Contract is active and enforceable
    COMPLETED = "completed"      # Contract has been fulfilled
    CANCELLED = "cancelled"      # Contract was terminated before completion
    FAILED = "failed"            # Contract execution failed


class SmartContract:
    """
    Base class for all smart contracts in the system.
    
    This class provides the core functionality that all contracts will share,
    including state management, validation, and execution frameworks.
    """
    
    def __init__(self, 
                 owner_id: str,
                 name: str = "",
                 description: str = "",
                 contract_id: Optional[str] = None,
                 state: ContractState = ContractState.DRAFT,
                 metadata: Optional[Dict[str, Any]] = None):
        """
        Initialize a new smart contract.
        
        Args:
            owner_id: The ID of the wallet/entity that created this contract
            name: Human-readable name for the contract
            description: Detailed description of the contract purpose
            contract_id: Unique identifier for the contract (generated if None)
            state: Initial state of the contract
            metadata: Additional contract-specific metadata
        """
        self.contract_id = contract_id or str(uuid.uuid4())
        self.owner_id = owner_id
        self.name = name
        self.description = description
        self.state = state
        self.metadata = metadata or {}
        self.created_at = time.time()
        self.updated_at = self.created_at
        self.activated_at = None
        self.completed_at = None
        self.parties = [owner_id]  # List of parties involved in the contract
        self.signatures = {}       # Map of party_id -> signature
        self.history = [{
            "timestamp": self.created_at,
            "state": self.state.value,
            "action": "contract_created",
            "actor": self.owner_id
        }]
    
    def validate(self) -> bool:
        """
        Validate that the contract is properly formed and ready for deployment.
        
        Returns:
            bool: True if the contract is valid, False otherwise
        """
        # Base validation logic
        if not self.owner_id:
            return False
        
        if not self.contract_id:
            return False
            
        # Additional validation should be implemented by subclasses
        return True
    
    def can_activate(self) -> bool:
        """
        Check if the contract can be activated.
        
        Returns:
            bool: True if the contract can be activated, False otherwise
        """
        # Basic activation condition - must be in PENDING state
        if self.state != ContractState.PENDING:
            return False
            
        # Check if all required parties have signed
        return all(party_id in self.signatures for party_id in self.parties)
    
    def activate(self) -> bool:
        """
        Activate the contract if it's in PENDING state and all conditions are met.
        
        Returns:
            bool: True if activation was successful, False otherwise
        """
        if not self.can_activate():
            return False
            
        self.state = ContractState.ACTIVE
        self.activated_at = time.time()
        self.updated_at = self.activated_at
        self._add_history_entry("contract_activated", self.owner_id)
        return True
    
    def execute(self, *args, **kwargs) -> bool:
        """
        Execute the contract logic.
        
        This method should be overridden by concrete contract implementations.
        
        Returns:
            bool: True if execution was successful, False otherwise
        """
        # Default implementation does nothing
        return True
    
    def complete(self) -> bool:
        """
        Mark the contract as completed.
        
        Returns:
            bool: True if the contract was successfully completed, False otherwise
        """
        if self.state != ContractState.ACTIVE:
            return False
            
        self.state = ContractState.COMPLETED
        self.completed_at = time.time()
        self.updated_at = self.completed_at
        self._add_history_entry("contract_completed", self.owner_id)
        return True
    
    def cancel(self, reason: str = "", actor_id: Optional[str] = None) -> bool:
        """
        Cancel the contract.
        
        Args:
            reason: The reason for cancellation
            actor_id: ID of the party initiating the cancellation
            
        Returns:
            bool: True if the contract was successfully cancelled, False otherwise
        """
        # Can only cancel contracts that aren't already completed or cancelled
        if self.state in (ContractState.COMPLETED, ContractState.CANCELLED, ContractState.FAILED):
            return False
            
        self.state = ContractState.CANCELLED
        self.updated_at = time.time()
        self.metadata["cancellation_reason"] = reason
        
        actor = actor_id or self.owner_id
        self._add_history_entry("contract_cancelled", actor, {"reason": reason})
        return True
    
    def fail(self, error_message: str, actor_id: Optional[str] = None) -> bool:
        """
        Mark the contract as failed.
        
        Args:
            error_message: Description of the failure
            actor_id: ID of the party reporting the failure
            
        Returns:
            bool: True if the contract was successfully marked as failed, False otherwise
        """
        if self.state in (ContractState.COMPLETED, ContractState.CANCELLED, ContractState.FAILED):
            return False
            
        self.state = ContractState.FAILED
        self.updated_at = time.time()
        self.metadata["failure_reason"] = error_message
        
        actor = actor_id or self.owner_id
        self._add_history_entry("contract_failed", actor, {"error": error_message})
        return True
    
    def add_party(self, party_id: str) -> bool:
        """
        Add a party to the contract.
        
        Args:
            party_id: ID of the party to add
            
        Returns:
            bool: True if the party was successfully added, False otherwise
        """
        if party_id in self.parties:
            return False
            
        if self.state != ContractState.DRAFT:
            return False
            
        self.parties.append(party_id)
        self.updated_at = time.time()
        self._add_history_entry("party_added", self.owner_id, {"party_id": party_id})
        return True
    
    def sign(self, party_id: str, signature: str) -> bool:
        """
        Record a signature for a party.
        
        Args:
            party_id: ID of the signing party
            signature: Cryptographic signature of the party
            
        Returns:
            bool: True if the signature was successfully recorded, False otherwise
        """
        if party_id not in self.parties:
            return False
            
        if party_id in self.signatures:
            return False
            
        if self.state not in (ContractState.DRAFT, ContractState.PENDING):
            return False
            
        self.signatures[party_id] = signature
        self.updated_at = time.time()
        
        if self.state == ContractState.DRAFT and len(self.signatures) == len(self.parties):
            self.state = ContractState.PENDING
            
        self._add_history_entry("contract_signed", party_id)
        return True
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the contract to a dictionary representation.
        
        Returns:
            Dict[str, Any]: Dictionary representation of the contract
        """
        return {
            "contract_id": self.contract_id,
            "owner_id": self.owner_id,
            "name": self.name,
            "description": self.description,
            "state": self.state.value,
            "metadata": self.metadata,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "activated_at": self.activated_at,
            "completed_at": self.completed_at,
            "parties": self.parties,
            "signatures": self.signatures,
            "history": self.history,
        }
    
    def to_json(self) -> str:
        """
        Convert the contract to a JSON string.
        
        Returns:
            str: JSON representation of the contract
        """
        return json.dumps(self.to_dict())
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SmartContract':
        """
        Create a contract instance from a dictionary.
        
        Args:
            data: Dictionary containing contract data
            
        Returns:
            SmartContract: A new contract instance
        """
        contract = cls(
            owner_id=data["owner_id"],
            name=data.get("name", ""),
            description=data.get("description", ""),
            contract_id=data["contract_id"],
            state=ContractState(data["state"]),
            metadata=data.get("metadata", {})
        )
        contract.created_at = data.get("created_at", time.time())
        contract.updated_at = data.get("updated_at", contract.created_at)
        contract.activated_at = data.get("activated_at")
        contract.completed_at = data.get("completed_at")
        contract.parties = data.get("parties", [contract.owner_id])
        contract.signatures = data.get("signatures", {})
        contract.history = data.get("history", [])
        return contract
    
    @classmethod
    def from_json(cls, json_str: str) -> 'SmartContract':
        """
        Create a contract instance from a JSON string.
        
        Args:
            json_str: JSON string containing contract data
            
        Returns:
            SmartContract: A new contract instance
        """
        data = json.loads(json_str)
        return cls.from_dict(data)
    
    def _add_history_entry(self, action: str, actor: str, details: Dict[str, Any] = None):
        """
        Add an entry to the contract history.
        
        Args:
            action: The action that occurred
            actor: ID of the actor who performed the action
            details: Additional details about the action
        """
        entry = {
            "timestamp": time.time(),
            "state": self.state.value,
            "action": action,
            "actor": actor
        }
        
        if details:
            entry["details"] = details
            
        self.history.append(entry)

