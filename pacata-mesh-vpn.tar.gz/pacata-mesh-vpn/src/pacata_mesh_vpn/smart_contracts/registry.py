import json
import uuid
import logging
from typing import Dict, List, Optional, Any, Type
from datetime import datetime

from .base_contract import SmartContract, ContractState

logger = logging.getLogger(__name__)

class ContractRegistry:
    """
    A registry for managing smart contracts in the system.
    
    The ContractRegistry is responsible for:
    - Creating new smart contracts
    - Storing contract state
    - Retrieving contracts by ID or other criteria
    - Managing contract lifecycle (activation, suspension, termination)
    - Persisting contracts to storage
    """
    
    def __init__(self, storage_path: str = 'contracts.json'):
        """
        Initialize a new contract registry.
        
        Args:
            storage_path: Path to the file where contracts will be persisted
        """
        self.storage_path = storage_path
        self._contracts: Dict[str, SmartContract] = {}
        self._load_contracts()
    
    def _load_contracts(self) -> None:
        """Load contracts from persistent storage."""
        try:
            with open(self.storage_path, 'r') as f:
                contract_data = json.load(f)
                
            for contract_id, data in contract_data.items():
                # The actual implementation would need to reconstruct
                # specific contract types based on the stored data
                contract_class = self._get_contract_class(data.get('type', ''))
                if contract_class:
                    self._contracts[contract_id] = contract_class.from_dict(data)
                    
            logger.info(f"Loaded {len(self._contracts)} contracts from {self.storage_path}")
        except FileNotFoundError:
            logger.info(f"No contract storage found at {self.storage_path}")
        except Exception as e:
            logger.error(f"Error loading contracts: {e}")
    
    def _save_contracts(self) -> None:
        """Save contracts to persistent storage."""
        try:
            contract_data = {
                contract_id: contract.to_dict()
                for contract_id, contract in self._contracts.items()
            }
            
            with open(self.storage_path, 'w') as f:
                json.dump(contract_data, f, indent=2)
                
            logger.info(f"Saved {len(self._contracts)} contracts to {self.storage_path}")
        except Exception as e:
            logger.error(f"Error saving contracts: {e}")
    
    def _get_contract_class(self, contract_type: str) -> Optional[Type[SmartContract]]:
        """
        Get the contract class based on the contract type.
        
        This would be extended as more contract types are added.
        
        Args:
            contract_type: The type identifier for the contract
            
        Returns:
            The contract class or None if not found
        """
        # This will be populated with actual contract classes as they're implemented
        contract_classes = {
            # Example: 'bandwidth_sharing': BandwidthSharingContract,
            # Example: 'node_reputation': NodeReputationContract,
        }
        return contract_classes.get(contract_type)
    
    def create_contract(self, contract_type: str, **kwargs) -> Optional[str]:
        """
        Create a new contract of the specified type.
        
        Args:
            contract_type: The type of contract to create
            **kwargs: Contract-specific parameters
            
        Returns:
            The ID of the created contract, or None if creation failed
        """
        contract_class = self._get_contract_class(contract_type)
        if not contract_class:
            logger.error(f"Unknown contract type: {contract_type}")
            return None
        
        try:
            contract_id = str(uuid.uuid4())
            contract = contract_class(
                contract_id=contract_id,
                created_at=datetime.utcnow(),
                **kwargs
            )
            self._contracts[contract_id] = contract
            self._save_contracts()
            logger.info(f"Created contract {contract_id} of type {contract_type}")
            return contract_id
        except Exception as e:
            logger.error(f"Error creating contract: {e}")
            return None
    
    def get_contract(self, contract_id: str) -> Optional[SmartContract]:
        """
        Retrieve a contract by its ID.
        
        Args:
            contract_id: The ID of the contract to retrieve
            
        Returns:
            The contract, or None if not found
        """
        return self._contracts.get(contract_id)
    
    def get_contracts_by_state(self, state: ContractState) -> List[SmartContract]:
        """
        Get all contracts with the specified state.
        
        Args:
            state: The contract state to filter by
            
        Returns:
            A list of contracts in the specified state
        """
        return [
            contract for contract in self._contracts.values()
            if contract.state == state
        ]
    
    def get_contracts_by_owner(self, owner_id: str) -> List[SmartContract]:
        """
        Get all contracts owned by the specified entity.
        
        Args:
            owner_id: The ID of the owner (wallet address, node ID, etc.)
            
        Returns:
            A list of contracts owned by the specified entity
        """
        return [
            contract for contract in self._contracts.values()
            if contract.owner_id == owner_id
        ]
    
    def activate_contract(self, contract_id: str) -> bool:
        """
        Activate a contract.
        
        Args:
            contract_id: The ID of the contract to activate
            
        Returns:
            True if activation was successful, False otherwise
        """
        contract = self.get_contract(contract_id)
        if not contract:
            logger.error(f"Contract not found: {contract_id}")
            return False
        
        try:
            if contract.activate():
                self._save_contracts()
                logger.info(f"Activated contract {contract_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error activating contract {contract_id}: {e}")
            return False
    
    def suspend_contract(self, contract_id: str) -> bool:
        """
        Suspend a contract.
        
        Args:
            contract_id: The ID of the contract to suspend
            
        Returns:
            True if suspension was successful, False otherwise
        """
        contract = self.get_contract(contract_id)
        if not contract:
            logger.error(f"Contract not found: {contract_id}")
            return False
        
        try:
            if contract.suspend():
                self._save_contracts()
                logger.info(f"Suspended contract {contract_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error suspending contract {contract_id}: {e}")
            return False
    
    def terminate_contract(self, contract_id: str) -> bool:
        """
        Terminate a contract.
        
        Args:
            contract_id: The ID of the contract to terminate
            
        Returns:
            True if termination was successful, False otherwise
        """
        contract = self.get_contract(contract_id)
        if not contract:
            logger.error(f"Contract not found: {contract_id}")
            return False
        
        try:
            if contract.terminate():
                self._save_contracts()
                logger.info(f"Terminated contract {contract_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error terminating contract {contract_id}: {e}")
            return False
    
    def execute_contract_method(self, contract_id: str, method_name: str, **kwargs) -> Any:
        """
        Execute a method on a contract.
        
        Args:
            contract_id: The ID of the contract
            method_name: The name of the method to execute
            **kwargs: Method-specific parameters
            
        Returns:
            The result of the method execution, or None if execution failed
        """
        contract = self.get_contract(contract_id)
        if not contract:
            logger.error(f"Contract not found: {contract_id}")
            return None
        
        try:
            method = getattr(contract, method_name, None)
            if not method or not callable(method):
                logger.error(f"Method {method_name} not found on contract {contract_id}")
                return None
            
            result = method(**kwargs)
            self._save_contracts()  # Save any state changes
            return result
        except Exception as e:
            logger.error(f"Error executing method {method_name} on contract {contract_id}: {e}")
            return None

