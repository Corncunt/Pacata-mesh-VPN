#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Contract execution engine for Pacata Mesh VPN smart contracts.
This module provides the core execution environment for running smart contracts
and validating their results before committing them to the blockchain.
"""

import logging
import time
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union
import json

from .base_contract import SmartContract, ContractState
from ..blockchain.blockchain import Transaction
from ..security.validation import validate_data_structure

# Set up logging
logger = logging.getLogger(__name__)


class ExecutionStatus(Enum):
    """Status of smart contract execution."""
    SUCCESS = "success"
    FAILURE = "failure"
    REVERTED = "reverted"
    PENDING = "pending"
    TIMEOUT = "timeout"
    INVALID = "invalid"


class ExecutionResult:
    """
    Stores the result of a smart contract execution.
    
    This includes the execution status, return values, gas used,
    any state changes, and errors that occurred during execution.
    """
    
    def __init__(self, 
                 contract_id: str, 
                 status: ExecutionStatus = ExecutionStatus.PENDING,
                 return_value: Any = None,
                 gas_used: int = 0,
                 state_changes: Dict[str, Any] = None,
                 error: Optional[str] = None,
                 transaction_hash: Optional[str] = None):
        """
        Initialize an execution result.
        
        Args:
            contract_id: Unique identifier of the executed contract
            status: Execution status (SUCCESS, FAILURE, etc.)
            return_value: Value returned by the contract execution
            gas_used: Amount of computational resources used
            state_changes: Dictionary of changes to be applied to the contract state
            error: Error message if execution failed
            transaction_hash: Hash of the transaction if the execution was successful
        """
        self.contract_id = contract_id
        self.status = status
        self.return_value = return_value
        self.gas_used = gas_used
        self.state_changes = state_changes or {}
        self.error = error
        self.transaction_hash = transaction_hash
        self.execution_time = time.time()
    
    def is_successful(self) -> bool:
        """Check if execution was successful."""
        return self.status == ExecutionStatus.SUCCESS
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary format for storage or transmission."""
        return {
            "contract_id": self.contract_id,
            "status": self.status.value,
            "return_value": self.return_value,
            "gas_used": self.gas_used,
            "state_changes": self.state_changes,
            "error": self.error,
            "transaction_hash": self.transaction_hash,
            "execution_time": self.execution_time
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ExecutionResult':
        """Create an ExecutionResult instance from a dictionary."""
        return cls(
            contract_id=data["contract_id"],
            status=ExecutionStatus(data["status"]),
            return_value=data["return_value"],
            gas_used=data["gas_used"],
            state_changes=data["state_changes"],
            error=data["error"],
            transaction_hash=data["transaction_hash"]
        )
    
    def __str__(self) -> str:
        """String representation of the execution result."""
        if self.is_successful():
            return f"ExecutionResult: SUCCESS for contract {self.contract_id}, gas used: {self.gas_used}"
        return f"ExecutionResult: {self.status.value} for contract {self.contract_id}, error: {self.error}"


class ContractEngine:
    """
    Engine for executing and validating smart contracts.
    
    This class provides a secure environment for contract execution,
    handles resource limitations, validates inputs/outputs, and
    produces execution results.
    """
    
    # Maximum gas allowed for a single contract execution
    MAX_GAS_LIMIT = 10000
    
    # Maximum execution time in seconds
    EXECUTION_TIMEOUT = 5.0
    
    def __init__(self, 
                 gas_limit: int = MAX_GAS_LIMIT,
                 timeout: float = EXECUTION_TIMEOUT,
                 security_level: str = "high"):
        """
        Initialize the contract engine.
        
        Args:
            gas_limit: Maximum gas allowed for contract execution
            timeout: Maximum execution time in seconds
            security_level: Security level (low, medium, high)
        """
        self.gas_limit = gas_limit
        self.timeout = timeout
        self.security_level = security_level
        self.execution_count = 0
        logger.info(f"ContractEngine initialized with gas_limit={gas_limit}, timeout={timeout}s")
    
    def execute(self, 
                contract: SmartContract, 
                method: str, 
                params: Dict[str, Any],
                sender: str,
                gas_limit: Optional[int] = None) -> ExecutionResult:
        """
        Execute a smart contract method with the given parameters.
        
        Args:
            contract: The smart contract to execute
            method: Name of the method to call
            params: Parameters to pass to the method
            sender: Address of the caller
            gas_limit: Optional gas limit override for this execution
            
        Returns:
            ExecutionResult object containing the result of execution
        """
        if contract.state != ContractState.ACTIVE:
            return ExecutionResult(
                contract_id=contract.contract_id,
                status=ExecutionStatus.INVALID,
                error=f"Contract is not in active state: {contract.state.value}"
            )
        
        if gas_limit is None:
            gas_limit = self.gas_limit
            
        # Validate method exists
        if not hasattr(contract, method) or not callable(getattr(contract, method)):
            return ExecutionResult(
                contract_id=contract.contract_id,
                status=ExecutionStatus.INVALID,
                error=f"Method '{method}' not found in contract"
            )
        
        # Validate parameters
        try:
            self._validate_params(contract, method, params)
        except ValueError as e:
            return ExecutionResult(
                contract_id=contract.contract_id,
                status=ExecutionStatus.INVALID,
                error=f"Invalid parameters: {str(e)}"
            )
        
        # Set up execution context
        gas_used = 0
        start_time = time.time()
        self.execution_count += 1
        execution_id = f"{contract.contract_id}_{self.execution_count}_{int(start_time)}"
        
        # Create a safe execution environment
        try:
            # Get the method to call
            method_to_call = getattr(contract, method)
            
            # Execute the contract method with timeout
            result = self._execute_with_timeout(
                method_to_call, 
                params, 
                sender, 
                gas_limit, 
                start_time
            )
            
            # Calculate gas used (simplified model)
            end_time = time.time()
            execution_time = end_time - start_time
            gas_used = int(execution_time * 100) + len(json.dumps(params)) * 2
            
            if result.get("status") == "error":
                return ExecutionResult(
                    contract_id=contract.contract_id,
                    status=ExecutionStatus.FAILURE,
                    error=result.get("error", "Unknown error"),
                    gas_used=gas_used
                )
            
            # Validate the result
            state_changes = result.get("state_changes", {})
            return_value = result.get("return_value")
            
            # Generate a transaction hash for the execution
            tx_hash = self._generate_transaction_hash(contract, method, params, sender, return_value)
            
            return ExecutionResult(
                contract_id=contract.contract_id,
                status=ExecutionStatus.SUCCESS,
                return_value=return_value,
                gas_used=gas_used,
                state_changes=state_changes,
                transaction_hash=tx_hash
            )
            
        except Exception as e:
            logger.error(f"Error executing contract {contract.contract_id}.{method}: {str(e)}")
            return ExecutionResult(
                contract_id=contract.contract_id,
                status=ExecutionStatus.FAILURE,
                error=str(e),
                gas_used=gas_used
            )
    
    def _execute_with_timeout(self, 
                              method, 
                              params: Dict[str, Any],
                              sender: str,
                              gas_limit: int,
                              start_time: float) -> Dict[str, Any]:
        """
        Execute a contract method with a timeout.
        
        Args:
            method: Method to call
            params: Parameters to pass
            sender: Address of the caller
            gas_limit: Gas limit for execution
            start_time: Time when execution started
            
        Returns:
            Dictionary with execution results
        """
        # In a production system, this would use threading or multiprocessing
        # with proper timeout handling. For simplicity, we'll check time manually.
        try:
            # Add sender to the execution context
            context = {"sender": sender, "gas_limit": gas_limit}
            
            # Call the method with params and context
            if hasattr(method, "__code__") and "context" in method.__code__.co_varnames:
                result = method(params=params, context=context)
            else:
                result = method(**params)
            
            # Check if we exceeded timeout
            if time.time() - start_time > self.timeout:
                return {"status": "error", "error": "Execution timeout"}
            
            # Format the result
            if isinstance(result, dict) and "status" in result:
                return result
            
            # If the result is not a formatted dict, wrap it
            return {
                "status": "success",
                "return_value": result,
                "state_changes": {}  # No state changes reported
            }
            
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def _validate_params(self, contract: SmartContract, method: str, params: Dict[str, Any]) -> None:
        """
        Validate that the parameters match what the contract method expects.
        
        Args:
            contract: The contract to validate against
            method: The method name
            params: Parameters to validate
            
        Raises:
            ValueError: If parameters are invalid
        """
        method_obj = getattr(contract, method)
        
        # Check if the contract has a validation method
        if hasattr(contract, f"validate_{method}_params"):
            validator = getattr(contract, f"validate_{method}_params")
            validator(params)
            return
        
        # Basic validation based on function signature
        import inspect
        sig = inspect.signature(method_obj)
        
        # If the method accepts **kwargs or a 'params' parameter, accept any parameters
        for param in sig.parameters.values():
            if (param.kind == inspect.Parameter.VAR_KEYWORD or 
                param.name == "params"):
                return
        
        # Check that all required parameters are provided
        for param_name, param in sig.parameters.items():
            if param_name in ("self", "context"):
                continue
                
            if param.default == inspect.Parameter.empty and param_name not in params:
                raise ValueError(f"Required parameter '{param_name}' not provided")
    
    def _generate_transaction_hash(self, 
                                  contract: SmartContract,
                                  method: str,
                                  params: Dict[str, Any],
                                  sender: str,
                                  result: Any) -> str:
        """
        Generate a hash for the transaction.
        
        Args:
            contract: The executed contract
            method: Method that was called
            params: Parameters that were passed
            sender: Address of the caller
            result: Result of the execution
            
        Returns:
            Transaction hash string
        """
        import hashlib
        
        # Create a string representation of all inputs
        data = {
            "contract_id": contract.contract_id,
            "method": method,
            "params": params,
            "sender": sender,
            "result": result,
            "timestamp": time.time()
        }
        
        # Convert to JSON and hash
        json_data = json.dumps(data, sort_keys=True)
        return hashlib.sha256(json_data.encode()).hexdigest()
    
    def verify_execution(self, execution_result: ExecutionResult) -> bool:
        """
        Verify that an execution result is valid and has not been tampered with.
        
        Args:
            execution_result: The execution result to verify
            
        Returns:
            True if valid, False otherwise
        """
        # In a real implementation, this would validate against blockchain state
        # and verify cryptographic proofs. For now, we'll just do basic checks.
        
        if not execution_result.is_successful():
            return False
            
        # Check if the transaction hash exists
        if not execution_result.transaction_hash:
            return False
            
        # Verify the hash format (simple check)
        if not (len(execution_result.transaction_hash) == 64 and 
                all(c in "0123456789abcdef" for c in execution_result.transaction_hash)):
            return False
            
        return True
    
    def prepare_transaction(self, 
                           execution_result: ExecutionResult, 
                           fee: float = 0.001) -> Optional[Transaction]:
        """
        Prepare a blockchain transaction from a successful execution result.
        
        Args:
            execution_result: The successful execution result
            fee: Transaction fee
            
        Returns:
            Transaction object or None if the result is not valid
        """
        if not self.verify_execution(execution_result):
            return None
            
        # In a real implementation, this would create a proper blockchain
        # transaction with appropriate signatures and data structure
        # For now, we'll create a simplified version
        
        # This is a placeholder - actual implementation would depend on the
        # blockchain Transaction class implementation
        transaction_data = {
            "contract_id": execution_result.contract_id,
            "state_changes": execution_result.state_changes,
            "result": execution_result.return_value,
            "gas_used": execution_result.gas_used,
            "timestamp": execution_result.execution_time
        }
        
        # This is placeholder code - update based on actual Transaction class
        transaction = Transaction(
            sender="contract_engine",
            recipient=execution_result.contract_id, 
            amount=0.0,  # No value transfer
            data=json.dumps(transaction_data),
            fee=fee
        )
        
        return transaction

