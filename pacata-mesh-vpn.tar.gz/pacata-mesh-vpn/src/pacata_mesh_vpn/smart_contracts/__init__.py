"""
Smart Contracts Package

This package contains the implementation of smart contracts for the Pacata Mesh VPN
blockchain integration. It provides the base contract infrastructure, contract execution
engine, and specialized VPN-related contracts.
"""

# These imports will be enabled as the respective modules are implemented
# Base contract infrastructure
from .base_contract import SmartContract, ContractState

# Contract management
from .registry import ContractRegistry

# Contract execution
from .engine import ContractEngine, ExecutionResult

# VPN-specific contract types
from .bandwidth_contract import BandwidthSharingContract
from .reputation_contract import NodeReputationContract
from .payment_contract import TokenPaymentContract

# Contract type identifiers
BANDWIDTH_SHARING_CONTRACT = "BANDWIDTH_SHARING"
NODE_REPUTATION_CONTRACT = "NODE_REPUTATION"
TOKEN_PAYMENT_CONTRACT = "TOKEN_PAYMENT"

def register_contracts(registry: ContractRegistry) -> None:
    """
    Register all available smart contract types with the contract registry.
    
    This function should be called after creating a ContractRegistry instance
    to ensure all contract types are properly registered and available for use.
    
    Args:
        registry: The ContractRegistry instance to register contracts with
    """
    # Access the private attribute directly for registration
    # In a production system, the registry would provide a proper registration method
    contract_classes = {
        BANDWIDTH_SHARING_CONTRACT: BandwidthSharingContract,
        NODE_REPUTATION_CONTRACT: NodeReputationContract,
        TOKEN_PAYMENT_CONTRACT: TokenPaymentContract,
    }
    
    # Update the registry's contract classes
    registry._get_contract_class.__globals__['contract_classes'] = contract_classes

__all__ = [
    # Base infrastructure
    'SmartContract',
    'ContractState',
    
    # Contract management
    'ContractRegistry',
    'register_contracts',
    
    # Execution
    'ContractEngine',
    'ExecutionResult',
    
    # VPN-specific contracts
    'BandwidthSharingContract',
    'NodeReputationContract',
    'TokenPaymentContract',
    
    # Contract type identifiers
    'BANDWIDTH_SHARING_CONTRACT',
    'NODE_REPUTATION_CONTRACT',
    'TOKEN_PAYMENT_CONTRACT',
]


