import json
import time
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any

from .base_contract import SmartContract, ContractState


class ReputationFactor(Enum):
    """Enum representing different factors that contribute to a node's reputation."""
    UPTIME = "uptime"
    BANDWIDTH_QUALITY = "bandwidth_quality"
    LATENCY = "latency"
    SECURITY = "security"
    RELIABILITY = "reliability"
    HONEST_REPORTING = "honest_reporting"


class NodeReputationContract(SmartContract):
    """
    Smart contract for tracking and managing VPN node reputation.
    
    This contract maintains reputation scores for VPN nodes based on
    various performance and security factors. Higher reputation scores
    increase the node's chances of being selected for VPN connections
    and may result in higher token rewards.
    """
    
    def __init__(self, contract_id: str, owner_address: str, node_address: str):
        """
        Initialize a new reputation contract for a specific node.
        
        Args:
            contract_id: Unique identifier for this contract.
            owner_address: Blockchain address of the contract owner.
            node_address: Address of the VPN node this contract tracks.
        """
        super().__init__(contract_id, owner_address)
        self.node_address = node_address
        self.total_score = 0.0
        self.factor_scores = {factor: 0.0 for factor in ReputationFactor}
        self.factor_weights = {
            ReputationFactor.UPTIME: 0.25,
            ReputationFactor.BANDWIDTH_QUALITY: 0.20,
            ReputationFactor.LATENCY: 0.15,
            ReputationFactor.SECURITY: 0.25,
            ReputationFactor.RELIABILITY: 0.10,
            ReputationFactor.HONEST_REPORTING: 0.05
        }
        self.history = []
        self.last_update = time.time()
        
    def update_reputation(self, factor: ReputationFactor, score: float, 
                          reporter_address: str, evidence: Optional[Dict] = None) -> bool:
        """
        Update the reputation score for a specific factor.
        
        Args:
            factor: The reputation factor being updated.
            score: The new score (0.0 to 10.0) for this factor.
            reporter_address: Address of the entity reporting this score.
            evidence: Optional evidence supporting the reputation update.
            
        Returns:
            True if the update was successful, False otherwise.
        """
        if self.state != ContractState.ACTIVE:
            return False
            
        if score < 0.0 or score > 10.0:
            return False
            
        # Record this update in history
        update_record = {
            "timestamp": datetime.utcnow().isoformat(),
            "factor": factor.value,
            "previous_score": self.factor_scores[factor],
            "new_score": score,
            "reporter": reporter_address,
            "evidence": evidence or {}
        }
        self.history.append(update_record)
        
        # Update the score for this factor
        self.factor_scores[factor] = score
        
        # Recalculate total score
        self._recalculate_total_score()
        
        self.last_update = time.time()
        return True
    
    def _recalculate_total_score(self) -> None:
        """
        Recalculate the total reputation score based on weighted factor scores.
        """
        self.total_score = sum(
            self.factor_scores[factor] * self.factor_weights[factor]
            for factor in ReputationFactor
        )
    
    def get_reputation_score(self) -> float:
        """
        Get the current total reputation score for the node.
        
        Returns:
            The total weighted reputation score from 0.0 to 10.0.
        """
        return self.total_score
    
    def get_factor_score(self, factor: ReputationFactor) -> float:
        """
        Get the current score for a specific reputation factor.
        
        Args:
            factor: The reputation factor to query.
            
        Returns:
            The score for the specified factor from 0.0 to 10.0.
        """
        return self.factor_scores[factor]
    
    def update_factor_weight(self, factor: ReputationFactor, weight: float) -> bool:
        """
        Update the weight of a specific reputation factor.
        Only the contract owner can update weights.
        
        Args:
            factor: The reputation factor whose weight should be updated.
            weight: The new weight (0.0 to 1.0) for this factor.
            
        Returns:
            True if the update was successful, False otherwise.
        """
        if self.state != ContractState.ACTIVE:
            return False
            
        if weight < 0.0 or weight > 1.0:
            return False
        
        # Adjust other weights to ensure total remains 1.0
        total_weight = sum(self.factor_weights.values())
        current_weight = self.factor_weights[factor]
        difference = weight - current_weight
        
        # If we're increasing this weight, decrease others proportionally
        if difference > 0:
            for f in ReputationFactor:
                if f != factor:
                    adjustment = (self.factor_weights[f] / (total_weight - current_weight)) * difference
                    self.factor_weights[f] -= adjustment
        # If we're decreasing this weight, increase others proportionally
        elif difference < 0:
            for f in ReputationFactor:
                if f != factor:
                    adjustment = (self.factor_weights[f] / (total_weight - current_weight)) * abs(difference)
                    self.factor_weights[f] += adjustment
        
        self.factor_weights[factor] = weight
        self._recalculate_total_score()
        return True
    
    def get_reputation_history(self, limit: Optional[int] = None) -> List[Dict]:
        """
        Get the reputation update history for the node.
        
        Args:
            limit: Optional limit on the number of history entries to return.
            
        Returns:
            A list of reputation update records.
        """
        if limit:
            return self.history[-limit:]
        return self.history
    
    def serialize(self) -> Dict[str, Any]:
        """
        Serialize the contract state to a dictionary.
        
        Returns:
            A dictionary containing all contract data.
        """
        data = super().serialize()
        data.update({
            "node_address": self.node_address,
            "total_score": self.total_score,
            "factor_scores": {factor.value: score for factor, score in self.factor_scores.items()},
            "factor_weights": {factor.value: weight for factor, weight in self.factor_weights.items()},
            "history": self.history,
            "last_update": self.last_update
        })
        return data
    
    @classmethod
    def deserialize(cls, data: Dict[str, Any]) -> 'NodeReputationContract':
        """
        Create a NodeReputationContract instance from serialized data.
        
        Args:
            data: Dictionary containing serialized contract data.
            
        Returns:
            A new NodeReputationContract instance.
        """
        contract = cls(
            contract_id=data["contract_id"],
            owner_address=data["owner_address"],
            node_address=data["node_address"]
        )
        
        contract.state = ContractState(data["state"])
        contract.created_at = data["created_at"]
        contract.expires_at = data.get("expires_at")
        contract.total_score = data["total_score"]
        
        # Deserialize factor scores
        for factor_name, score in data["factor_scores"].items():
            contract.factor_scores[ReputationFactor(factor_name)] = score
            
        # Deserialize factor weights
        for factor_name, weight in data["factor_weights"].items():
            contract.factor_weights[ReputationFactor(factor_name)] = weight
            
        contract.history = data["history"]
        contract.last_update = data["last_update"]
        
        return contract

