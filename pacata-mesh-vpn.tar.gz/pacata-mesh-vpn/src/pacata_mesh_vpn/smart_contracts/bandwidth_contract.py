#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import json
import uuid
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from datetime import datetime, timedelta

from .base_contract import SmartContract, ContractState

@dataclass
class BandwidthRecord:
    """Represents a single bandwidth sharing record between nodes."""
    provider_id: str
    consumer_id: str
    bytes_transferred: int
    timestamp: float
    session_id: str
    verified: bool = False
    rewarded: bool = False


@dataclass
class BandwidthStats:
    """Aggregated bandwidth statistics for a node."""
    total_provided: int = 0
    total_consumed: int = 0
    last_update: float = 0
    sessions_count: int = 0
    pending_reward: float = 0


class BandwidthSharingContract(SmartContract):
    """
    Smart contract for tracking and rewarding bandwidth sharing between VPN nodes.
    
    This contract:
    1. Tracks bandwidth shared between provider and consumer nodes
    2. Validates bandwidth sharing claims through consensus
    3. Calculates rewards based on bandwidth contribution
    4. Distributes rewards to nodes that share bandwidth
    """
    
    def __init__(self, contract_id: Optional[str] = None, owner_id: Optional[str] = None):
        """
        Initialize a new bandwidth sharing contract.
        
        Args:
            contract_id: Unique identifier for the contract (generated if None)
            owner_id: ID of the contract owner (often a node or admin)
        """
        super().__init__(contract_id or str(uuid.uuid4()), owner_id)
        self.contract_type = "BANDWIDTH_SHARING"
        self.bandwidth_records: List[BandwidthRecord] = []
        self.node_stats: Dict[str, BandwidthStats] = {}
        self.reward_rate = 0.0001  # Tokens per megabyte (configurable)
        self.verification_threshold = 2  # Number of confirmations needed
        self.verification_votes: Dict[str, List[str]] = {}  # record_id -> list of confirming nodes
        self.min_payout_amount = 10.0  # Minimum amount for payout
        self.last_payout_time = time.time()
        self.payout_interval = 86400  # Daily payouts (in seconds)
        
    def initialize(self, config: Dict[str, Any]) -> bool:
        """
        Initialize the contract with configuration parameters.
        
        Args:
            config: Dictionary containing configuration parameters
            
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            if "reward_rate" in config:
                self.reward_rate = float(config["reward_rate"])
            if "verification_threshold" in config:
                self.verification_threshold = int(config["verification_threshold"])
            if "min_payout_amount" in config:
                self.min_payout_amount = float(config["min_payout_amount"])
            if "payout_interval" in config:
                self.payout_interval = int(config["payout_interval"])
                
            self.state = ContractState.ACTIVE
            return True
        except (ValueError, KeyError) as e:
            self.error_message = f"Initialization failed: {str(e)}"
            self.state = ContractState.ERROR
            return False
            
    def record_bandwidth_usage(self, provider_id: str, consumer_id: str, 
                               bytes_transferred: int, session_id: str) -> str:
        """
        Record bandwidth shared between a provider and consumer node.
        
        Args:
            provider_id: ID of the node providing bandwidth
            consumer_id: ID of the node consuming bandwidth
            bytes_transferred: Number of bytes transferred
            session_id: Unique session identifier
            
        Returns:
            The record ID of the new bandwidth record
        """
        if self.state != ContractState.ACTIVE:
            raise ValueError(f"Contract is not active. Current state: {self.state}")
        
        if bytes_transferred <= 0:
            raise ValueError("Bytes transferred must be positive")
            
        record = BandwidthRecord(
            provider_id=provider_id,
            consumer_id=consumer_id,
            bytes_transferred=bytes_transferred,
            timestamp=time.time(),
            session_id=session_id
        )
        
        # Create a unique record ID
        record_id = f"{provider_id}:{consumer_id}:{session_id}:{int(record.timestamp)}"
        
        # Update node statistics
        if provider_id not in self.node_stats:
            self.node_stats[provider_id] = BandwidthStats()
        if consumer_id not in self.node_stats:
            self.node_stats[consumer_id] = BandwidthStats()
            
        self.node_stats[provider_id].total_provided += bytes_transferred
        self.node_stats[provider_id].last_update = record.timestamp
        self.node_stats[provider_id].sessions_count += 1
        
        self.node_stats[consumer_id].total_consumed += bytes_transferred
        self.node_stats[consumer_id].last_update = record.timestamp
        
        # Add record to the contract
        self.bandwidth_records.append(record)
        self.verification_votes[record_id] = []
        
        # Update contract state
        self.last_updated = time.time()
        
        # Emit an event
        self._emit_event("BandwidthRecorded", {
            "record_id": record_id,
            "provider_id": provider_id,
            "consumer_id": consumer_id,
            "bytes_transferred": bytes_transferred,
            "timestamp": record.timestamp
        })
        
        return record_id
        
    def verify_bandwidth_record(self, record_id: str, verifier_id: str) -> bool:
        """
        Verify a bandwidth sharing record by a third-party node.
        
        Args:
            record_id: ID of the bandwidth record to verify
            verifier_id: ID of the node verifying the record
            
        Returns:
            True if the verification was recorded, False otherwise
        """
        if record_id not in self.verification_votes:
            return False
            
        # Prevent duplicate votes
        if verifier_id in self.verification_votes[record_id]:
            return False
            
        # Record the verification
        self.verification_votes[record_id].append(verifier_id)
        
        # Check if verification threshold is reached
        if len(self.verification_votes[record_id]) >= self.verification_threshold:
            # Find and mark the record as verified
            for record in self.bandwidth_records:
                r_id = f"{record.provider_id}:{record.consumer_id}:{record.session_id}:{int(record.timestamp)}"
                if r_id == record_id:
                    record.verified = True
                    
                    # Calculate reward
                    mb_transferred = record.bytes_transferred / (1024 * 1024)  # Convert to MB
                    reward_amount = mb_transferred * self.reward_rate
                    
                    # Add pending reward
                    provider_stats = self.node_stats[record.provider_id]
                    provider_stats.pending_reward += reward_amount
                    
                    # Emit verification event
                    self._emit_event("BandwidthVerified", {
                        "record_id": record_id,
                        "verifier_count": len(self.verification_votes[record_id]),
                        "reward_amount": reward_amount
                    })
                    break
        
        return True
        
    def calculate_rewards(self, node_id: str) -> float:
        """
        Calculate the current reward amount for a node.
        
        Args:
            node_id: ID of the node to calculate rewards for
            
        Returns:
            The current reward amount
        """
        if node_id not in self.node_stats:
            return 0.0
            
        return self.node_stats[node_id].pending_reward
        
    def process_payouts(self) -> Dict[str, float]:
        """
        Process payouts for all nodes that have reached the minimum payout amount.
        
        Returns:
            Dictionary mapping node IDs to payout amounts
        """
        current_time = time.time()
        
        # Check if enough time has passed since last payout
        if current_time - self.last_payout_time < self.payout_interval:
            return {}
            
        payouts = {}
        
        for node_id, stats in self.node_stats.items():
            if stats.pending_reward >= self.min_payout_amount:
                payouts[node_id] = stats.pending_reward
                stats.pending_reward = 0
                
                # Mark all verified records for this provider as rewarded
                for record in self.bandwidth_records:
                    if record.provider_id == node_id and record.verified and not record.rewarded:
                        record.rewarded = True
        
        if payouts:
            self.last_payout_time = current_time
            self._emit_event("PayoutsProcessed", {
                "payouts": payouts,
                "timestamp": current_time
            })
            
        return payouts
        
    def get_node_stats(self, node_id: str) -> Optional[Dict[str, Any]]:
        """
        Get bandwidth statistics for a specific node.
        
        Args:
            node_id: ID of the node to get statistics for
            
        Returns:
            Dictionary with node statistics or None if node not found
        """
        if node_id not in self.node_stats:
            return None
            
        stats = self.node_stats[node_id]
        
        return {
            "total_provided_mb": stats.total_provided / (1024 * 1024),
            "total_consumed_mb": stats.total_consumed / (1024 * 1024),
            "sessions_count": stats.sessions_count,
            "pending_reward": stats.pending_reward,
            "last_activity": datetime.fromtimestamp(stats.last_update).isoformat() if stats.last_update > 0 else None
        }
    
    def get_network_stats(self) -> Dict[str, Any]:
        """
        Get network-wide bandwidth statistics.
        
        Returns:
            Dictionary with network statistics
        """
        total_provided = sum(stats.total_provided for stats in self.node_stats.values())
        total_consumed = sum(stats.total_consumed for stats in self.node_stats.values())
        total_pending_rewards = sum(stats.pending_reward for stats in self.node_stats.values())
        total_sessions = sum(stats.sessions_count for stats in self.node_stats.values())
        active_nodes = sum(1 for stats in self.node_stats.values() if time.time() - stats.last_update < 86400)
        
        return {
            "total_bandwidth_mb": total_provided / (1024 * 1024),
            "total_pending_rewards": total_pending_rewards,
            "total_sessions": total_sessions,
            "active_nodes_24h": active_nodes,
            "total_nodes": len(self.node_stats)
        }

    def execute(self, action: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a contract method based on the specified action.
        
        Args:
            action: Name of the action to perform
            params: Parameters for the action
            
        Returns:
            Dictionary with the result of the action
        """
        if self.state != ContractState.ACTIVE:
            return {"success": False, "error": f"Contract is not active. Current state: {self.state}"}
            
        try:
            if action == "record_bandwidth":
                record_id = self.record_bandwidth_usage(
                    provider_id=params["provider_id"],
                    consumer_id=params["consumer_id"],
                    bytes_transferred=params["bytes_transferred"],
                    session_id=params["session_id"]
                )
                return {"success": True, "record_id": record_id}
                
            elif action == "verify_bandwidth":
                result = self.verify_bandwidth_record(
                    record_id=params["record_id"],
                    verifier_id=params["verifier_id"]
                )
                return {"success": result}
                
            elif action == "get_rewards":
                rewards = self.calculate_rewards(params["node_id"])
                return {"success": True, "rewards": rewards}
                
            elif action == "process_payouts":
                payouts = self.process_payouts()
                return {"success": True, "payouts": payouts}
                
            elif action == "get_node_stats":
                stats = self.get_node_stats(params["node_id"])
                if stats:
                    return {"success": True, "stats": stats}
                return {"success": False, "error": "Node not found"}
                
            elif action == "get_network_stats":
                stats = self.get_network_stats()
                return {"success": True, "stats": stats}
                
            else:
                return {"success": False, "error": f"Unknown action: {action}"}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
            
    def serialize(self) -> Dict[str, Any]:
        """
        Serialize the contract state to a dictionary.
        
        Returns:
            Dictionary representation of the contract
        """
        bandwidth_records = []
        for record in self.bandwidth_records:
            bandwidth_records.append({
                "provider_id": record.provider_id,
                "consumer_id": record.consumer_id,
                "bytes_transferred": record.bytes_transferred,
                "timestamp": record.timestamp,
                "session_id": record.session_id,
                "verified": record.verified,
                "rewarded": record.rewarded
            })
            
        # Convert node stats to serializable format
        node_stats = {}
        for node_id, stats in self.node_stats.items():
            node_stats[node_id] = {
                "total_provided": stats.total_provided,
                "total_consumed": stats.total_consumed,
                "last_update": stats.last_update,
                "sessions_count": stats.sessions_count,
                "pending_reward": stats.pending_reward
            }
            
        return {
            **super().serialize(),
            "contract_type": self.contract_type,
            "bandwidth_records": bandwidth_records,
            "node_stats": node_stats,
            "reward_rate": self.reward_rate,
            "verification_threshold": self.verification_threshold,
            "verification_votes": self.verification_votes,
            "min_payout_amount": self.min_payout_amount,
            "last_payout_time": self.last_payout_time,
            "payout_interval": self.payout_interval
        }
        
    @classmethod
    def deserialize(cls, data: Dict[str, Any]) -> 'BandwidthSharingContract':
        """
        Create a contract instance from serialized data.
        
        Args:
            data: Serialized contract data dictionary
            
        Returns:
            A new BandwidthSharingContract instance with restored state
        """
        # Create a new contract instance with the saved ID and owner
        contract = cls(
            contract_id=data.get("contract_id"),
            owner_id=data.get("owner_id")
        )
        
        # Restore contract base properties
        contract.state = ContractState[data.get("state", "INITIALIZED")]
        contract.created_at = data.get("created_at", time.time())
        contract.last_updated = data.get("last_updated", time.time())
        contract.error_message = data.get("error_message", "")
        
        # Restore bandwidth contract specific properties
        contract.contract_type = data.get("contract_type", "BANDWIDTH_SHARING")
        contract.reward_rate = data.get("reward_rate", 0.0001)
        contract.verification_threshold = data.get("verification_threshold", 2)
        contract.min_payout_amount = data.get("min_payout_amount", 10.0)
        contract.last_payout_time = data.get("last_payout_time", time.time())
        contract.payout_interval = data.get("payout_interval", 86400)
        contract.verification_votes = data.get("verification_votes", {})
        
        # Reconstruct bandwidth records
        contract.bandwidth_records = []
        for record_data in data.get("bandwidth_records", []):
            record = BandwidthRecord(
                provider_id=record_data.get("provider_id", ""),
                consumer_id=record_data.get("consumer_id", ""),
                bytes_transferred=record_data.get("bytes_transferred", 0),
                timestamp=record_data.get("timestamp", 0.0),
                session_id=record_data.get("session_id", ""),
                verified=record_data.get("verified", False),
                rewarded=record_data.get("rewarded", False)
            )
            contract.bandwidth_records.append(record)
            
        # Reconstruct node stats
        contract.node_stats = {}
        for node_id, stats_data in data.get("node_stats", {}).items():
            stats = BandwidthStats(
                total_provided=stats_data.get("total_provided", 0),
                total_consumed=stats_data.get("total_consumed", 0),
                last_update=stats_data.get("last_update", 0.0),
                sessions_count=stats_data.get("sessions_count", 0),
                pending_reward=stats_data.get("pending_reward", 0.0)
            )
            contract.node_stats[node_id] = stats
            
        return contract
        
    def _emit_event(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """
        Emit a contract event (to be captured by listeners).
        
        Args:
            event_type: Type of the event
            event_data: Data associated with the event
        """
        # This would typically integrate with an event system
        # For now, we'll just log the event
        event = {
            "contract_id": self.contract_id,
            "event_type": event_type,
            "timestamp": time.time(),
            "data": event_data
        }
        
        # In a real implementation, this would publish to an event bus/stream
        # For now, we'll just print it for debugging purposes
        print(f"CONTRACT EVENT: {json.dumps(event)}")
        
    def get_session_records(self, session_id: str) -> List[BandwidthRecord]:
        """
        Get all bandwidth records for a specific session.
        
        Args:
            session_id: ID of the session to get records for
            
        Returns:
            List of bandwidth records for the session
        """
        return [record for record in self.bandwidth_records if record.session_id == session_id]
        
    def get_pending_verifications(self) -> List[Tuple[str, int]]:
        """
        Get records that have not yet reached the verification threshold.
        
        Returns:
            List of tuples containing record ID and current verification count
        """
        pending = []
        for record_id, votes in self.verification_votes.items():
            votes_count = len(votes)
            if votes_count < self.verification_threshold:
                pending.append((record_id, votes_count))
        return pending
