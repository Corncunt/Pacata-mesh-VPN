#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Payment Smart Contract Module for Pacata Mesh VPN

This module implements the TokenPaymentContract class responsible for handling
token payments between VPN users and nodes in the mesh network.
"""

import json
import time
import uuid
from enum import Enum
from typing import Dict, Any, Optional, List, Tuple

from ..blockchain.wallet import Wallet
from ..security.validation import validate_data_structure
from .base_contract import SmartContract, ContractState


class PaymentStatus(Enum):
    """Represents the different states of a payment contract."""
    PENDING = "pending"        # Payment initiated but not confirmed
    CONFIRMED = "confirmed"    # Payment confirmed by blockchain
    COMPLETED = "completed"    # Service delivered and payment finalized
    FAILED = "failed"          # Payment failed for some reason
    REFUNDED = "refunded"      # Payment was refunded to payer
    DISPUTED = "disputed"      # Payment is under dispute resolution


class TokenPaymentContract(SmartContract):
    """
    Contract that handles token payments between VPN nodes and users.
    
    This contract manages the lifecycle of payments, ensures proper token transfers,
    and provides verification of completed transactions.
    """
    
    def __init__(self, 
                 payer_address: str,
                 payee_address: str,
                 amount: float,
                 service_id: str,
                 payment_details: Dict[str, Any] = None,
                 contract_id: Optional[str] = None,
                 created_at: Optional[float] = None,
                 updated_at: Optional[float] = None,
                 status: PaymentStatus = PaymentStatus.PENDING,
                 metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Initialize a new token payment contract.
        
        Args:
            payer_address: Wallet address of the user making the payment
            payee_address: Wallet address of the node receiving the payment
            amount: Amount of tokens to be transferred
            service_id: Identifier for the service being paid for
            payment_details: Additional details about the payment (service type, duration, etc.)
            contract_id: Unique identifier for this contract (generated if not provided)
            created_at: Timestamp of contract creation (set to current time if not provided)
            updated_at: Timestamp of last contract update (set to creation time if not provided)
            status: Current status of the payment
            metadata: Additional metadata for the contract
        """
        super().__init__(contract_id or str(uuid.uuid4()),
                         created_at or time.time(),
                         updated_at or time.time(),
                         ContractState.ACTIVE,
                         metadata or {})
        
        self.payer_address = payer_address
        self.payee_address = payee_address
        self.amount = amount
        self.service_id = service_id
        self.payment_details = payment_details or {}
        self.status = status
        self.transaction_id = None
        self.payment_history = []
        
        # Record the initial payment status
        self._record_status_change(status, "Contract initialized")
    
    def _record_status_change(self, new_status: PaymentStatus, reason: str) -> None:
        """
        Record a change in payment status with timestamp and reason.
        
        Args:
            new_status: The new status of the payment
            reason: Reason for the status change
        """
        self.payment_history.append({
            "timestamp": time.time(),
            "previous_status": getattr(self, "status", None),
            "new_status": new_status,
            "reason": reason
        })
        self.status = new_status
        self.updated_at = time.time()
    
    def initiate_payment(self, wallet: Wallet) -> bool:
        """
        Initiate a payment from the payer to the payee.
        
        Args:
            wallet: The payer's wallet used to send the payment
            
        Returns:
            bool: True if payment was successfully initiated, False otherwise
        """
        if self.status != PaymentStatus.PENDING:
            return False
            
        # Verify the wallet belongs to the payer
        if wallet.address != self.payer_address:
            self._record_status_change(PaymentStatus.FAILED, 
                                     "Payment attempted with incorrect wallet")
            return False
            
        # Check if wallet has sufficient funds
        if wallet.get_balance() < self.amount:
            self._record_status_change(PaymentStatus.FAILED, 
                                     "Insufficient funds in payer wallet")
            return False
            
        # Attempt to make the transaction
        try:
            self.transaction_id = wallet.send_transaction(
                self.payee_address, 
                self.amount,
                f"Payment for service: {self.service_id}"
            )
            self._record_status_change(PaymentStatus.CONFIRMED, 
                                     f"Payment initiated with transaction ID: {self.transaction_id}")
            return True
        except Exception as e:
            self._record_status_change(PaymentStatus.FAILED, 
                                     f"Transaction failed: {str(e)}")
            return False
    
    def complete_payment(self) -> bool:
        """
        Mark the payment as completed after service delivery.
        
        Returns:
            bool: True if payment was successfully completed, False otherwise
        """
        if self.status != PaymentStatus.CONFIRMED:
            return False
            
        self._record_status_change(PaymentStatus.COMPLETED, 
                                 "Service delivered and payment finalized")
        return True
    
    def refund_payment(self, wallet: Wallet, reason: str) -> bool:
        """
        Refund the payment to the original payer.
        
        Args:
            wallet: The payee's wallet used to send the refund
            reason: Reason for the refund
            
        Returns:
            bool: True if refund was successful, False otherwise
        """
        if self.status not in [PaymentStatus.CONFIRMED, PaymentStatus.DISPUTED]:
            return False
            
        # Verify the wallet belongs to the payee
        if wallet.address != self.payee_address:
            return False
            
        # Attempt to make the refund transaction
        try:
            refund_tx_id = wallet.send_transaction(
                self.payer_address, 
                self.amount,
                f"Refund for service: {self.service_id}. Reason: {reason}"
            )
            self._record_status_change(PaymentStatus.REFUNDED, 
                                     f"Payment refunded. Transaction ID: {refund_tx_id}")
            return True
        except Exception as e:
            self._record_status_change(PaymentStatus.DISPUTED, 
                                     f"Refund failed: {str(e)}")
            return False
    
    def dispute_payment(self, reason: str) -> bool:
        """
        Mark the payment as disputed for further resolution.
        
        Args:
            reason: Reason for the dispute
            
        Returns:
            bool: True if the dispute was registered, False otherwise
        """
        if self.status in [PaymentStatus.FAILED, PaymentStatus.REFUNDED]:
            return False
            
        self._record_status_change(PaymentStatus.DISPUTED, 
                                 f"Payment disputed. Reason: {reason}")
        return True
    
    def resolve_dispute(self, in_favor_of: str, resolution_notes: str) -> bool:
        """
        Resolve a disputed payment.
        
        Args:
            in_favor_of: Address of the party the dispute is resolved in favor of
            resolution_notes: Notes about the resolution decision
            
        Returns:
            bool: True if the dispute was resolved, False otherwise
        """
        if self.status != PaymentStatus.DISPUTED:
            return False
            
        if in_favor_of == self.payer_address:
            self._record_status_change(PaymentStatus.REFUNDED, 
                                     f"Dispute resolved in favor of payer: {resolution_notes}")
        else:
            self._record_status_change(PaymentStatus.COMPLETED, 
                                     f"Dispute resolved in favor of payee: {resolution_notes}")
        return True
    
    def get_payment_status(self) -> Tuple[PaymentStatus, List[Dict[str, Any]]]:
        """
        Get the current payment status and history.
        
        Returns:
            Tuple containing the current status and the payment history
        """
        return (self.status, self.payment_history)
    
    def serialize(self) -> Dict[str, Any]:
        """
        Serialize the contract to a dictionary.
        
        Returns:
            Dict containing all contract data
        """
        data = super().serialize()
        data.update({
            "payer_address": self.payer_address,
            "payee_address": self.payee_address,
            "amount": self.amount,
            "service_id": self.service_id,
            "payment_details": self.payment_details,
            "status": self.status.value,
            "transaction_id": self.transaction_id,
            "payment_history": self.payment_history
        })
        return data
    
    @classmethod
    def deserialize(cls, data: Dict[str, Any]) -> 'TokenPaymentContract':
        """
        Deserialize contract data from a dictionary.
        
        Args:
            data: Dictionary containing contract data
            
        Returns:
            Reconstructed TokenPaymentContract instance
        """
        # Validate the incoming data structure
        expected_fields = [
            "contract_id", "created_at", "updated_at", "state",
            "payer_address", "payee_address", "amount", "service_id"
        ]
        validate_data_structure(data, expected_fields)
        
        # Create a new contract instance
        contract = cls(
            payer_address=data["payer_address"],
            payee_address=data["payee_address"],
            amount=data["amount"],
            service_id=data["service_id"],
            payment_details=data.get("payment_details", {}),
            contract_id=data["contract_id"],
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            status=PaymentStatus(data["status"]),
            metadata=data.get("metadata", {})
        )
        
        # Restore additional state
        contract.transaction_id = data.get("transaction_id")
        contract.payment_history = data.get("payment_history", [])
        
        return contract

