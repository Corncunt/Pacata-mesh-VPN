import hashlib
import json
import time
import os
import threading
from typing import Dict, List, Set, Optional, Any, Tuple
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Constants
DIFFICULTY = 4  # Number of leading zeros required in block hash
MINING_REWARD = 5.0  # Mining reward in Pacata coins
BLOCKCHAIN_DIR = os.path.expanduser("~/.pacata/blockchain")
GENESIS_COINBASE_ADDRESS = "PACATA_GENESIS_ADDRESS"
BLOCK_FILE_EXTENSION = ".blk"
BLOCKCHAIN_INDEX_FILE = "blockchain_index.json"

class Transaction:
    """Represents a transaction on the Pacata blockchain"""
    
    def __init__(self, sender: str, recipient: str, amount: float, nonce: int, 
                 signature: Optional[str] = None, timestamp: Optional[float] = None, 
                 transaction_id: Optional[str] = None):
        self.sender = sender
        self.recipient = recipient
        self.amount = amount
        self.nonce = nonce  # Prevents replay attacks
        self.signature = signature
        self.timestamp = timestamp or time.time()
        self._transaction_id = transaction_id
    
    @property
    def transaction_id(self) -> str:
        """Generate or return the transaction ID."""
        if self._transaction_id is None:
            # Generate transaction ID if it doesn't exist
            transaction_data = {
                "sender": self.sender,
                "recipient": self.recipient,
                "amount": self.amount,
                "nonce": self.nonce,
                "timestamp": self.timestamp
            }
            self._transaction_id = hashlib.sha256(json.dumps(transaction_data, sort_keys=True).encode()).hexdigest()
        return self._transaction_id
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert transaction to dictionary format."""
        return {
            "sender": self.sender,
            "recipient": self.recipient,
            "amount": self.amount,
            "nonce": self.nonce,
            "signature": self.signature,
            "timestamp": self.timestamp,
            "transaction_id": self.transaction_id
        }
    
    @classmethod
    def from_dict(cls, transaction_dict: Dict[str, Any]) -> 'Transaction':
        """Create a Transaction object from a dictionary."""
        return cls(
            sender=transaction_dict["sender"],
            recipient=transaction_dict["recipient"],
            amount=transaction_dict["amount"],
            nonce=transaction_dict["nonce"],
            signature=transaction_dict["signature"],
            timestamp=transaction_dict["timestamp"],
            transaction_id=transaction_dict["transaction_id"]
        )
    
    def __str__(self) -> str:
        return f"Transaction({self.transaction_id[:8]}): {self.sender[:8]} -> {self.recipient[:8]}, amount: {self.amount}, nonce: {self.nonce}"


class Block:
    """Represents a block in the Pacata blockchain"""
    
    def __init__(self, index: int, transactions: List[Transaction], timestamp: Optional[float] = None,
                 previous_hash: str = "", nonce: int = 0, hash_value: Optional[str] = None):
        self.index = index
        self.transactions = transactions
        self.timestamp = timestamp or time.time()
        self.previous_hash = previous_hash
        self.nonce = nonce  # Used for proof of work
        self._hash = hash_value
    
    @property
    def hash(self) -> str:
        """Calculate and return the hash of the block."""
        if not self._hash:
            self._hash = self.calculate_hash()
        return self._hash
    
    def calculate_hash(self) -> str:
        """Calculate the hash of the block based on its contents."""
        transactions_data = [tx.to_dict() for tx in self.transactions]
        block_data = {
            "index": self.index,
            "transactions": transactions_data,
            "timestamp": self.timestamp,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce
        }
        block_string = json.dumps(block_data, sort_keys=True).encode()
        return hashlib.sha256(block_string).hexdigest()
    
    def mine_block(self, difficulty: int) -> None:
        """
        Mine the block by finding a nonce that results in a hash with the required number of leading zeros.
        """
        target = '0' * difficulty
        while self.hash[:difficulty] != target:
            self.nonce += 1
            self._hash = self.calculate_hash()
        
        logger.info(f"Block #{self.index} mined: {self.hash}")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert block to dictionary format."""
        return {
            "index": self.index,
            "transactions": [tx.to_dict() for tx in self.transactions],
            "timestamp": self.timestamp,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce,
            "hash": self.hash
        }
    
    @classmethod
    def from_dict(cls, block_dict: Dict[str, Any]) -> 'Block':
        """Create a Block object from a dictionary."""
        transactions = [Transaction.from_dict(tx) for tx in block_dict["transactions"]]
        return cls(
            index=block_dict["index"],
            transactions=transactions,
            timestamp=block_dict["timestamp"],
            previous_hash=block_dict["previous_hash"],
            nonce=block_dict["nonce"],
            hash_value=block_dict["hash"]
        )
    
    def __str__(self) -> str:
        return f"Block #{self.index} - Hash: {self.hash[:10]}..., Transactions: {len(self.transactions)}"


class Blockchain:
    """Implements the Pacata blockchain"""
    
    def __init__(self):
        self.chain: List[Block] = []
        self.pending_transactions: List[Transaction] = []
        self.transaction_pool: Set[str] = set()  # Set of transaction IDs in the pool
        self.address_nonces: Dict[str, int] = {}  # Track the next nonce for each address
        
        # Thread lock for synchronization
        self.lock = threading.RLock()
        
        # Ensure blockchain directory exists
        os.makedirs(BLOCKCHAIN_DIR, exist_ok=True)
        
        # Load blockchain from disk or create genesis block
        self._load_blockchain()
        
        # If blockchain is empty, create genesis block
        if not self.chain:
            self._create_genesis_block()
    
    def _create_genesis_block(self) -> None:
        """Create the genesis block with initial coin allocation."""
        # Create a coinbase transaction that generates the initial coins
        coinbase_tx = Transaction(
            sender="COINBASE",
            recipient=GENESIS_COINBASE_ADDRESS,
            amount=100.0,  # Initial allocation
            nonce=0,
            timestamp=time.time()
        )
        
        # Create the genesis block
        genesis_block = Block(
            index=0,
            transactions=[coinbase_tx],
            timestamp=time.time(),
            previous_hash="0"
        )
        
        # Mine the genesis block
        genesis_block.mine_block(DIFFICULTY)
        
        # Add the genesis block to the chain
        self.chain.append(genesis_block)
        
        # Save the genesis block
        self._save_block(genesis_block)
        self._update_index()
        
        logger.info("Genesis block created")
    
    def _load_blockchain(self) -> None:
        """Load the blockchain from disk."""
        index_file = os.path.join(BLOCKCHAIN_DIR, BLOCKCHAIN_INDEX_FILE)
        
        # Check if index file exists
        if not os.path.exists(index_file):
            logger.info("No blockchain index found. Starting with a new blockchain.")
            return
        
        try:
            with open(index_file, 'r') as f:
                index_data = json.load(f)
                
            # Load blocks in order
            for block_file in index_data["blocks"]:
                block_path = os.path.join(BLOCKCHAIN_DIR, block_file)
                with open(block_path, 'r') as f:
                    block_data = json.load(f)
                    block = Block.from_dict(block_data)
                    self.chain.append(block)
                    
                    # Update nonces for all addresses in transactions
                    for tx in block.transactions:
                        if tx.sender != "COINBASE":
                            self.address_nonces[tx.sender] = max(
                                self.address_nonces.get(tx.sender, 0),
                                tx.nonce + 1
                            )
            
            logger.info(f"Loaded {len(self.chain)} blocks from disk")
        except Exception as e:
            logger.error(f"Error loading blockchain: {e}")
            # Start fresh if loading fails
            self.chain = []
    
    def _save_block(self, block: Block) -> None:
        """Save a block to disk."""
        file_name = f"block_{block.index}_{block.hash[:8]}{BLOCK_FILE_EXTENSION}"
        file_path = os.path.join(BLOCKCHAIN_DIR, file_name)
        
        with open(file_path, 'w') as f:
            json.dump(block.to_dict(), f, indent=2)
        
        logger.debug(f"Saved block #{block.index} to {file_path}")
    
    def _update_index(self) -> None:
        """Update the blockchain index file."""
        index_file = os.path.join(BLOCKCHAIN_DIR, BLOCKCHAIN_INDEX_FILE)
        
        block_files = []
        for block in self.chain:
            file_name = f"block_{block.index}_{block.hash[:8]}{BLOCK_FILE_EXTENSION}"
            block_files.append(file_name)
        
        index_data = {
            "blocks": block_files,
            "last_updated": time.time()
        }
        
        with open(index_file, 'w') as f:
            json.dump(index_data, f, indent=2)
        
        logger.debug("Updated blockchain index")
    
    def get_latest_block(self) -> Block:
        """Get the latest block in the chain."""
        with self.lock:
            return self.chain[-1]
    
    def add_transaction(self, transaction: Transaction) -> bool:
        """
        Add a new transaction to the pending transactions list.
        Returns True if the transaction was added successfully.
        """
        with self.lock:
            # Check if transaction already exists
            if transaction.transaction_id in self.transaction_pool:
                logger.warning(f"Transaction {transaction.transaction_id[:8]} already exists in the pool")
                return False
            
            # Validate transaction
            if not self._validate_transaction(transaction):
                logger.warning(f"Invalid transaction: {transaction}")
                return False
            
            # Add transaction to pool
            self.pending_transactions.append(transaction)
            self.transaction_pool.add(transaction.transaction_id)
            
            logger.info(f"Transaction {transaction.transaction_id[:8]} added to pool")
            return True
    
    def _validate_transaction(self, transaction: Transaction) -> bool:
        """
        Validate a transaction.
        Returns True if the transaction is valid.
        """
        # Skip validation for coinbase transactions
        if transaction.sender == "COINBASE":
            return True
        
        # Check if sender has sufficient balance
        sender_balance = self.get_balance(transaction.sender)
        if sender_balance < transaction.amount:
            logger.warning(f"Insufficient balance for {transaction.sender}: {sender_balance} < {transaction.amount}")
            return False
        
        # Check transaction nonce
        expected_nonce = self.get_nonce(transaction.sender)
        if transaction.nonce != expected_nonce:
            logger.warning(f"Invalid nonce for {transaction.sender}: expected {expected_nonce}, got {transaction.nonce}")
            return False
        
        # TODO: Validate signature when wallet implementation is complete
        
        return True
    
    def get_balance(self, address: str) -> float:
        """Calculate and return the balance for a given address."""
        with self.lock:
            balance = 0.0
            
            # Iterate through all blocks and transactions
            for block in self.chain:
                for tx in block.transactions:
                    if tx.recipient == address:
                        balance += tx.amount
                    if tx.sender == address:
                        balance -= tx.amount
            
            return max(0.0, balance)  # Ensure balance is not negative
    
    def get_nonce(self, address: str) -> int:
        """Get the current nonce for an address."""
        with self.lock:
            return self.address_nonces.get(address, 0)
    
    def get_transactions_for_address(self, address: str) -> List[Dict[str, Any]]:
        """Get all transactions involving a specific address."""
        with self.lock:
            transactions = []
            
            for block in self.chain:
                for tx in block.transactions:
                    if tx.sender == address or tx.recipient == address:
                        tx_data = tx.to_dict()
                        tx_data["block_index"] = block.index
                        tx_data["block_hash"] = block.hash
                        transactions.append(tx_data)
            
            return transactions
    
    def create_block(self) -> Block:
        """Create a new block with pending transactions."""
        with self.lock:
            last_block = self.get_latest_block()
            
            new_block = Block(
                index=last_block.index + 1,
                transactions=self.pending_transactions.copy(),
                timestamp=time.time(),
                previous_hash=last_block.hash
            )
            
            return new_block
    
    def add_block(self, block: Block) -> bool:
        """
        Add a validated block to the chain.
        Returns True if the block was added successfully.
        """
        with self.lock:
            # Validate the block before adding
            if not self.validate_block(block):
                logger.warning(f"Invalid block #{block.index}")
                return False
            
            # Add the block to the chain
            self.chain.append(block)
            
            # Save the block to disk
            self._save_block(block)
            self._update_index()
            
            # Update address nonces
            for tx in block.transactions:
                if tx.sender != "COINBASE":
                    self.address_nonces[tx.sender] = max(
                        self.address_nonces.get(tx.sender, 0),
                        tx.nonce + 1
                    )
            
            # Clear pending transactions that were included in the block
            processed_tx_ids = {tx.transaction_id for tx in block.transactions}
            self.pending_transactions = [tx for tx in self.pending_transactions if tx.transaction_id not in processed_tx_ids]
            
            # Also remove the transactions from the transaction pool
            self.transaction_pool -= processed_tx_ids
            
            logger.info(f"Block #{block.index} added to the chain")
            return True
    
    def validate_block(self, block: Block) -> bool:
        """
        Validate if a block is valid.
        Returns True if the block is valid.
        """
        with self.lock:
            # Check if the block index is correct
            if len(self.chain) > 0:
                last_block = self.get_latest_block()
                if block.index != last_block.index + 1:
                    logger.warning(f"Invalid block index: expected {last_block.index + 1}, got {block.index}")
                    return False
                
                # Check if previous hash matches the hash of the last block
                if block.previous_hash != last_block.hash:
                    logger.warning(f"Invalid previous hash: expected {last_block.hash}, got {block.previous_hash}")
                    return False
            
            # Verify block hash
            if block.hash != block.calculate_hash():
                logger.warning("Invalid block hash")
                return False
            
            # Check proof of work
            if block.hash[:DIFFICULTY] != '0' * DIFFICULTY:
                logger.warning("Proof of work requirement not met")
                return False
            
            # Validate all transactions in the block
            transaction_ids = set()
            for tx in block.transactions:
                # Check for duplicate transactions within the block
                if tx.transaction_id in transaction_ids:
                    logger.warning(f"Duplicate transaction in block: {tx.transaction_id}")
                    return False
                transaction_ids.add(tx.transaction_id)
                
                # Skip validation for coinbase transactions
                if tx.sender == "COINBASE":
                    continue
                
                # Validate each transaction
                if not self._validate_transaction(tx):
                    logger.warning(f"Invalid transaction in block: {tx.transaction_id}")
                    return False
            
            return True
    
    def validate_chain(self) -> bool:
        """
        Validate the entire blockchain.
        Returns True if the blockchain is valid.
        """
        with self.lock:
            # An empty chain is valid (will be initialized with genesis block)
            if not self.chain:
                return True
            
            # Check each block in the chain
            for i in range(1, len(self.chain)):
                current_block = self.chain[i]
                previous_block = self.chain[i-1]
                
                # Verify the block's previous hash points to the previous block
                if current_block.previous_hash != previous_block.hash:
                    logger.error(f"Block #{current_block.index} has incorrect previous hash")
                    return False
                
                # Verify the block's hash is correct
                if current_block.hash != current_block.calculate_hash():
                    logger.error(f"Block #{current_block.index} has incorrect hash")
                    return False
                
                # Verify proof of work
                if current_block.hash[:DIFFICULTY] != '0' * DIFFICULTY:
                    logger.error(f"Block #{current_block.index} doesn't meet proof of work requirement")
                    return False
            
            logger.info("Blockchain is valid")
            return True
    
    def mine_block(self, miner_address: str) -> Block:
        """
        Mine a new block and add it to the chain.
        Returns the mined block.
        """
        with self.lock:
            # Create a coinbase transaction to reward the miner
            coinbase_tx = Transaction(
                sender="COINBASE",
                recipient=miner_address,
                amount=MINING_REWARD,
                nonce=0,
                timestamp=time.time()
            )
            
            # Add the coinbase transaction to the pending transactions
            self.pending_transactions.insert(0, coinbase_tx)
            
            # Create a new block with all pending transactions
            new_block = self.create_block()
            
            # Mine the block
            logger.info(f"Mining block #{new_block.index}...")
            new_block.mine_block(DIFFICULTY)
            
            # Add the mined block to the chain
            success = self.add_block(new_block)
            
            if not success:
                logger.error("Failed to add mined block to the chain")
                # Remove the coinbase transaction from pending transactions if the block wasn't added
                self.pending_transactions.pop(0)
                return None
            
            logger.info(f"Successfully mined block #{new_block.index}")
            return new_block
