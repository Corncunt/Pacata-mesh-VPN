import hashlib
import json
import time
import random
import logging
from typing import Dict, List, Optional, Any, Set, Tuple
from abc import ABC, abstractmethod

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Constants for consensus mechanisms
DEFAULT_POW_DIFFICULTY = 4  # Default number of leading zeros for PoW
MIN_STAKE_AMOUNT = 10.0     # Minimum amount required to stake
STAKE_REWARD_RATE = 0.02    # 2% annual return on staked amount
DPOS_DELEGATE_COUNT = 21    # Number of delegates in DPoS
DPOS_SLOT_TIME = 3          # Time in seconds for each delegate's slot


class Consensus(ABC):
    """
    Abstract base class defining the interface for consensus mechanisms.
    Any consensus algorithm must implement these methods.
    """
    
    @abstractmethod
    def validate_block(self, block, blockchain=None) -> bool:
        """
        Validate if a block meets the consensus requirements.
        
        Args:
            block: The block to validate
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: True if the block is valid according to the consensus rules
        """
        pass
    
    @abstractmethod
    def prepare_block(self, block, node_id: str, blockchain=None) -> None:
        """
        Prepare a block for mining/validation according to the consensus rules.
        
        Args:
            block: The block to prepare
            node_id: The identifier of the node that is creating the block
            blockchain: Optional reference to the blockchain
        """
        pass
    
    @abstractmethod
    def finalize_block(self, block, blockchain=None) -> bool:
        """
        Finalize a block according to the consensus rules (e.g., mining for PoW).
        
        Args:
            block: The block to finalize
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: True if the block was successfully finalized
        """
        pass
    
    @abstractmethod
    def get_block_reward(self, block, node_id: str, blockchain=None) -> float:
        """
        Calculate the reward for creating a block.
        
        Args:
            block: The block that was created
            node_id: The identifier of the node that created the block
            blockchain: Optional reference to the blockchain
            
        Returns:
            float: The reward amount
        """
        pass
    
    @abstractmethod
    def can_create_block(self, node_id: str, blockchain=None) -> bool:
        """
        Check if a node is eligible to create a block at the current time.
        
        Args:
            node_id: The identifier of the node
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: True if the node can create a block
        """
        pass
    

class ProofOfWork(Consensus):
    """
    Implements Proof of Work consensus mechanism.
    This is an enhanced version of the simple PoW implemented in blockchain.py.
    """
    
    def __init__(self, difficulty: int = DEFAULT_POW_DIFFICULTY, adaptive_difficulty: bool = True):
        """
        Initialize the PoW consensus mechanism.
        
        Args:
            difficulty: The number of leading zeros required in the block hash
            adaptive_difficulty: Whether to adjust difficulty based on block times
        """
        self.difficulty = difficulty
        self.adaptive_difficulty = adaptive_difficulty
        self.target_block_time = 60  # Target time between blocks in seconds
        self.difficulty_adjustment_interval = 10  # Adjust difficulty every N blocks
    
    def validate_block(self, block, blockchain=None) -> bool:
        """
        Validate if a block has a valid proof of work.
        
        Args:
            block: The block to validate
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: True if the block has valid proof of work
        """
        # Check if the block hash has the required number of leading zeros
        if not block.hash.startswith('0' * self.difficulty):
            logger.warning(f"Block hash doesn't meet difficulty requirement: {block.hash}")
            return False
        
        # Verify that the hash is calculated correctly
        calculated_hash = block.calculate_hash()
        if block.hash != calculated_hash:
            logger.warning(f"Block hash verification failed. Expected: {calculated_hash}, Got: {block.hash}")
            return False
        
        return True
    
    def prepare_block(self, block, node_id: str, blockchain=None) -> None:
        """
        Prepare a block for mining according to PoW rules.
        In PoW, there's not much preparation needed.
        
        Args:
            block: The block to prepare
            node_id: The identifier of the node that is creating the block
            blockchain: Optional reference to the blockchain
        """
        # For PoW, we just need to reset the nonce
        block.nonce = 0
        
        # If we're using adaptive difficulty, check if we need to adjust
        if self.adaptive_difficulty and blockchain and len(blockchain.chain) % self.difficulty_adjustment_interval == 0:
            self._adjust_difficulty(blockchain)
    
    def finalize_block(self, block, blockchain=None) -> bool:
        """
        Mine the block using proof of work.
        
        Args:
            block: The block to mine
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: True if mining was successful
        """
        # Mine the block by finding a nonce that results in a hash with required leading zeros
        target = '0' * self.difficulty
        while not block.hash.startswith(target):
            block.nonce += 1
            block._hash = block.calculate_hash()
            
            # Optional: Add a way to cancel mining if needed
            if block.nonce % 10000 == 0:
                # Check for any cancellation signal
                if getattr(self, '_cancel_mining', False):
                    logger.info("Mining operation cancelled")
                    return False
        
        logger.info(f"Block #{block.index} mined with nonce {block.nonce}: {block.hash}")
        return True
    
    def get_block_reward(self, block, node_id: str, blockchain=None) -> float:
        """
        Calculate the mining reward for a PoW block.
        
        Args:
            block: The block that was mined
            node_id: The identifier of the miner
            blockchain: Optional reference to the blockchain
            
        Returns:
            float: The mining reward
        """
        # In this implementation, the mining reward is fixed
        # In a real implementation, this could decrease over time
        base_reward = 5.0
        
        # Optionally, add transaction fees as part of the reward
        fees = 0.0
        if blockchain:
            for tx in block.transactions:
                if tx.sender != "COINBASE":
                    # In a real implementation, calculate the fee based on transaction size or complexity
                    fees += 0.001
        
        return base_reward + fees
    
    def can_create_block(self, node_id: str, blockchain=None) -> bool:
        """
        In PoW, any node can create a block at any time.
        
        Args:
            node_id: The identifier of the node
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: Always True for PoW
        """
        # In PoW, any node can attempt to mine a block
        return True
    
    def _adjust_difficulty(self, blockchain) -> None:
        """
        Adjust the mining difficulty based on the average block time.
        
        Args:
            blockchain: The blockchain to analyze
        """
        if len(blockchain.chain) <= self.difficulty_adjustment_interval:
            return
        
        # Calculate the average time between the last N blocks
        start_time = blockchain.chain[-self.difficulty_adjustment_interval].timestamp
        end_time = blockchain.chain[-1].timestamp
        avg_block_time = (end_time - start_time) / self.difficulty_adjustment_interval
        
        # Adjust difficulty based on the average block time
        if avg_block_time < self.target_block_time * 0.5:
            # Blocks are being mined too quickly, increase difficulty
            self.difficulty += 1
            logger.info(f"Difficulty increased to {self.difficulty}")
        elif avg_block_time > self.target_block_time * 2:
            # Blocks are being mined too slowly, decrease difficulty
            if self.difficulty > 1:
                self.difficulty -= 1
                logger.info(f"Difficulty decreased to {self.difficulty}")


class ProofOfStake(Consensus):
    """
    Implements Proof of Stake consensus mechanism.
    In PoS, validators are chosen based on the amount of cryptocurrency they're staking.
    """
    
    def __init__(self):
        """Initialize the PoS consensus mechanism."""
        self.stakes = {}  # Maps node_id to staked amount
        self.last_block_timestamps = {}  # Maps node_id to timestamp of their last block
        self.min_stake_age = 60 * 60 * 24  # 1 day in seconds
        self.max_future_time = 15  # Maximum seconds a block can be ahead of current time
    
    def stake(self, node_id: str, amount: float) -> bool:
        """
        Stake coins for a node to participate in the PoS consensus.
        
        Args:
            node_id: The identifier of the node
            amount: The amount to stake
            
        Returns:
            bool: True if staking was successful
        """
        if amount < MIN_STAKE_AMOUNT:
            logger.warning(f"Stake amount too low: {amount}. Minimum required: {MIN_STAKE_AMOUNT}")
            return False
        
        # Update the stake for the node
        if node_id in self.stakes:
            self.stakes[node_id] += amount
        else:
            self.stakes[node_id] = amount
        
        logger.info(f"Node {node_id} has staked {amount} coins. Total stake: {self.stakes[node_id]}")
        return True
    
    def unstake(self, node_id: str, amount: float) -> bool:
        """
        Unstake coins for a node.
        
        Args:
            node_id: The identifier of the node
            amount: The amount to unstake
            
        Returns:
            bool: True if unstaking was successful
        """
        if node_id not in self.stakes:
            logger.warning(f"Node {node_id} has no stake")
            return False
        
        if amount > self.stakes[node_id]:
            logger.warning(f"Unstake amount {amount} exceeds current stake {self.stakes[node_id]}")
            return False
        
        self.stakes[node_id] -= amount
        logger.info(f"Node {node_id} has unstaked {amount} coins. Remaining stake: {self.stakes[node_id]}")
        
        # If stake is now 0, remove the node from the stakes dictionary
        if self.stakes[node_id] == 0:
            del self.stakes[node_id]
        
        return True
    
    def validate_block(self, block, blockchain=None) -> bool:
        """
        Validate if a block meets the PoS requirements.
        
        Args:
            block: The block to validate
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: True if the block is valid according to PoS rules
        """
        # Verify the block creator has a stake
        creator = block.transactions[0].recipient  # Assuming first tx is the reward
        if creator not in self.stakes:
            logger.warning(f"Block creator {creator} has no stake")
            return False
        
        # Check if the block timestamp is valid
        current_time = time.time()
        if block.timestamp > current_time + self.max_future_time:
            logger.warning(f"Block timestamp {block.timestamp} is too far in the future")
            return False
        
        # Verify the block hash is valid for PoS (could involve checking against the stake amount)
        stake_target = self._calculate_stake_target(creator)
        block_hash_int = int(block.hash, 16)
        if block_hash_int > stake_target:
            logger.warning(f"Block hash doesn't meet stake target for creator {creator}")
            return False
        
        return True
    
    def prepare_block(self, block, node_id: str, blockchain=None) -> None:
        """
        Prepare a block according to PoS rules.
        
        Args:
            block: The block to prepare
            node_id: The identifier of the node that is creating the block
            blockchain: Optional reference to the blockchain
        """
        # In PoS, the nonce is less important, but we can use it for uniqueness
        block.nonce = int(time.time() * 1000) % 1000000
        
        # The timestamp is critical for PoS
        block.timestamp = time.time()
    
    def finalize_block(self, block, blockchain=None) -> bool:
        """
        Finalize a block according to PoS rules.
        In PoS, we don't mine, but we still need to create a valid hash.
        
        Args:
            block: The block to finalize
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: True if the block was successfully finalized
        """
        # In PoS, we still compute a hash, but we don't try to meet a difficulty target
        # Instead, the right to create a block depends on the stake
        block._hash = block.calculate_hash()
        
        # Record the timestamp for this validator's last block
        creator = block.transactions[0].recipient
        self.last_block_timestamps[creator] = block.timestamp
        
        logger.info(f"Block #{block.index} finalized by {creator}: {block.hash}")
        return True
    
    def get_block_reward(self, block, node_id: str, blockchain=None) -> float:
        """
        Calculate the reward for creating a block in PoS.
        
        Args:
            block: The block that was created
            node_id: The identifier of the node that created the block
            blockchain: Optional reference to the blockchain
            
        Returns:
            float: The reward amount
        """
        # In PoS, the reward is typically a percentage of the stake
        if node_id not in self.stakes:
            return 0.0
        
        # Calculate reward based on stake amount and stake time
        stake_amount = self.stakes[node_id]
        reward = stake_amount * STAKE_REWARD_RATE / 365  # Daily reward
        
        # Add transaction fees
        fees = 0.0
        for tx in block.transactions:
            if tx.sender != "COINBASE":
                # In a real implementation, calculate the fee based on transaction size or complexity
                fees += 0.0005  # Smaller fee than PoW because of lower costs
        
        return reward + fees
    
    def can_create_block(self, node_id: str, blockchain=None) -> bool:
        """
        Check if a node is eligible to create a block at the current time based on its stake.
        
        Args:
            node_id: The identifier of the node
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: True if the node can create a block
        """
        # Check if the node has a stake
        if node_id not in self.stakes:
            return False
        
        # Check if the stake meets the minimum requirement
        if self.stakes[node_id] < MIN_STAKE_AMOUNT:
            return False
        
        # Check if the stake is mature enough
        current_time = time.time()
        if node_id in self.last_block_timestamps:
            time_since_last_block = current_time - self.last_block_timestamps[node_id]
            if time_since_last_block < self.min_stake_age:
                return False
        
        # Use randomness influenced by stake amount to determine eligibility
        # This simulates the "lottery" aspect of PoS
        random_value = random.random()
        stake_weight = self.stakes[node_id] / sum(self.stakes.values())
        
        # The higher the stake, the more likely to be chosen
        return random_value < stake_weight
    
    def _calculate_stake_target(self, node_id: str) -> int:
        """
        Calculate the target value for a node based on its stake.
        
        Args:
            node_id: The identifier of the node
            
        Returns:
            int: The stake target as an integer
        """
        if node_id not in self.stakes:
            return 0
        
        # The higher the stake, the "easier" it is to create a block
        # This is represented by a higher target value (easier to be below)
        stake_fraction = self.stakes[node_id] / sum(self.stakes.values())
        max_target = int("f" * 64, 16)  # Maximum possible hash value (all Fs in hex)
        return int(max_target * stake_fraction)


class DPoS(Consensus):
    """
    Implements Delegated Proof of Stake consensus mechanism.
    In DPoS, a limited number of delegates are voted in to create blocks.
    """
    
    def __init__(self, delegate_count: int = DPOS_DELEGATE_COUNT, slot_time: int = DPOS_SLOT_TIME):
        """
        Initialize the DPoS consensus mechanism.
        
        Args:
            delegate_count: Number of active delegates
            slot_time: Time in seconds for each delegate's slot
        """
        self.delegate_count = delegate_count
        self.slot_time = slot_time
        self.delegates = {}  # Maps node_id to votes received
        self.active_delegates = []  # Ordered list of active delegates
        self.votes = {}  # Maps voter_id to delegate_id voted for
        self.last_block_time = time.time()
    
    def vote(self, voter_id: str, delegate_id: str, vote_weight: float = 1.0) -> bool:
        """
        Vote for a delegate.
        
        Args:
            voter_id: The identifier of the voter
            delegate_id: The identifier of the delegate
            vote_weight: Weight of the vote, can be based on stake
            
        Returns:
            bool: True if voting was successful
        """
        # Record the vote
        self.votes[voter_id] = (delegate_id, vote_weight)
        
        # Update delegate votes
        if delegate_id in self.delegates:
            self.delegates[delegate_id] += vote_weight
        else:
            self.delegates[delegate_id] = vote_weight
        
        # Recalculate active delegates
        self._update_active_delegates()
        logger.info(f"Vote recorded: {voter_id} voted for {delegate_id} with weight {vote_weight}")
        return True
    
    def unvote(self, voter_id: str) -> bool:
        """
        Remove a vote for a delegate.
        
        Args:
            voter_id: The identifier of the voter
            
        Returns:
            bool: True if unvoting was successful
        """
        if voter_id not in self.votes:
            return False
        
        delegate_id, vote_weight = self.votes[voter_id]
        
        # Remove the vote
        del self.votes[voter_id]
        
        # Update delegate votes
        if delegate_id in self.delegates:
            self.delegates[delegate_id] -= vote_weight
            if self.delegates[delegate_id] <= 0:
                del self.delegates[delegate_id]
        
        # Recalculate active delegates
        self._update_active_delegates()
        logger.info(f"Vote removed: {voter_id} unvoted {delegate_id}")
        return True
    
    def validate_block(self, block, blockchain=None) -> bool:
        """
        Validate if a block meets the DPoS requirements.
        
        Args:
            block: The block to validate
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: True if the block is valid according to DPoS rules
        """
        # Verify the block creator is an active delegate
        creator = block.transactions[0].recipient  # Assuming first tx is the reward
        if creator not in self.active_delegates:
            logger.warning(f"Block creator {creator} is not an active delegate")
            return False
        
        # Verify the block is created in the delegate's time slot
        expected_slot = self._calculate_time_slot(block.timestamp)
        expected_delegate = self._get_delegate_for_slot(expected_slot)
        if creator != expected_delegate:
            logger.warning(f"Block not created in correct time slot. Expected: {expected_delegate}, Got: {creator}")
            return False
        
        # Verify the block hash is valid (optional additional check)
        if block.hash != block.calculate_hash():
            logger.warning(f"Block hash verification failed")
            return False
        
        return True
    
    def prepare_block(self, block, node_id: str, blockchain=None) -> None:
        """
        Prepare a block according to DPoS rules.
        
        Args:
            block: The block to prepare
            node_id: The identifier of the node that is creating the block
            blockchain: Optional reference to the blockchain
        """
        # Set the timestamp to the beginning of the current slot for consistency
        current_slot = self._calculate_current_slot()
        block.timestamp = self.last_block_time + (current_slot * self.slot_time)
        
        # In DPoS, the nonce is less important, but we can use it for uniqueness
        block.nonce = current_slot
    
    def finalize_block(self, block, blockchain=None) -> bool:
        """
        Finalize a block according to DPoS rules.
        
        Args:
            block: The block to finalize
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: True if the block was successfully finalized
        """
        # Calculate the block hash
        block._hash = block.calculate_hash()
        
        # Update the last block time
        self.last_block_time = block.timestamp
        
        logger.info(f"Block #{block.index} finalized by delegate {block.transactions[0].recipient}: {block.hash}")
        return True
    
    def get_block_reward(self, block, node_id: str, blockchain=None) -> float:
        """
        Calculate the reward for creating a block in DPoS.
        
        Args:
            block: The block that was created
            node_id: The identifier of the node that created the block
            blockchain: Optional reference to the blockchain
            
        Returns:
            float: The reward amount
        """
        # In DPoS, the reward is typically fixed
        base_reward = 3.0  # Lower than PoW because it's more energy-efficient
        
        # Add transaction fees
        fees = 0.0
        for tx in block.transactions:
            if tx.sender != "COINBASE":
                fees += 0.0002  # Even smaller fee than PoS
        
        return base_reward + fees
    
    def can_create_block(self, node_id: str, blockchain=None) -> bool:
        """
        Check if a node is eligible to create a block at the current time.
        In DPoS, only the delegate for the current time slot can create a block.
        
        Args:
            node_id: The identifier of the node
            blockchain: Optional reference to the blockchain
            
        Returns:
            bool: True if the node can create a block
        """
        # Check if the node is an active delegate
        if node_id not in self.active_delegates:
            return False
        
        # Check if it's the node's time slot
        current_slot = self._calculate_current_slot()
        slot_delegate = self._get_delegate_for_slot(current_slot)
        
        return node_id == slot_delegate
    
    def _update_active_delegates(self) -> None:
        """
        Update the list of active delegates based on votes.
        """
        # Sort delegates by votes and take the top ones
        sorted_delegates = sorted(self.delegates.items(), key=lambda x: x[1], reverse=True)
        self.active_delegates = [d[0] for d in sorted_delegates[:self.delegate_count]]
        logger.info(f"Active delegates updated: {self.active_delegates}")
    
    def _calculate_current_slot(self) -> int:
        """
        Calculate the current time slot.
        
        Returns:
            int: The current slot number
        """
        time_elapsed = time.time() - self.last_block_time
        return int(time_elapsed / self.slot_time)
    
    def _calculate_time_slot(self, timestamp: float) -> int:
        """
        Calculate the time slot for a given timestamp.
        
        Args:
            timestamp: The timestamp to calculate the slot for
            
        Returns:
            int: The slot number
        """
        time_elapsed = timestamp - self.last_block_time
        return int(time_elapsed / self.slot_time)
    
    def _get_delegate_for_slot(self, slot: int) -> str:
        """
        Get the delegate assigned to a specific time slot.
        
        Args:
            slot: The slot number
            
        Returns:
            str: The delegate's identifier
        """
        if not self.active_delegates:
            return ""
        return self.active_delegates[slot % len(self.active_delegates)]


class ConsensusFactory:
    """
    Factory class for creating appropriate consensus mechanisms.
    """
    
    @staticmethod
    def create_consensus(consensus_type: str, **kwargs) -> Consensus:
        """
        Create a consensus mechanism of the specified type.
        
        Args:
            consensus_type: The type of consensus mechanism to create
            **kwargs: Additional parameters for the consensus mechanism
            
        Returns:
            Consensus: The created consensus mechanism
            
        Raises:
            ValueError: If the consensus type is unknown
        """
        if consensus_type.lower() == "pow":
            difficulty = kwargs.get("difficulty", DEFAULT_POW_DIFFICULTY)
            adaptive = kwargs.get("adaptive_difficulty", True)
            return ProofOfWork(difficulty=difficulty, adaptive_difficulty=adaptive)
        
        elif consensus_type.lower() == "pos":
            return ProofOfStake()
        
        elif consensus_type.lower() == "dpos":
            delegate_count = kwargs.get("delegate_count", DPOS_DELEGATE_COUNT)
            slot_time = kwargs.get("slot_time", DPOS_SLOT_TIME)
            return DPoS(delegate_count=delegate_count, slot_time=slot_time)
        
        else:
            raise ValueError(f"Unknown consensus type: {consensus_type}")
