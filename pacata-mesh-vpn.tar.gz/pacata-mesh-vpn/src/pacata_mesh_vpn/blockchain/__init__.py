"""
Pacata Mesh VPN Blockchain Module

This module implements the distributed ledger, cryptocurrency, and incentive
system for the Pacata Mesh VPN. It includes wallet functionality, transaction
validation, mining, and consensus mechanisms.

Key Components:
- Wallet management
- Blockchain data structures
- Transaction processing
- Mining and consensus algorithms
- Incentive mechanisms for node operators
- Peer-to-peer networking and blockchain synchronization
"""
from .wallet import PacataWallet
from .blockchain import Blockchain, Block, Transaction
from .consensus import Consensus, ProofOfWork, ProofOfStake, DPoS, ConsensusFactory
from .p2p import BlockchainP2P, MessageType, P2PError, PeerConnectionError, MessageValidationError

__all__ = [
    'PacataWallet',
    'Blockchain',
    'Block',
    'Transaction',
    'Consensus',
    'ProofOfWork',
    'ProofOfStake',
    'DPoS',
    'ConsensusFactory',
    'BlockchainP2P',
    'MessageType',
    'P2PError',
    'PeerConnectionError',
    'MessageValidationError'
]

