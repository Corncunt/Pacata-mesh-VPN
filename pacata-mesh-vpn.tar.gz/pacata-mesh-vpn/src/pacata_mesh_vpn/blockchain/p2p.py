#!/usr/bin/env python3
"""
Peer-to-Peer Blockchain Synchronization Module

This module implements the P2P networking layer for the Pacata Mesh VPN blockchain,
allowing nodes to discover each other, exchange blockchain data, broadcast transactions,
and maintain consensus across the network.
"""

import asyncio
import base64
import hashlib
import json
import logging
import random
import socket
import time
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple, Union, Callable, Any

from ..networking.dht import DHT, Node
from .blockchain import Blockchain, Block, Transaction
from .consensus import Consensus, ConsensusFactory, ProofOfWork, ProofOfStake, DPoS

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('pacata.blockchain.p2p')

# P2P protocol constants
P2P_VERSION = "0.1.0"
BLOCK_BROADCAST_INTERVAL = 10  # seconds
TRANSACTION_BROADCAST_INTERVAL = 5  # seconds
MAX_BLOCKCHAIN_DOWNLOAD_RETRIES = 3
SYNC_INTERVAL = 300  # seconds
HEADER_SIZE = 4  # bytes for message size header
MAX_MESSAGE_SIZE = 10 * 1024 * 1024  # 10 MB max message size

class MessageType(Enum):
    """Types of messages exchanged in the P2P network."""
    HANDSHAKE = 1
    GET_PEERS = 2
    PEERS = 3
    GET_BLOCKCHAIN = 4
    BLOCKCHAIN = 5
    GET_BLOCKS = 6
    BLOCKS = 7
    NEW_BLOCK = 8
    TRANSACTION = 9
    GET_MEMPOOL = 10
    MEMPOOL = 11
    CONSENSUS_DATA = 12
    ERROR = 99

class P2PError(Exception):
    """Base exception for P2P networking errors."""
    pass

class PeerConnectionError(P2PError):
    """Exception raised for peer connection issues."""
    pass

class MessageValidationError(P2PError):
    """Exception raised for message validation issues."""
    pass

class BlockchainP2P:
    """
    Implements the P2P networking layer for blockchain synchronization.
    
    This class manages peer connections, blockchain data exchange, and consensus
    synchronization across the network.
    """
    
    def __init__(self, host: str, port: int, blockchain: Blockchain, dht: DHT):
        """
        Initialize the P2P networking layer.
        
        Args:
            host: The host IP address to bind to
            port: The port to listen on
            blockchain: The blockchain instance
            dht: The DHT instance for peer discovery
        """
        self.host = host
        self.port = port
        self.blockchain = blockchain
        self.dht = dht
        self.peers: Dict[str, Tuple[str, int]] = {}  # peer_id -> (host, port)
        self.active_connections: Dict[str, asyncio.StreamWriter] = {}  # peer_id -> writer
        self.server = None
        self.running = False
        self.known_blocks: Set[str] = set()  # Set of known block hashes
        self.known_txs: Set[str] = set()  # Set of known transaction hashes
        self.sync_lock = asyncio.Lock()
        self.handlers = {
            MessageType.HANDSHAKE: self._handle_handshake,
            MessageType.GET_PEERS: self._handle_get_peers,
            MessageType.PEERS: self._handle_peers,
            MessageType.GET_BLOCKCHAIN: self._handle_get_blockchain,
            MessageType.BLOCKCHAIN: self._handle_blockchain,
            MessageType.GET_BLOCKS: self._handle_get_blocks,
            MessageType.BLOCKS: self._handle_blocks,
            MessageType.NEW_BLOCK: self._handle_new_block,
            MessageType.TRANSACTION: self._handle_transaction,
            MessageType.GET_MEMPOOL: self._handle_get_mempool,
            MessageType.MEMPOOL: self._handle_mempool,
            MessageType.CONSENSUS_DATA: self._handle_consensus_data,
            MessageType.ERROR: self._handle_error,
        }
        self.consensus_factory = ConsensusFactory()
        self.node_id = self._generate_node_id()
        
        # Set up background tasks
        self.tasks = []
    
    def _generate_node_id(self) -> str:
        """Generate a unique node ID based on host, port, and random data."""
        unique_string = f"{self.host}:{self.port}:{random.randint(0, 1000000)}"
        return hashlib.sha256(unique_string.encode()).hexdigest()[:16]
    
    async def start(self):
        """Start the P2P server and background tasks."""
        if self.running:
            logger.warning("P2P network already running")
            return
        
        logger.info(f"Starting P2P blockchain network on {self.host}:{self.port}")
        self.running = True
        
        # Start the server
        self.server = await asyncio.start_server(
            self._handle_connection, self.host, self.port
        )
        
        # Start background tasks
        self.tasks = [
            asyncio.create_task(self._discover_peers_task()),
            asyncio.create_task(self._broadcast_blocks_task()),
            asyncio.create_task(self._broadcast_transactions_task()),
            asyncio.create_task(self._sync_blockchain_task()),
        ]
        
        logger.info(f"P2P blockchain network started with node ID: {self.node_id}")
    
    async def stop(self):
        """Stop the P2P server and all background tasks."""
        if not self.running:
            logger.warning("P2P network not running")
            return
        
        logger.info("Stopping P2P blockchain network")
        self.running = False
        
        # Close all connections
        for peer_id, writer in self.active_connections.items():
            try:
                writer.close()
                await writer.wait_closed()
            except Exception as e:
                logger.error(f"Error closing connection to peer {peer_id}: {e}")
        
        # Cancel all tasks
        for task in self.tasks:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        
        # Close the server
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        
        self.active_connections = {}
        self.peers = {}
        logger.info("P2P blockchain network stopped")
    
    async def _handle_connection(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        """
        Handle incoming connections from peers.
        
        Args:
            reader: The stream reader for the connection
            writer: The stream writer for the connection
        """
        peer_addr = writer.get_extra_info('peername')
        peer_id = None
        
        try:
            logger.info(f"New connection from {peer_addr}")
            
            # Perform handshake
            peer_id = await self._perform_handshake(reader, writer)
            if not peer_id:
                logger.warning(f"Handshake failed with {peer_addr}")
                writer.close()
                return
            
            # Process messages until connection is closed
            while self.running:
                try:
                    message = await self._receive_message(reader)
                    if not message:
                        break
                    
                    message_type = MessageType(message.get('type'))
                    handler = self.handlers.get(message_type)
                    
                    if handler:
                        await handler(message, writer, peer_id)
                    else:
                        logger.warning(f"Unknown message type: {message_type}")
                except (asyncio.CancelledError, ConnectionError):
                    break
                except Exception as e:
                    logger.error(f"Error processing message from {peer_id}: {e}")
                    await self._send_error(writer, str(e))
        
        except Exception as e:
            logger.error(f"Error handling connection from {peer_addr}: {e}")
        
        finally:
            # Clean up the connection
            if peer_id and peer_id in self.active_connections:
                del self.active_connections[peer_id]
            
            try:
                writer.close()
                await writer.wait_closed()
            except:
                pass
            
            logger.info(f"Connection closed with {peer_addr if not peer_id else peer_id}")
    
    async def _receive_message(self, reader: asyncio.StreamReader) -> Optional[Dict]:
        """
        Receive and parse a message from a peer.
        
        Args:
            reader: The stream reader for the connection
        
        Returns:
            The parsed message, or None if the connection was closed
        """
        # Read message size
        size_bytes = await reader.read(HEADER_SIZE)
        if not size_bytes:
            return None
        
        if len(size_bytes) < HEADER_SIZE:
            raise PeerConnectionError("Incomplete message size header")
        
        message_size = int.from_bytes(size_bytes, byteorder='big')
        if message_size > MAX_MESSAGE_SIZE:
            raise MessageValidationError(f"Message too large: {message_size} bytes")
        
        # Read the actual message
        message_bytes = await reader.read(message_size)
        if len(message_bytes) < message_size:
            raise PeerConnectionError("Incomplete message")
        
        # Parse the message
        try:
            return json.loads(message_bytes.decode())
        except json.JSONDecodeError:
            raise MessageValidationError("Invalid JSON in message")
    
    async def _send_message(self, writer: asyncio.StreamWriter, message_type: MessageType, data: Dict = None):
        """
        Send a message to a peer.
        
        Args:
            writer: The stream writer for the connection
            message_type: The type of message to send
            data: The data to include in the message
        """
        if data is None:
            data = {}
        
        message = {
            'type': message_type.value,
            'version': P2P_VERSION,
            'timestamp': int(time.time()),
            'node_id': self.node_id,
            'data': data
        }
        
        message_bytes = json.dumps(message).encode()
        size_bytes = len(message_bytes).to_bytes(HEADER_SIZE, byteorder='big')
        
        writer.write(size_bytes + message_bytes)
        await writer.drain()
    
    async def _send_error(self, writer: asyncio.StreamWriter, error_message: str):
        """
        Send an error message to a peer.
        
        Args:
            writer: The stream writer for the connection
            error_message: The error message to send
        """
        await self._send_message(writer, MessageType.ERROR, {'error': error_message})
    
    async def _perform_handshake(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> Optional[str]:
        """
        Perform the initial handshake with a new peer.
        
        Args:
            reader: The stream reader for the connection
            writer: The stream writer for the connection
        
        Returns:
            The peer's node ID on success, None on failure
        """
        peer_addr = writer.get_extra_info('peername')
        
        try:
            # Send handshake
            blockchain_height = len(self.blockchain.chain)
            consensus_type = self.blockchain.consensus.__class__.__name__
            
            await self._send_message(writer, MessageType.HANDSHAKE, {
                'height': blockchain_height,
                'consensus': consensus_type,
                'host': self.host,
                'port': self.port
            })
            
            # Receive handshake
            message = await self._receive_message(reader)
            if not message or MessageType(message.get('type')) != MessageType.HANDSHAKE:
                logger.warning(f"Invalid handshake from {peer_addr}")
                return None
            
            peer_id = message.get('node_id')
            if not peer_id:
                logger.warning(f"Missing node_id in handshake from {peer_addr}")
                return None
            
            # Store peer information
            peer_data = message.get('data', {})
            peer_host = peer_data.get('host')
            peer_port = peer_data.get('port')
            
            if peer_host and peer_port:
                self.peers[peer_id] = (peer_host, peer_port)
                self.active_connections[peer_id] = writer
                logger.info(f"Handshake completed with peer {peer_id} at {peer_host}:{peer_port}")
            
            return peer_id
        
        except Exception as e:
            logger.error(f"Handshake failed with {peer_addr}: {e}")
            return None
    
    async def connect_to_peer(self, host: str, port: int) -> bool:
        """
        Connect to a peer.
        
        Args:
            host: The peer's host
            port: The peer's port
        
        Returns:
            True if the connection was successful, False otherwise
        """
        try:
            logger.info(f"Connecting to peer at {host}:{port}")
            reader, writer = await asyncio.open_connection(host, port)
            
            # Perform handshake
            peer_id = await self._perform_handshake(reader, writer)
            if not peer_id:
                logger.warning(f"Handshake failed with {host}:{port}")
                writer.close()
                return False
            
            # Start task to handle messages from this peer
            asyncio.create_task(self._handle_peer_messages(reader, writer, peer_id))
            return True
        
        except Exception as e:
            logger.error(f"Failed to connect to peer at {host}:{port}: {e}")
            return False
    
    async def _handle_peer_messages(self, reader: asyncio.StreamReader, 
                                   writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle messages from a connected peer.
        
        Args:
            reader: The stream reader for the connection
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        try:
            while self.running:
                message = await self._receive_message(reader)
                if not message:
                    break
                
                message_type = MessageType(message.get('type'))
                handler = self.handlers.get(message_type)
                
                if handler:
                    await handler(message, writer, peer_id)
                else:
                    logger.warning(f"Unknown message type from {peer_id}: {message_type}")
        
        except (asyncio.CancelledError, ConnectionError):
            pass
        except Exception as e:
            logger.error(f"Error handling messages from peer {peer_id}: {e}")
        
        finally:
            # Clean up the connection
            if peer_id in self.active_connections:
                del self.active_connections[peer_id]
            
            try:
                writer.close()
                await writer.wait_closed()
            except:
                pass
            
            logger.info(f"Connection with peer {peer_id} closed")
    
    # Message handlers
    
    async def _handle_handshake(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle a handshake message from a peer.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        data = message.get('data', {})
        peer_height = data.get('height', 0)
        peer_consensus = data.get('consensus', 'ProofOfWork')
        peer_host = data.get('host')
        peer_port = data.get('port')
        
        logger.info(f"Received handshake from peer {peer_id}: height={peer_height}, consensus={peer_consensus}")
        
        # Store peer information
        if peer_host and peer_port:
            self.peers[peer_id] = (peer_host, peer_port)
            self.active_connections[peer_id] = writer
        
        # Check if we need blockchain sync
        our_height = len(self.blockchain.chain)
        if peer_height > our_height:
            logger.info(f"Peer {peer_id} has a longer blockchain ({peer_height} > {our_height}), requesting sync")
            asyncio.create_task(self._request_blockchain(peer_id))
    
    async def _handle_get_peers(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle a request for peers.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        logger.info(f"Received get_peers request from {peer_id}")
        peers_data = []
        
        # Include DHT peers
        dht_nodes = self.dht.get_nodes()
        for node in dht_nodes:
            peers_data.append({
                'host': node.host,
                'port': node.port,
                'id': node.id
            })
        
        # Include directly connected peers
        for pid, (host, port) in self.peers.items():
            if pid != peer_id:  # Don't send the requesting peer back
                peers_data.append({
                    'host': host,
                    'port': port,
                    'id': pid
                })
        
        await self._send_message(writer, MessageType.PEERS, {'peers': peers_data})
    
    async def _handle_peers(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle a response with peer information.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        data = message.get('data', {})
        peers = data.get('peers', [])
        
        logger.info(f"Received {len(peers)} peers from {peer_id}")
        
        for peer in peers:
            host = peer.get('host')
            port = peer.get('port')
            pid = peer.get('id')
            
            if not all([host, port, pid]) or pid == self.node_id or pid in self.peers:
                continue
            
            # Add to DHT
            self.dht.add_node(Node(pid, host, port))
            
            # Try to connect if we're not already at max connections
            if len(self.active_connections) < 10:  # Arbitrary limit
                asyncio.create_task(self.connect_to_peer(host, port))
    
    async def _handle_get_blockchain(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle a request for the full blockchain.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        logger.info(f"Received get_blockchain request from {peer_id}")
        
        # Serialize the blockchain
        chain_data = self._serialize_blockchain()
        
        await self._send_message(writer, MessageType.BLOCKCHAIN, {
            'chain': chain_data,
            'height': len(self.blockchain.chain)
        })
    
    async def _handle_blockchain(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle a response with the full blockchain.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        async with self.sync_lock:
            data = message.get('data', {})
            chain_data = data.get('chain', [])
            height = data.get('height', 0)
            
            logger.info(f"Received blockchain from {peer_id} with height {height}")
            
            # Validate and process the blockchain
            if height > len(self.blockchain.chain):
                try:
                    new_chain = self._deserialize_blockchain(chain_data)
                    if self.blockchain.validate_chain(new_chain):
                        self.blockchain.chain = new_chain
                        logger.info(f"Successfully updated blockchain to height {height}")
                        
                        # Update known blocks
                        self.known_blocks = {block.hash for block in self.blockchain.chain}
                        
                        # Reset mempool for transactions that are now in the blockchain
                        self._update_mempool_after_sync()
                    else:
                        logger.warning(f"Received invalid blockchain from {peer_id}")
                except Exception as e:
                    logger.error(f"Error processing blockchain from {peer_id}: {e}")
    
    async def _handle_get_blocks(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle a request for specific blocks.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        data = message.get('data', {})
        start_height = data.get('start', 0)
        end_height = data.get('end', len(self.blockchain.chain))
        
        # Limit the range to avoid excessive data
        if end_height - start_height > 100:
            end_height = start_height + 100
        
        blocks = []
        for i in range(start_height, min(end_height, len(self.blockchain.chain))):
            blocks.append(self._serialize_block(self.blockchain.chain[i]))
        
        logger.info(f"Sending {len(blocks)} blocks to {peer_id}")
        await self._send_message(writer, MessageType.BLOCKS, {'blocks': blocks})
    
    async def _handle_blocks(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle a response with multiple blocks.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        async with self.sync_lock:
            data = message.get('data', {})
            blocks_data = data.get('blocks', [])
            
            logger.info(f"Received {len(blocks_data)} blocks from {peer_id}")
            
            added_blocks = 0
            for block_data in blocks_data:
                try:
                    block = self._deserialize_block(block_data)
                    
                    if block.hash in self.known_blocks:
                        continue
                    
                    if self.blockchain.validate_block(block):
                        self.blockchain.add_block(block)
                        self.known_blocks.add(block.hash)
                        added_blocks += 1
                    else:
                        logger.warning(f"Received invalid block from {peer_id}: {block.hash}")
                except Exception as e:
                    logger.error(f"Error processing block from {peer_id}: {e}")
            
            if added_blocks > 0:
                logger.info(f"Added {added_blocks} new blocks to the blockchain")
                # Update mempool for transactions that are now in the blockchain
                self._update_mempool_after_sync()
    
    async def _handle_new_block(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle a broadcast of a new block.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        data = message.get('data', {})
        block_data = data.get('block')
        
        if not block_data:
            return
        
        # Check if we already know this block
        block_hash = block_data.get('hash')
        if block_hash in self.known_blocks:
            return
        
        logger.info(f"Received new block from {peer_id}: {block_hash}")
        
        try:
            block = self._deserialize_block(block_data)
            
            # Validate and add the block
            if self.blockchain.validate_block(block):
                self.blockchain.add_block(block)
                self.known_blocks.add(block.hash)
                logger.info(f"Added new block to blockchain: {block.hash}")
                
                # Broadcast to other peers
                asyncio.create_task(self.broadcast_block(block, exclude_peers=[peer_id]))
                
                # Update mempool
                self._update_mempool_after_sync()
            else:
                logger.warning(f"Received invalid block from {peer_id}: {block.hash}")
        except Exception as e:
            logger.error(f"Error processing new block from {peer_id}: {e}")
    
    async def _handle_transaction(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle a broadcast of a new transaction.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        data = message.get('data', {})
        tx_data = data.get('transaction')
        
        if not tx_data:
            return
        
        # Check if we already know this transaction
        tx_hash = tx_data.get('hash')
        if tx_hash in self.known_txs:
            return
        
        logger.info(f"Received new transaction from {peer_id}: {tx_hash}")
        
        try:
            tx = self._deserialize_transaction(tx_data)
            
            # Validate and add the transaction
            if self.blockchain.validate_transaction(tx):
                self.blockchain.add_transaction(tx)
                self.known_txs.add(tx.hash)
                logger.info(f"Added new transaction to mempool: {tx.hash}")
                
                # Broadcast to other peers
                asyncio.create_task(self.broadcast_transaction(tx, exclude_peers=[peer_id]))
            else:
                logger.warning(f"Received invalid transaction from {peer_id}: {tx.hash}")
        except Exception as e:
            logger.error(f"Error processing transaction from {peer_id}: {e}")
    
    async def _handle_get_mempool(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle a request for mempool transactions.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        logger.info(f"Received get_mempool request from {peer_id}")
        
        # Get all pending transactions
        transactions = []
        for tx in self.blockchain.pending_transactions:
            transactions.append(self._serialize_transaction(tx))
        
        await self._send_message(writer, MessageType.MEMPOOL, {'transactions': transactions})
    
    async def _handle_mempool(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle a response with mempool transactions.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        data = message.get('data', {})
        transactions_data = data.get('transactions', [])
        
        logger.info(f"Received {len(transactions_data)} mempool transactions from {peer_id}")
        
        for tx_data in transactions_data:
            try:
                tx_hash = tx_data.get('hash')
                if tx_hash in self.known_txs:
                    continue
                
                tx = self._deserialize_transaction(tx_data)
                
                # Validate and add the transaction
                if self.blockchain.validate_transaction(tx):
                    self.blockchain.add_transaction(tx)
                    self.known_txs.add(tx.hash)
                    logger.info(f"Added new transaction to mempool: {tx.hash}")
                else:
                    logger.warning(f"Received invalid transaction in mempool from {peer_id}: {tx.hash}")
            except Exception as e:
                logger.error(f"Error processing mempool transaction from {peer_id}: {e}")
    
    async def _handle_consensus_data(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle consensus related data from peers.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        data = message.get('data', {})
        consensus_type = data.get('type')
        consensus_data = data.get('data', {})
        
        logger.info(f"Received consensus data from {peer_id}: type={consensus_type}")
        
        # Handle based on consensus type
        if consensus_type == 'ProofOfWork':
            # For PoW, nothing special needed as difficulty is calculated deterministically
            pass
        elif consensus_type == 'ProofOfStake':
            # For PoS, handle stake and validator information
            validator_info = consensus_data.get('validators', [])
            stake_info = consensus_data.get('stakes', {})
            
            # Update local consensus data if using PoS
            if isinstance(self.blockchain.consensus, ProofOfStake):
                self.blockchain.consensus.update_validators(validator_info)
                self.blockchain.consensus.update_stakes(stake_info)
        elif consensus_type == 'DPoS':
            # For DPoS, handle delegate and voting information
            delegates = consensus_data.get('delegates', [])
            votes = consensus_data.get('votes', {})
            
            # Update local consensus data if using DPoS
            if isinstance(self.blockchain.consensus, DPoS):
                self.blockchain.consensus.update_delegates(delegates)
                self.blockchain.consensus.update_votes(votes)
        
        # Acknowledge receipt
        await self._send_message(writer, MessageType.CONSENSUS_DATA, {
            'status': 'received',
            'type': consensus_type
        })
    
    async def _handle_error(self, message: Dict, writer: asyncio.StreamWriter, peer_id: str):
        """
        Handle an error message from a peer.
        
        Args:
            message: The message received
            writer: The stream writer for the connection
            peer_id: The peer's node ID
        """
        data = message.get('data', {})
        error = data.get('error', 'Unknown error')
        
        logger.warning(f"Received error from peer {peer_id}: {error}")
    
    # Background tasks
    
    async def _discover_peers_task(self):
        """Background task to discover and connect to new peers."""
        while self.running:
            try:
                # First, query DHT for nodes
                dht_nodes = self.dht.get_nodes()
                
                for node in dht_nodes:
                    # Skip ourselves and already connected peers
                    if node.id == self.node_id or node.id in self.peers:
                        continue
                    
                    # Attempt to connect
                    if len(self.active_connections) < 10:  # Limit concurrent connections
                        asyncio.create_task(self.connect_to_peer(node.host, node.port))
                
                # Then, ask connected peers for more peers
                for peer_id, writer in list(self.active_connections.items()):
                    try:
                        await self._send_message(writer, MessageType.GET_PEERS)
                    except Exception as e:
                        logger.error(f"Error requesting peers from {peer_id}: {e}")
                
                # Wait before next discovery cycle
                await asyncio.sleep(60)  # Discover peers every minute
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in peer discovery task: {e}")
                await asyncio.sleep(30)  # Shorter interval on error
    
    async def _broadcast_blocks_task(self):
        """Background task to broadcast newly mined blocks."""
        last_height = len(self.blockchain.chain)
        
        while self.running:
            try:
                current_height = len(self.blockchain.chain)
                
                # Check if new blocks were added
                if current_height > last_height:
                    # Broadcast all new blocks
                    for i in range(last_height, current_height):
                        block = self.blockchain.chain[i]
                        await self.broadcast_block(block)
                    
                    last_height = current_height
                
                await asyncio.sleep(BLOCK_BROADCAST_INTERVAL)
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in block broadcast task: {e}")
                await asyncio.sleep(5)  # Shorter interval on error
    
    async def _broadcast_transactions_task(self):
        """Background task to periodically broadcast pending transactions."""
        known_tx_hashes = set()
        
        while self.running:
            try:
                # Get current mempool transactions
                current_tx_hashes = {tx.hash for tx in self.blockchain.pending_transactions}
                
                # Find new transactions
                new_tx_hashes = current_tx_hashes - known_tx_hashes
                
                if new_tx_hashes:
                    # Broadcast each new transaction
                    for tx in self.blockchain.pending_transactions:
                        if tx.hash in new_tx_hashes:
                            await self.broadcast_transaction(tx)
                    
                    known_tx_hashes = current_tx_hashes
                
                await asyncio.sleep(TRANSACTION_BROADCAST_INTERVAL)
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in transaction broadcast task: {e}")
                await asyncio.sleep(5)  # Shorter interval on error
    
    async def _sync_blockchain_task(self):
        """Background task to periodically sync blockchain with peers."""
        while self.running:
            try:
                # Only sync if we have peers
                if self.peers:
                    # Choose a random peer to sync with
                    peer_id = random.choice(list(self.peers.keys()))
                    
                    # Get a writer for this peer
                    writer = self.active_connections.get(peer_id)
                    if writer:
                        logger.info(f"Requesting blockchain sync with peer {peer_id}")
                        await self._send_message(writer, MessageType.GET_BLOCKCHAIN)
                    
                    # Also refresh mempool
                    await self._request_mempool(peer_id)
                
                await asyncio.sleep(SYNC_INTERVAL)
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in blockchain sync task: {e}")
                await asyncio.sleep(60)  # Try again after a minute
    
    # Public methods for blockchain operations
    
    async def broadcast_transaction(self, transaction: Transaction, exclude_peers: List[str] = None):
        """
        Broadcast a transaction to all connected peers.
        
        Args:
            transaction: The transaction to broadcast
            exclude_peers: Optional list of peer IDs to exclude from broadcast
        """
        if exclude_peers is None:
            exclude_peers = []
        
        # Add to known transactions
        self.known_txs.add(transaction.hash)
        
        # Serialize the transaction
        tx_data = self._serialize_transaction(transaction)
        
        # Broadcast to all connected peers
        for peer_id, writer in list(self.active_connections.items()):
            if peer_id in exclude_peers:
                continue
            
            try:
                await self._send_message(writer, MessageType.TRANSACTION, {'transaction': tx_data})
                logger.debug(f"Transaction {transaction.hash} broadcast to peer {peer_id}")
            except Exception as e:
                logger.error(f"Error broadcasting transaction to peer {peer_id}: {e}")
        
        logger.info(f"Transaction {transaction.hash} broadcast to {len(self.active_connections) - len(exclude_peers)} peers")
    
    async def broadcast_block(self, block: Block, exclude_peers: List[str] = None):
        """
        Broadcast a block to all connected peers.
        
        Args:
            block: The block to broadcast
            exclude_peers: Optional list of peer IDs to exclude from broadcast
        """
        if exclude_peers is None:
            exclude_peers = []
        
        # Add to known blocks
        self.known_blocks.add(block.hash)
        
        # Serialize the block
        block_data = self._serialize_block(block)
        
        # Broadcast to all connected peers
        for peer_id, writer in list(self.active_connections.items()):
            if peer_id in exclude_peers:
                continue
            
            try:
                await self._send_message(writer, MessageType.NEW_BLOCK, {'block': block_data})
                logger.debug(f"Block {block.hash} broadcast to peer {peer_id}")
            except Exception as e:
                logger.error(f"Error broadcasting block to peer {peer_id}: {e}")
        
        logger.info(f"Block {block.hash} broadcast to {len(self.active_connections) - len(exclude_peers)} peers")
    
    async def broadcast_consensus_data(self, consensus_type: str, data: Dict):
        """
        Broadcast consensus data to all connected peers.
        
        Args:
            consensus_type: The type of consensus (PoW, PoS, DPoS)
            data: The consensus data to broadcast
        """
        for peer_id, writer in list(self.active_connections.items()):
            try:
                await self._send_message(writer, MessageType.CONSENSUS_DATA, {
                    'type': consensus_type,
                    'data': data
                })
                logger.debug(f"Consensus data broadcast to peer {peer_id}")
            except Exception as e:
                logger.error(f"Error broadcasting consensus data to peer {peer_id}: {e}")
        
        logger.info(f"Consensus data broadcast to {len(self.active_connections)} peers")
    
    # Helper methods
    
    async def _request_blockchain(self, peer_id: str):
        """
        Request the full blockchain from a specific peer.
        
        Args:
            peer_id: The peer's node ID
        """
        writer = self.active_connections.get(peer_id)
        if not writer:
            logger.warning(f"Cannot request blockchain from peer {peer_id}: not connected")
            return
        
        try:
            await self._send_message(writer, MessageType.GET_BLOCKCHAIN)
            logger.info(f"Requested blockchain from peer {peer_id}")
        except Exception as e:
            logger.error(f"Error requesting blockchain from peer {peer_id}: {e}")
    
    async def _request_blocks(self, peer_id: str, start_height: int, end_height: int):
        """
        Request specific blocks from a peer.
        
        Args:
            peer_id: The peer's node ID
            start_height: The starting block height
            end_height: The ending block height
        """
        writer = self.active_connections.get(peer_id)
        if not writer:
            logger.warning(f"Cannot request blocks from peer {peer_id}: not connected")
            return
        
        try:
            await self._send_message(writer, MessageType.GET_BLOCKS, {
                'start': start_height,
                'end': end_height
            })
            logger.info(f"Requested blocks {start_height}-{end_height} from peer {peer_id}")
        except Exception as e:
            logger.error(f"Error requesting blocks from peer {peer_id}: {e}")
    
    async def _request_mempool(self, peer_id: str):
        """
        Request mempool transactions from a peer.
        
        Args:
            peer_id: The peer's node ID
        """
        writer = self.active_connections.get(peer_id)
        if not writer:
            logger.warning(f"Cannot request mempool from peer {peer_id}: not connected")
            return
        
        try:
            await self._send_message(writer, MessageType.GET_MEMPOOL)
            logger.info(f"Requested mempool transactions from peer {peer_id}")
        except Exception as e:
            logger.error(f"Error requesting mempool from peer {peer_id}: {e}")
    
    def _update_mempool_after_sync(self):
        """
        Update the mempool after blockchain synchronization.
        
        This removes transactions that are already included in the blockchain.
        """
        # Get all transaction hashes in the blockchain
        blockchain_tx_hashes = set()
        for block in self.blockchain.chain:
            for tx in block.transactions:
                blockchain_tx_hashes.add(tx.hash)
        
        # Filter out transactions that are already in the blockchain
        filtered_transactions = []
        for tx in self.blockchain.pending_transactions:
            if tx.hash not in blockchain_tx_hashes:
                filtered_transactions.append(tx)
            else:
                # Remove from known transactions if it's now in the blockchain
                if tx.hash in self.known_txs:
                    self.known_txs.remove(tx.hash)
        
        # Update pending transactions
        if len(filtered_transactions) != len(self.blockchain.pending_transactions):
            logger.info(f"Removed {len(self.blockchain.pending_transactions) - len(filtered_transactions)} transactions from mempool that are now in the blockchain")
            self.blockchain.pending_transactions = filtered_transactions
    
    # Serialization and deserialization methods
    
    def _serialize_blockchain(self) -> List[Dict]:
        """
        Serialize the entire blockchain for network transmission.
        
        Returns:
            A list of serialized blocks
        """
        return [self._serialize_block(block) for block in self.blockchain.chain]
    
    def _deserialize_blockchain(self, chain_data: List[Dict]) -> List[Block]:
        """
        Deserialize a blockchain received from the network.
        
        Args:
            chain_data: The serialized blockchain data
            
        Returns:
            A list of Block objects
        """
        return [self._deserialize_block(block_data) for block_data in chain_data]
    
    def _serialize_block(self, block: Block) -> Dict:
        """
        Serialize a block for network transmission.
        
        Args:
            block: The Block object to serialize
            
        Returns:
            A dictionary with the serialized block data
        """
        return {
            'index': block.index,
            'timestamp': block.timestamp,
            'transactions': [self._serialize_transaction(tx) for tx in block.transactions],
            'previous_hash': block.previous_hash,
            'hash': block.hash,
            'nonce': block.nonce,
            'difficulty': block.difficulty,
            'merkle_root': block.merkle_root,
            'miner': block.miner
        }
    
    def _deserialize_block(self, block_data: Dict) -> Block:
        """
        Deserialize a block received from the network.
        
        Args:
            block_data: The serialized block data
            
        Returns:
            A Block object
        """
        block = Block(
            index=block_data['index'],
            timestamp=block_data['timestamp'],
            transactions=[self._deserialize_transaction(tx) for tx in block_data['transactions']],
            previous_hash=block_data['previous_hash'],
            nonce=block_data['nonce'],
            difficulty=block_data['difficulty'],
            miner=block_data['miner']
        )
        
        # Set the hash manually since we're deserializing a completed block
        block.hash = block_data['hash']
        block.merkle_root = block_data['merkle_root']
        
        return block
    
    def _serialize_transaction(self, transaction: Transaction) -> Dict:
        """
        Serialize a transaction for network transmission.
        
        Args:
            transaction: The Transaction object to serialize
            
        Returns:
            A dictionary with the serialized transaction data
        """
        return {
            'sender': transaction.sender,
            'recipient': transaction.recipient,
            'amount': float(transaction.amount),
            'fee': float(transaction.fee),
            'timestamp': transaction.timestamp,
            'signature': transaction.signature,
            'nonce': transaction.nonce,
            'hash': transaction.hash,
            'data': transaction.data
        }
    
    def _deserialize_transaction(self, tx_data: Dict) -> Transaction:
        """
        Deserialize a transaction received from the network.
        
        Args:
            tx_data: The serialized transaction data
            
        Returns:
            A Transaction object
        """
        tx = Transaction(
            sender=tx_data['sender'],
            recipient=tx_data['recipient'],
            amount=float(tx_data['amount']),
            fee=float(tx_data['fee']),
            data=tx_data.get('data', None)
        )
        
        # Set additional properties manually
        tx.timestamp = tx_data['timestamp']
        tx.signature = tx_data['signature']
        tx.nonce = tx_data['nonce']
        tx.hash = tx_data['hash']
        
        return tx
