#!/usr/bin/env python3
"""
Pacata Cryptocurrency Wallet

This module implements a simple cryptocurrency wallet for the Pacata mesh VPN.
It provides functionality for key generation, address creation, balance checking,
transaction creation and signing, and viewing transaction history.
"""

import os
import json
import time
import hashlib
import base64
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime

import click
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.serialization import load_pem_private_key
from cryptography.exceptions import InvalidSignature

logger = logging.getLogger(__name__)

WALLET_DIR = Path.home() / ".pacata" / "wallets"
DEFAULT_WALLET_NAME = "default"
TRANSACTION_FEE = 0.001  # 0.1% transaction fee
DEVELOPER_FEE = 0.0005  # 0.05% developer fee
DEVELOPER_ADDRESS = "pacata1developer000000000000000000000000000000"


class PacataWallet:
    """Implements a cryptocurrency wallet for the Pacata mesh VPN."""

    def __init__(self, name: str = DEFAULT_WALLET_NAME):
        """
        Initialize a Pacata wallet.

        Args:
            name: The name of the wallet.
        """
        self.name = name
        self.private_key = None
        self.public_key = None
        self.address = None
        self.wallet_path = WALLET_DIR / f"{name}.json"
        
        # Create wallet directory if it doesn't exist
        if not WALLET_DIR.exists():
            WALLET_DIR.mkdir(parents=True)
        
        # Load wallet if it exists, otherwise initialize a new one
        if self.wallet_path.exists():
            self.load_wallet()
        else:
            self.generate_keys()
            self.save_wallet()

    def generate_keys(self) -> None:
        """Generate a new key pair for the wallet."""
        # Generate private key
        self.private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        
        # Get public key
        self.public_key = self.private_key.public_key()
        
        # Generate address from public key
        self.address = self._generate_address_from_public_key()
        
        logger.info(f"Generated new wallet with address: {self.address}")

    def _generate_address_from_public_key(self) -> str:
        """
        Generate a unique address from the public key.
        
        Returns:
            A string representation of the wallet address.
        """
        # Export public key to bytes
        public_key_bytes = self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        # Hash the public key
        hash_obj = hashlib.sha256(public_key_bytes)
        hashed = hash_obj.digest()
        
        # Take the first 20 bytes of the hash and convert to hex
        address_bytes = hashed[:20]
        address_hex = address_bytes.hex()
        
        # Add the "pacata1" prefix
        return f"pacata1{address_hex}"

    def save_wallet(self) -> None:
        """Save the wallet to a file."""
        try:
            # Serialize private key
            private_key_pem = self.private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            
            # Create wallet data
            wallet_data = {
                "name": self.name,
                "address": self.address,
                "private_key_pem": private_key_pem.decode('utf-8'),
                "created_at": datetime.now().isoformat()
            }
            
            # Save to file
            with open(self.wallet_path, 'w') as f:
                json.dump(wallet_data, f, indent=2)
                
            logger.info(f"Wallet saved to {self.wallet_path}")
        except Exception as e:
            logger.error(f"Failed to save wallet: {e}")
            raise

    def load_wallet(self) -> None:
        """Load a wallet from a file."""
        try:
            with open(self.wallet_path, 'r') as f:
                wallet_data = json.load(f)
            
            # Load wallet data
            self.name = wallet_data["name"]
            self.address = wallet_data["address"]
            
            # Load private key
            private_key_pem = wallet_data["private_key_pem"].encode('utf-8')
            self.private_key = load_pem_private_key(
                private_key_pem,
                password=None
            )
            
            # Get public key
            self.public_key = self.private_key.public_key()
            
            logger.info(f"Loaded wallet with address: {self.address}")
        except Exception as e:
            logger.error(f"Failed to load wallet: {e}")
            raise

    def get_balance(self, blockchain) -> float:
        """
        Get the current balance of the wallet.
        
        Args:
            blockchain: An instance of the blockchain to query for balance.
            
        Returns:
            The current balance of the wallet.
        """
        # This would typically query the blockchain
        # For now, we'll simulate it
        return blockchain.get_balance(self.address)

    def create_transaction(self, recipient: str, amount: float, blockchain) -> Dict:
        """
        Create a new transaction.
        
        Args:
            recipient: The recipient's address.
            amount: The amount to send.
            blockchain: An instance of the blockchain.
            
        Returns:
            A transaction dictionary.
        """
        # Check if we have enough balance
        balance = self.get_balance(blockchain)
        total_amount = amount + (amount * TRANSACTION_FEE) + (amount * DEVELOPER_FEE)
        
        if balance < total_amount:
            raise ValueError(f"Insufficient balance. Have {balance}, need {total_amount}")
        
        # Create transaction
        timestamp = int(time.time())
        transaction = {
            "sender": self.address,
            "recipient": recipient,
            "amount": amount,
            "timestamp": timestamp,
            "fee": amount * TRANSACTION_FEE,
            "dev_fee": amount * DEVELOPER_FEE,
            "nonce": blockchain.get_nonce(self.address)
        }
        
        # Add developer fee transaction
        dev_transaction = {
            "sender": self.address,
            "recipient": DEVELOPER_ADDRESS,
            "amount": amount * DEVELOPER_FEE,
            "timestamp": timestamp,
            "fee": 0,  # No fee for the developer fee transaction
            "dev_fee": 0,  # No developer fee for the developer fee transaction
            "nonce": blockchain.get_nonce(self.address) + 1
        }
        
        # Sign transactions
        transaction["signature"] = self._sign_transaction(transaction)
        dev_transaction["signature"] = self._sign_transaction(dev_transaction)
        
        return {
            "main_transaction": transaction,
            "dev_transaction": dev_transaction
        }

    def _sign_transaction(self, transaction: Dict) -> str:
        """
        Sign a transaction with the private key.
        
        Args:
            transaction: The transaction to sign.
            
        Returns:
            The signature as a base64-encoded string.
        """
        # Create a copy of the transaction without the signature
        tx_copy = transaction.copy()
        if "signature" in tx_copy:
            del tx_copy["signature"]
        
        # Serialize transaction to JSON and encode as bytes
        tx_bytes = json.dumps(tx_copy, sort_keys=True).encode('utf-8')
        
        # Sign the transaction
        signature = self.private_key.sign(
            tx_bytes,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        
        # Return base64-encoded signature
        return base64.b64encode(signature).decode('utf-8')

    def verify_transaction(self, transaction: Dict, public_key) -> bool:
        """
        Verify a transaction's signature.
        
        Args:
            transaction: The transaction to verify.
            public_key: The sender's public key.
            
        Returns:
            True if the signature is valid, False otherwise.
        """
        # Get the signature
        signature = base64.b64decode(transaction["signature"])
        
        # Create a copy of the transaction without the signature
        tx_copy = transaction.copy()
        del tx_copy["signature"]
        
        # Serialize transaction to JSON and encode as bytes
        tx_bytes = json.dumps(tx_copy, sort_keys=True).encode('utf-8')
        
        try:
            # Verify the signature
            public_key.verify(
                signature,
                tx_bytes,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            return True
        except InvalidSignature:
            return False

    def get_transaction_history(self, blockchain) -> List[Dict]:
        """
        Get the transaction history for this wallet.
        
        Args:
            blockchain: An instance of the blockchain.
            
        Returns:
            A list of transactions involving this wallet.
        """
        # This would typically query the blockchain
        # For now, we'll simulate it
        return blockchain.get_transactions_for_address(self.address)

    def send(self, recipient: str, amount: float, blockchain) -> Dict:
        """
        Send Pacata tokens to another address.
        
        Args:
            recipient: The recipient's address.
            amount: The amount to send.
            blockchain: An instance of the blockchain.
            
        Returns:
            The result of the transaction.
        """
        # Create transaction
        transactions = self.create_transaction(recipient, amount, blockchain)
        
        # Submit to blockchain
        result = blockchain.add_transaction(transactions["main_transaction"])
        blockchain.add_transaction(transactions["dev_transaction"])
        
        return result


@click.group()
def cli():
    """Pacata Cryptocurrency Wallet CLI."""
    pass


@cli.command()
@click.option('--name', default=DEFAULT_WALLET_NAME, help='Wallet name')
def create(name):
    """Create a new wallet."""
    wallet_path = WALLET_DIR / f"{name}.json"
    if wallet_path.exists():
        click.echo(f"Wallet '{name}' already exists.")
        return
    
    try:
        wallet = PacataWallet(name)
        click.echo(f"Created new wallet: {wallet.address}")
        click.echo(f"Wallet saved to: {wallet.wallet_path}")
    except Exception as e:
        click.echo(f"Error creating wallet: {e}")


@cli.command()
def list():
    """List all available wallets."""
    if not WALLET_DIR.exists():
        click.echo("No wallets found.")
        return
    
    wallets = list(WALLET_DIR.glob("*.json"))
    if not wallets:
        click.echo("No wallets found.")
        return
    
    click.echo("Available wallets:")
    for wallet_path in wallets:
        name = wallet_path.stem
        try:
            with open(wallet_path, 'r') as f:
                wallet_data = json.load(f)
            click.echo(f"  {name}: {wallet_data['address']}")
        except:
            click.echo(f"  {name}: (error loading wallet)")


@cli.command()
@click.option('--name', default=DEFAULT_WALLET_NAME, help='Wallet name')
def info(name):
    """Show wallet information."""
    try:
        wallet = PacataWallet(name)
        click.echo(f"Wallet: {wallet.name}")
        click.echo(f"Address: {wallet.address}")
        
        # In a real implementation, we would query the blockchain here
        # For now, we'll just show placeholder text
        click.echo("Balance: (connect to blockchain to view)")
    except Exception as e:
        click.echo(f"Error loading wallet: {e}")


@cli.command()
@click.option('--name', default=DEFAULT_WALLET_NAME, help='Wallet name')
@click.argument('recipient')
@click.argument('amount', type=float)
def send(name, recipient, amount):
    """Send Pacata tokens to another address."""
    try:
        wallet = PacataWallet(name)
        click.echo(f"Sending {amount} PAC from {wallet.address} to {recipient}")
        
        # In a real implementation, we would interact with the blockchain here
        # For now, we'll just show placeholder text
        click.echo("Transaction created (connect to blockchain to submit)")
    except Exception as e:
        click.echo(f"Error: {e}")


@cli.command()
@click.option('--name', default=DEFAULT_WALLET_NAME, help='Wallet name')
def history(name):
    """View transaction history."""
    try:
        wallet = PacataWallet(name)
        click.echo(f"Transaction history for {wallet.address}")
        
        # In a real implementation, we would query the blockchain here
        # For now, we'll just show placeholder text
        click.echo("(connect to blockchain to view history)")
    except Exception as e:
        click.echo(f"Error: {e}")


def run_wallet():
    """Entry point for the pacata-wallet command."""
    try:
        cli()
    except Exception as e:
        click.echo(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    import sys
    run_wallet()

