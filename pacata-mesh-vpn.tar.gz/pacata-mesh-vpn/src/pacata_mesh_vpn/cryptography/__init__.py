"""
Cryptography module for Pacata Mesh VPN.

This module provides cryptographic functionality for secure communications within the
Pacata Mesh VPN network, including encryption, decryption, key management, and authentication.
"""

# Import key functionality to expose at the package level
from .encryption import encrypt_data, decrypt_data
from .encryption import generate_key, derive_shared_key
from .encryption import compute_mac, verify_mac
from .encryption import encrypt_with_mac, decrypt_with_mac
from .encryption import generate_keys, encrypt_traffic, decrypt_traffic
from .crypto_manager import CryptoManager

__all__ = [
    'encrypt_data',
    'decrypt_data',
    'generate_key',
    'derive_shared_key',
    'compute_mac',
    'verify_mac',
    'encrypt_with_mac',
    'decrypt_with_mac',
    'generate_keys',
    'encrypt_traffic',
    'decrypt_traffic',
    'CryptoManager',
]
