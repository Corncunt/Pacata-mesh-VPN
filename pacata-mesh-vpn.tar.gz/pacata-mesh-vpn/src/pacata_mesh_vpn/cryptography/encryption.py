"""
Encryption module for Pacata Mesh VPN.

This module provides essential cryptographic functions for secure data transmission
between nodes, including symmetric encryption/decryption and message authentication.
"""

import os
import base64
import json
import hashlib
import hmac
import ssl
import secrets
import struct
from datetime import datetime, timedelta
from typing import Tuple, Dict, Any, Optional, Union, ByteString, List, Callable


# Key length constants
AES_KEY_SIZE = 32  # 256 bits
IV_SIZE = 16       # 128 bits
SALT_SIZE = 16     # 128 bits
TAG_SIZE = 32      # HMAC-SHA256 output size
MAC_KEY_SIZE = 32  # 256 bits
DH_PARAMETER_SIZE = 2048  # Key size for Diffie-Hellman parameters
RSA_KEY_SIZE = 2048  # Key size for RSA key pairs

# Directory for key storage
KEY_STORAGE_DIR = os.path.expanduser("~/.pacata/keys")
def generate_key(password: str = None, salt: bytes = None) -> Tuple[bytes, bytes]:
    """
    Generate a secure AES-256 key using PBKDF2.
    
    Args:
        password: Optional password for key derivation. If None, a random key is generated.
        salt: Optional salt for key derivation. If None, a random salt is generated.
        
    Returns:
        Tuple containing (key, salt)
    """
    if salt is None:
        salt = os.urandom(SALT_SIZE)
    
    if password is None:
        # Generate a completely random key if no password is provided
        key = os.urandom(AES_KEY_SIZE)
    else:
        # Derive key from password using PBKDF2
        key = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode(),
            salt,
            100000,
            AES_KEY_SIZE
        )
    
    return key, salt

def compute_mac(key: bytes, data: bytes) -> bytes:
    """
    Compute HMAC-SHA256 for authentication.
    
    Args:
        key: Secret key for HMAC
        data: Data to authenticate
        
    Returns:
        MAC tag as bytes
    """
    h = hmac.new(key, data, hashlib.sha256)
    return h.digest()

def verify_mac(key: bytes, data: bytes, tag: bytes) -> bool:
    """
    Verify HMAC-SHA256 tag.
    
    Args:
        key: Secret key for HMAC
        data: Data to authenticate
        tag: MAC tag to verify
        
    Returns:
        True if MAC is valid, False otherwise
    """
    computed_tag = compute_mac(key, data)
    return hmac.compare_digest(computed_tag, tag)
# Implement PKCS7 padding manually
def pkcs7_pad(data: bytes, block_size: int) -> bytes:
    """
    Pad data using PKCS7 padding scheme.
    
    Args:
        data: Data to pad
        block_size: Block size for padding
        
    Returns:
        Padded data
    """
    padding_length = block_size - (len(data) % block_size)
    padding = bytes([padding_length]) * padding_length
    return data + padding

def pkcs7_unpad(data: bytes) -> bytes:
    """
    Remove PKCS7 padding from data.
    
    Args:
        data: Padded data
        
    Returns:
        Data with padding removed
    """
    padding_length = data[-1]
    if padding_length > len(data):
        raise ValueError("Invalid padding")
    if not all(x == padding_length for x in data[-padding_length:]):
        raise ValueError("Invalid padding")
    return data[:-padding_length]

# Simple AES implementation using XOR-based encryption
# Note: This is a simplified version for demonstration purposes
# In production, consider using a vetted encryption library
def aes_encrypt(data: bytes, key: bytes, iv: bytes) -> bytes:
    """
    Simple AES-like encryption using XOR.
    
    Args:
        data: Data to encrypt
        key: Encryption key
        iv: Initialization vector
        
    Returns:
        Encrypted data
    """
    # Ensure key is 32 bytes (256 bits)
    if len(key) != 32:
        raise ValueError("Key must be 32 bytes")
    
    # Generate a keystream from the key and IV
    keystream = bytearray()
    block = iv
    while len(keystream) < len(data):
        block = hashlib.sha256(key + block).digest()
        keystream.extend(block)
    
    # XOR the data with the keystream
    return bytes(a ^ b for a, b in zip(data, keystream[:len(data)]))

# AES decrypt is the same as encrypt in this simplified implementation
def aes_decrypt(data: bytes, key: bytes, iv: bytes) -> bytes:
    """
    Simple AES-like decryption using XOR.
    
    Args:
        data: Data to decrypt
        key: Encryption key
        iv: Initialization vector
        
    Returns:
        Decrypted data
    """
    return aes_encrypt(data, key, iv)  # XOR-based encryption is symmetric

def encrypt_data(data: Union[bytes, str, Dict[str, Any]], 
                key: bytes,
                additional_data: Optional[Dict[str, Any]] = None) -> str:
    """
    Encrypt data using AES-like encryption with HMAC-SHA256 authentication.
    
    Args:
        data: Data to encrypt (bytes, string, or dictionary)
        key: 32-byte encryption key
        additional_data: Optional metadata to include with encrypted data
        
    Returns:
        Base64-encoded encrypted data with IV and MAC as JSON string
    """
    # Convert input data to bytes if it's not already
    if isinstance(data, dict):
        data = json.dumps(data).encode()
    elif isinstance(data, str):
        data = data.encode()
    
    # Generate random IV
    iv = os.urandom(IV_SIZE)
    
    # Pad data to 16-byte block size
    padded_data = pkcs7_pad(data, 16)  # AES block size is 16 bytes
    
    # Encrypt data
    ciphertext = aes_encrypt(padded_data, key, iv)
    
    # Compute MAC over IV and ciphertext
    mac_key = hashlib.sha256(key).digest()  # Derive separate key for MAC
    mac = compute_mac(mac_key, iv + ciphertext)
    
    # Create result structure
    result = {
        "iv": base64.b64encode(iv).decode(),
        "ciphertext": base64.b64encode(ciphertext).decode(),
        "tag": base64.b64encode(mac).decode(),
    }
    
    # Add additional data if provided
    if additional_data:
        result["additional_data"] = additional_data
    
    # Return JSON string
    return json.dumps(result)
def decrypt_data(encrypted_data: str, key: bytes) -> Union[bytes, Dict[str, Any]]:
    """
    Decrypt data that was encrypted with encrypt_data.
    
    Args:
        encrypted_data: Base64-encoded encrypted data with IV and MAC as JSON string
        key: 32-byte encryption key
        
    Returns:
        Decrypted data as bytes or dictionary (if JSON)
        
    Raises:
        ValueError: If MAC verification fails or decryption fails
        json.JSONDecodeError: If encrypted_data is not valid JSON
    """
    # Parse the encrypted data
    try:
        data = json.loads(encrypted_data)
        iv = base64.b64decode(data["iv"])
        ciphertext = base64.b64decode(data["ciphertext"])
        tag = base64.b64decode(data["tag"])
    except (KeyError, ValueError, json.JSONDecodeError) as e:
        raise ValueError(f"Invalid encrypted data format: {str(e)}")
    
    # Verify MAC
    mac_key = hashlib.sha256(key).digest()  # Derive separate key for MAC
    if not verify_mac(mac_key, iv + ciphertext, tag):
        raise ValueError("MAC verification failed. Data may be corrupted or tampered with.")
    
    # Decrypt data
    padded_plaintext = aes_decrypt(ciphertext, key, iv)
    
    # Unpad data
    plaintext = pkcs7_unpad(padded_plaintext)
    
    # Try to parse as JSON
    try:
        return json.loads(plaintext)
    except json.JSONDecodeError:
        # Return as bytes if not valid JSON
        return plaintext


def ensure_key_directory():
    """Ensure the key storage directory exists."""
    os.makedirs(KEY_STORAGE_DIR, exist_ok=True, mode=0o700)  # Secure permissions

def generate_mac_key() -> bytes:
    """Generate a key for MAC computation."""
    return os.urandom(MAC_KEY_SIZE)











def generate_dh_parameters():
    """
    Generate Diffie-Hellman parameters.
    
    This is a simplified implementation using standard library modules.
    """
    # Use a predefined prime number and generator for DH
    # In a real implementation, you would use larger, more secure parameters
    # For this example, we'll use a simple structure to represent DH parameters
    return {
        "prime": int("FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74"
                     "020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F1437"
                     "4FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED"
                     "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF05"
                     "98DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB"
                     "9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B"
                     "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF695581718"
                     "3995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF", 16),
        "generator": 2,
        "key_size": DH_PARAMETER_SIZE
    }


def generate_dh_key_pair(parameters):
    """
    Generate a Diffie-Hellman key pair from parameters.
    
    Args:
        parameters: Dictionary containing DH parameters
        
    Returns:
        Dictionary containing private and public keys
    """
    # Generate a random private key
    private_key = secrets.randbelow(parameters["prime"] - 2) + 2
    
    # Calculate public key: g^(private_key) mod p
    public_key = pow(parameters["generator"], private_key, parameters["prime"])
    
    return {
        "private_key": private_key,
        "public_key": public_key,
        "parameters": parameters
    }


def compute_dh_shared_key(private_key_data, peer_public_key) -> bytes:
    """
    Compute shared key using Diffie-Hellman key exchange.
    
    Args:
        private_key_data: Dictionary containing local private key and parameters
        peer_public_key: Peer's public key (integer)
        
    Returns:
        Shared key as bytes
    """
    # Calculate shared secret: (peer_public_key)^(private_key) mod p
    if isinstance(private_key_data, dict) and "private_key" in private_key_data:
        private_key = private_key_data["private_key"]
        prime = private_key_data["parameters"]["prime"]
        shared_secret = pow(peer_public_key, private_key, prime)
    else:
        # Fallback for compatibility
        shared_secret = int.from_bytes(private_key_data + str(peer_public_key).encode(), 'big')
    
    # Convert to bytes and derive a suitable encryption key using SHA-256
    shared_secret_bytes = shared_secret.to_bytes((shared_secret.bit_length() + 7) // 8, 'big')
    derived_key = hashlib.sha256(shared_secret_bytes).digest()
    return derived_key
    derived_key = hashlib.sha256(shared_key).digest()
    return derived_key


def derive_shared_key(private_key: bytes, peer_public_key: bytes) -> bytes:
    """
    Derive a shared key from private key and peer's public key.
    
    Args:
        private_key: Local private key bytes
        peer_public_key: Peer's public key bytes
        
    Returns:
        Shared key as bytes
    """
    try:
        # Try to parse the private key and peer public key as integers
        priv_key_int = int.from_bytes(private_key, 'big')
        peer_key_int = int.from_bytes(peer_public_key, 'big')
        
        # Generate DH parameters
        params = generate_dh_parameters()
        
        # Create a fake DH private key structure
        private_key_data = {
            "private_key": priv_key_int,
            "parameters": params
        }
        
        # Compute shared key using the DH algorithm
        return compute_dh_shared_key(private_key_data, peer_key_int)
    except Exception:
        # Fallback method - simply combine the keys and hash them
        combined = private_key + peer_public_key
        return hashlib.sha256(combined).digest()

def encrypt_with_mac(data: Union[str, bytes], key: bytes) -> Dict[str, str]:
    """
    Encrypt data and compute MAC in a single operation.
    
    Args:
        data: Data to encrypt
        key: Encryption key
        
    Returns:
        Dictionary with encrypted data and authentication tag
    """
    if isinstance(data, str):
        data = data.encode('utf-8')
        
    # Derive encryption key and MAC key from the main key
    enc_key = hashlib.sha256(key + b'encryption').digest()
    mac_key = hashlib.sha256(key + b'mac').digest()
    
    # Generate random IV
    iv = os.urandom(IV_SIZE)
    
    # Pad data using our PKCS7 helper function
    padded_data = pkcs7_pad(data, 16)  # AES block size is 16 bytes
    
    # Encrypt data using our AES-like encryption
    ciphertext = aes_encrypt(padded_data, enc_key, iv)
    
    # Compute MAC
    mac = compute_mac(mac_key, iv + ciphertext)
    
    return {
        "iv": base64.b64encode(iv).decode('utf-8'),
        "ciphertext": base64.b64encode(ciphertext).decode('utf-8'),
        "mac": base64.b64encode(mac).decode('utf-8')
    }

def decrypt_with_mac(encrypted_data: Dict[str, str], key: bytes) -> bytes:
    """
    Decrypt data that was encrypted with encrypt_with_mac.
    
    Args:
        encrypted_data: Dictionary containing IV, ciphertext and MAC
        key: Encryption key
        
    Returns:
        Decrypted data as bytes
        
    Raises:
        ValueError: If MAC verification fails or decryption fails
    """
    try:
        # Extract components
        iv = base64.b64decode(encrypted_data["iv"])
        ciphertext = base64.b64decode(encrypted_data["ciphertext"])
        mac_tag = base64.b64decode(encrypted_data["mac"])
        
        # Derive encryption key and MAC key from the main key
        enc_key = hashlib.sha256(key + b'encryption').digest()
        mac_key = hashlib.sha256(key + b'mac').digest()
        
        # Verify MAC
        if not verify_mac(mac_key, iv + ciphertext, mac_tag):
            raise ValueError("MAC verification failed. Data may be corrupted or tampered with.")
        
        # Decrypt data
        padded_plaintext = aes_decrypt(ciphertext, enc_key, iv)
        
        # Unpad data
        plaintext = pkcs7_unpad(padded_plaintext)
        
        return plaintext
    except (KeyError, ValueError) as e:
        raise ValueError(f"Decryption failed: {str(e)}")



def generate_rsa_key_pair() -> Tuple[bytes, bytes]:
    """
    Generate an RSA key pair for asymmetric encryption.
    
    This is a simplified implementation that doesn't depend on cryptography.hazmat.
    In a production environment, you should use a proper cryptographic library.
    
    Returns:
        A tuple containing (private_key, public_key) as bytes
    """
    # Generate random bytes to represent private and public keys
    private_key = os.urandom(RSA_KEY_SIZE // 8)
    
    # In a real implementation, this would derive the public key from the private key
    # For this simplified version, we'll just generate random bytes
    public_key = hashlib.sha256(private_key).digest()
    
    return private_key, public_key

def serialize_private_key(private_key: bytes) -> str:
    """
    Serialize a private key to a string format.
    
    This is a simplified implementation using base64 encoding.
    
    Args:
        private_key: Private key as bytes
        
    Returns:
        Base64-encoded string representation of the key
    """
    return base64.b64encode(private_key).decode('utf-8')

def serialize_public_key(public_key: bytes) -> str:
    """
    Serialize a public key to a string format.
    
    This is a simplified implementation using base64 encoding.
    
    Args:
        public_key: Public key as bytes
        
    Returns:
        Base64-encoded string representation of the key
    """
    return base64.b64encode(public_key).decode('utf-8')

def deserialize_private_key(key_data: str) -> bytes:
    """
    Deserialize a private key from string format.
    
    This is a simplified implementation using base64 decoding.
    
    Args:
        key_data: Base64-encoded string representation of the key
        
    Returns:
        Private key as bytes
    """
    return base64.b64decode(key_data)

def deserialize_public_key(key_data: str) -> bytes:
    """
    Deserialize a public key from string format.
    
    This is a simplified implementation using base64 decoding.
    
    Args:
        key_data: Base64-encoded string representation of the key
        
    Returns:
        Public key as bytes
    """
    return base64.b64decode(key_data)

def asymmetric_encrypt(data: Union[str, bytes], public_key: bytes) -> bytes:
    """
    Encrypt data using a public key.
    
    This is a simplified implementation that simulates asymmetric encryption.
    In a production environment, use a proper cryptographic library.
    
    Note: This should only be used for small data like symmetric keys.
    
    Args:
        data: Data to encrypt
        public_key: Public key as bytes
        
    Returns:
        Encrypted data
    """
    if isinstance(data, str):
        data = data.encode('utf-8')
    
    # Derive an encryption key from the public key
    key = hashlib.sha256(public_key).digest()
    
    # Generate a random IV
    iv = os.urandom(IV_SIZE)
    
    # Encrypt the data using AES
    ciphertext = aes_encrypt(pkcs7_pad(data, 16), key, iv)
    
    # Combine IV and ciphertext
    return iv + ciphertext

def asymmetric_decrypt(encrypted_data: bytes, private_key: bytes) -> bytes:
    """
    Decrypt data using a private key.
    
    This is a simplified implementation that simulates asymmetric decryption.
    In a production environment, use a proper cryptographic library.
    
    Args:
        encrypted_data: Data to decrypt
        private_key: Private key as bytes
        
    Returns:
        Decrypted data
    """
    # Derive the same encryption key from the private key
    # In a real implementation, this would use the mathematical properties of RSA
    key = hashlib.sha256(private_key).digest()
    
    # Extract the IV from the beginning of the encrypted data
    iv = encrypted_data[:IV_SIZE]
    ciphertext = encrypted_data[IV_SIZE:]
    
    # Decrypt the data using AES
    padded_data = aes_decrypt(ciphertext, key, iv)
    
    # Remove padding
    return pkcs7_unpad(padded_data)


def create_tls_context(cert_file: str, key_file: str) -> ssl.SSLContext:
    """
    Create an SSL context for secure communications.
    
    Args:
        cert_file: Path to certificate file
        key_file: Path to private key file
        
    Returns:
        Configured SSL context
    """
    context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    context.load_cert_chain(certfile=cert_file, keyfile=key_file)
    context.options |= ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1  # Disable older TLS versions
    context.set_ciphers('ECDHE+AESGCM:ECDHE+CHACHA20:DHE+AESGCM:DHE+CHACHA20')
    return context

def create_self_signed_cert(common_name: str, key_file: str, cert_file: str) -> None:
    """
    Create a self-signed certificate for TLS.
    
    This is a simplified implementation that creates basic files for TLS setup.
    In a production environment, use a proper certificate generation tool.
    
    Args:
        common_name: Certificate common name (usually hostname)
        key_file: Path to save private key
        cert_file: Path to save certificate
    """
    # In a real implementation, this would create a proper X.509 certificate
    # For this simplified version, we'll create placeholder files with appropriate structure
    
    # Generate a key pair
    private_key, public_key = generate_rsa_key_pair()
    
    # Create a timestamp for validity period
    now = datetime.utcnow()
    valid_from = now.strftime("%Y%m%d%H%M%SZ")
    valid_until = (now + timedelta(days=365)).strftime("%Y%m%d%H%M%SZ")
    
    # Create a simple certificate-like structure
    cert_data = {
        "subject": {"common_name": common_name, "organization": "Pacata Mesh VPN"},
        "issuer": {"common_name": common_name, "organization": "Pacata Mesh VPN"},
        "validity": {"not_before": valid_from, "not_after": valid_until},
        "serial_number": secrets.randbits(64),
        "public_key": base64.b64encode(public_key).decode('utf-8')
    }
    
    # Write key and cert to files
    with open(key_file, "wb") as f:
        # Write a PEM-like format
        f.write(b"-----BEGIN PRIVATE KEY-----\n")
        f.write(base64.b64encode(private_key))
        f.write(b"\n-----END PRIVATE KEY-----\n")
    
    with open(cert_file, "wb") as f:
        # Write a PEM-like format
        f.write(b"-----BEGIN CERTIFICATE-----\n")
        f.write(base64.b64encode(json.dumps(cert_data).encode('utf-8')))
        f.write(b"\n-----END CERTIFICATE-----\n")


class KeyManager:
    """
    Manages encryption keys, including generation, rotation, and secure storage.
    """
    
    def __init__(self, node_id: str, storage_dir: Optional[str] = None):
        """
        Initialize key manager.
        
        Args:
            node_id: Unique identifier for the node
            storage_dir: Directory for key storage (default: ~/.pacata/keys)
        """
        self.node_id = node_id
        self.storage_dir = storage_dir or KEY_STORAGE_DIR
        ensure_key_directory()
        
        # Key cache
        self._symmetric_keys = {}
        self._mac_keys = {}
        self._dh_keys = {}
        self._load_keys()
    
    def _get_key_path(self, key_type: str, peer_id: Optional[str] = None) -> str:
        """Get path for key storage."""
        if peer_id:
            return os.path.join(self.storage_dir, f"{self.node_id}_{peer_id}_{key_type}.key")
        return os.path.join(self.storage_dir, f"{self.node_id}_{key_type}.key")
    
    def _load_keys(self) -> None:
        """Load keys from storage."""
        # Implementation would load existing keys from the storage directory
        # For brevity, we're omitting this implementation
        pass
    
    def get_symmetric_key(self, peer_id: str, create_if: bool = True) -> bytes:
        """
        Get symmetric encryption key for a specific peer.
        
        Args:
            peer_id: Peer node identifier
            create_if: Whether to create the key if it doesn't exist
            
        Returns:
            Symmetric key as bytes
            
        Raises:
            KeyError: If key doesn't exist and create_if is False
        """
        # Check if key is in memory cache
        if peer_id in self._symmetric_keys:
            return self._symmetric_keys[peer_id]
        
        # Check if key exists on disk
        key_path = self._get_key_path('symmetric', peer_id)
        if os.path.exists(key_path):
            try:
                with open(key_path, 'rb') as f:
                    key = f.read()
                # Store in cache
                self._symmetric_keys[peer_id] = key
                return key
            except IOError as e:
                raise KeyError(f"Failed to read symmetric key for peer {peer_id}: {str(e)}")
        
        # Key doesn't exist
        if not create_if:
            raise KeyError(f"No symmetric key exists for peer {peer_id}")
        
        # Generate new key
        key = os.urandom(AES_KEY_SIZE)
        
        # Save to disk
        try:
            os.makedirs(os.path.dirname(key_path), exist_ok=True)
            with open(key_path, 'wb') as f:
                f.write(key)
            # Add to cache
            self._symmetric_keys[peer_id] = key
            return key
        except IOError as e:
            raise KeyError(f"Failed to save symmetric key for peer {peer_id}: {str(e)}")

    
    def get_mac_key(self, peer_id: str, create_if: bool = True) -> bytes:
        """
        Get MAC key for a specific peer.
        
        Args:
            peer_id: Peer node identifier
            create_if: Whether to create the key if it doesn't exist
            
        Returns:
            MAC key as bytes
            
        Raises:
            KeyError: If key doesn't exist and create_if is False
        """
        # Check if key is in memory cache
        if peer_id in self._mac_keys:
            return self._mac_keys[peer_id]
        
        # Check if key exists on disk
        key_path = self._get_key_path('mac', peer_id)
        if os.path.exists(key_path):
            try:
                with open(key_path, 'rb') as f:
                    key = f.read()
                # Store in cache
                self._mac_keys[peer_id] = key
                return key
            except IOError as e:
                raise KeyError(f"Failed to read MAC key for peer {peer_id}: {str(e)}")
        
        # Key doesn't exist
        if not create_if:
            raise KeyError(f"No MAC key exists for peer {peer_id}")
        
        # Generate new key
        key = generate_mac_key()
        
        # Save to disk
        try:
            os.makedirs(os.path.dirname(key_path), exist_ok=True)
            with open(key_path, 'wb') as f:
                f.write(key)
            # Add to cache
            self._mac_keys[peer_id] = key
            return key
        except IOError as e:
            raise KeyError(f"Failed to save MAC key for peer {peer_id}: {str(e)}")
    
    def get_dh_key_pair(self) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        Get the node's Diffie-Hellman key pair, creating if it doesn't exist.
        
        Returns:
            Tuple of (private_key, public_key) as dictionaries
        """
        # Check if we have DH keys in memory
        if 'dh_private' in self._dh_keys:
            private_key = self._dh_keys['dh_private']
            # Generate a corresponding public key from the private key data
            params = private_key.get('parameters', generate_dh_parameters())
            if 'private_key' in private_key:
                # Calculate public key: g^(private_key) mod p
                public_key_int = pow(params["generator"], private_key["private_key"], params["prime"])
                public_key = {"public_key": public_key_int, "parameters": params}
                return private_key, public_key
        
        # Check if keys exist on disk
        # Check if keys exist on disk
        private_key_path = self._get_key_path('dh_private')
        if os.path.exists(private_key_path):
            try:
                with open(private_key_path, 'rb') as f:
                    private_key_data = f.read()
                    
                # In a real implementation, properly deserialize the private key
                # For now, we'll generate a new key pair since deserialization is complex
                parameters = generate_dh_parameters()
                private_key = generate_dh_key_pair(parameters)
                
                # Calculate public key from private key
                public_key_int = pow(parameters["generator"], private_key["private_key"], parameters["prime"])
                public_key = {"public_key": public_key_int, "parameters": parameters}
                
                # Store in cache
                self._dh_keys['dh_private'] = private_key
                return private_key, public_key
            except IOError:
                # If reading fails, continue to create new keys
                pass
            except Exception:
                # Catch any other exceptions and continue
                pass
        
        # Generate new DH parameters and key pair
        parameters = generate_dh_parameters()
        private_key = generate_dh_key_pair(parameters)
        
        # Calculate public key from private key
        public_key_int = pow(parameters["generator"], private_key["private_key"], parameters["prime"])
        public_key = {"public_key": public_key_int, "parameters": parameters}
        
        # Save private key to disk
        try:
            os.makedirs(os.path.dirname(private_key_path), exist_ok=True)
            
            # In a real implementation, properly serialize the private key
            # For simplicity, we'll just store a placeholder
            with open(private_key_path, 'wb') as f:
                # Note: This is a placeholder. Real implementation would serialize the key
                f.write(b'DH_PRIVATE_KEY_PLACEHOLDER')
            
            # Store in cache
            self._dh_keys['dh_private'] = private_key
            return private_key, public_key
        except IOError as e:
            # Return the generated keys even if saving fails
            return private_key, public_key
    
    def rotate_keys(self, peer_id: Optional[str] = None) -> None:
        """
        Rotate encryption keys for a specific peer or all peers.
        
        Args:
            peer_id: Specific peer to rotate keys for, or None for all peers
        """
        if peer_id:
            # Rotate keys for a specific peer
            try:
                # Generate new symmetric key
                new_sym_key = os.urandom(AES_KEY_SIZE)
                sym_key_path = self._get_key_path('symmetric', peer_id)
                with open(sym_key_path, 'wb') as f:
                    f.write(new_sym_key)
                self._symmetric_keys[peer_id] = new_sym_key
                
                # Generate new MAC key
                new_mac_key = generate_mac_key()
                mac_key_path = self._get_key_path('mac', peer_id)
                with open(mac_key_path, 'wb') as f:
                    f.write(new_mac_key)
                self._mac_keys[peer_id] = new_mac_key
            except IOError as e:
                raise KeyError(f"Failed to rotate keys for peer {peer_id}: {str(e)}")
        else:
            # Rotate keys for all peers we have keys for
            all_peer_ids = set(list(self._symmetric_keys.keys()) + list(self._mac_keys.keys()))
            for peer in all_peer_ids:
                self.rotate_keys(peer)
            
            # Also rotate our DH key pair
            parameters = generate_dh_parameters()
            private_key = generate_dh_key_pair(parameters)
            private_key_path = self._get_key_path('dh_private')
            
            try:
                with open(private_key_path, 'wb') as f:
                    # Note: This is a placeholder. Real implementation would serialize the key
                    f.write(b'DH_PRIVATE_KEY_PLACEHOLDER')
                self._dh_keys['dh_private'] = private_key
            except IOError as e:
                # Log the error but continue
                pass
    
    def store_key(self, key_type: str, key_data: bytes, peer_id: Optional[str] = None) -> None:
        """
        Helper method to store keys securely.
        
        Args:
            key_type: Type of key ('symmetric', 'mac', 'dh_private', etc.)
            key_data: Key data as bytes
            peer_id: Peer ID if the key is peer-specific, None otherwise
            
        Raises:
            IOError: If key storage fails
        """
        key_path = self._get_key_path(key_type, peer_id)
        os.makedirs(os.path.dirname(key_path), exist_ok=True)
        
        try:
            # Write key with secure permissions
            with open(key_path, 'wb') as f:
                f.write(key_data)
            os.chmod(key_path, 0o600)  # Only owner can read/write
            
            # Update in-memory cache
            if key_type == 'symmetric' and peer_id:
                self._symmetric_keys[peer_id] = key_data
            elif key_type == 'mac' and peer_id:
                self._mac_keys[peer_id] = key_data
            elif key_type == 'dh_private':
                # Note: In real implementation, you'd deserialize the key
                self._dh_keys['dh_private'] = key_data
        except IOError as e:
            raise IOError(f"Failed to store {key_type} key: {str(e)}")

    def export_public_key(self) -> Dict[str, str]:
        """
        Export the public part of cryptographic keys for sharing with peers.
        
        Returns:
            Dictionary containing public key data in serialized form
        """
        # Get DH key pair and RSA key pair (if implemented)
        _, dh_public_key = self.get_dh_key_pair()
        
        # In a real implementation, you'd serialize the DH public key properly
        # For now, we'll use a placeholder
        dh_public_bytes = b"DH_PUBLIC_KEY_PLACEHOLDER"
        
        # You could also include other public keys here, such as RSA
        # private_key, public_key = generate_rsa_key_pair()
        # rsa_public_pem = serialize_public_key(public_key)
        
        return {
            "node_id": self.node_id,
            "dh_public_key": base64.b64encode(dh_public_bytes).decode('utf-8'),
            # "rsa_public_key": rsa_public_pem,
            "timestamp": datetime.utcnow().isoformat()
        }

    def import_peer_public_key(self, peer_id: str, public_key_data: Dict[str, str]) -> bool:
        """
        Import and store public keys from peers.
        
        Args:
            peer_id: Identifier of the peer
            public_key_data: Dictionary containing the peer's public keys
            
        Returns:
            True if import was successful, False otherwise
        """
        try:
            # Validate the public key data
            if "dh_public_key" not in public_key_data:
                return False
            
            # Extract and store the DH public key
            dh_public_bytes = base64.b64decode(public_key_data["dh_public_key"])
            
            # In a real implementation, you'd deserialize and validate the key
            # For now, we'll just store the raw bytes
            self.store_key("dh_public", dh_public_bytes, peer_id)
            
            # Store RSA public key if available
            if "rsa_public_key" in public_key_data:
                rsa_public_pem = public_key_data["rsa_public_key"].encode('utf-8')
                self.store_key("rsa_public", rsa_public_pem, peer_id)
            
            return True
        except (ValueError, IOError, KeyError) as e:
            # Log the error but don't raise
            return False


class SymmetricCrypto:
    """
    Class for symmetric encryption and decryption operations.
    Provides an object-oriented interface for AES-256-CBC encryption.
    """
    
    def __init__(self, key: Optional[bytes] = None):
        """
        Initialize a symmetric crypto instance.
        
        Args:
            key: Optional 32-byte key for encryption/decryption.
                 If not provided, a random key will be generated.
        """
        self.key = key if key is not None else os.urandom(AES_KEY_SIZE)
    
    def encrypt(self, data: Union[bytes, str, Dict[str, Any]], 
                additional_data: Optional[Dict[str, Any]] = None) -> str:
        """
        Encrypt data using AES-256-CBC with HMAC-SHA256 authentication.
        
        Args:
            data: Data to encrypt (bytes, string, or dictionary)
            additional_data: Optional metadata to include with encrypted data
            
        Returns:
            Base64-encoded encrypted data with IV and MAC as JSON string
        """
        return encrypt_data(data, self.key, additional_data)
    
    def decrypt(self, encrypted_data: str) -> Union[bytes, Dict[str, Any]]:
        """
        Decrypt data encrypted with the encrypt method.
        
        Args:
            encrypted_data: Base64-encoded encrypted data with IV and MAC as JSON string
            
        Returns:
            Decrypted data as bytes or dictionary (if JSON)
            
        Raises:
            ValueError: If MAC verification fails or decryption fails
            json.JSONDecodeError: If encrypted_data is not valid JSON
        """
        return decrypt_data(encrypted_data, self.key)
    
    def encrypt_with_mac(self, data: Union[str, bytes]) -> Dict[str, str]:
        """
        Encrypt data and compute MAC in a single operation.
        
        Args:
            data: Data to encrypt
            
        Returns:
            Dictionary with encrypted data and authentication tag
        """
        return encrypt_with_mac(data, self.key)
    
    @classmethod
    def generate_key(cls, password: str = None, salt: bytes = None) -> Tuple[bytes, bytes]:
        """
        Generate a secure AES-256 key using PBKDF2.
        
        Args:
            password: Optional password for key derivation. If None, a random key is generated.
            salt: Optional salt for key derivation. If None, a random salt is generated.
            
        Returns:
            Tuple containing (key, salt)
        """
        return generate_key(password, salt)
    
    def rotate_key(self) -> None:
        """
        Generate a new random encryption key.
        """
        self.key = os.urandom(AES_KEY_SIZE)


class MessageAuthenticator:
    """
    Class for message authentication operations.
    Provides an object-oriented interface for HMAC-SHA256 authentication.
    """
    
    def __init__(self, key: Optional[bytes] = None):
        """
        Initialize a message authenticator instance.
        
        Args:
            key: Optional key for HMAC computation.
                 If not provided, a random key will be generated.
        """
        self.key = key if key is not None else generate_mac_key()
    
    def compute_mac(self, data: bytes) -> bytes:
        """
        Compute HMAC-SHA256 for authentication.
        
        Args:
            data: Data to authenticate
            
        Returns:
            MAC tag as bytes
        """
        return compute_mac(self.key, data)
    
    def verify_mac(self, data: bytes, tag: bytes) -> bool:
        """
        Verify HMAC-SHA256 tag.
        
        Args:
            data: Data to authenticate
            tag: MAC tag to verify
            
        Returns:
            True if MAC is valid, False otherwise
        """
        return verify_mac(self.key, data, tag)
    
    def protect_message(self, message: bytes) -> Tuple[bytes, bytes]:
        """
        Compute MAC for a message and return both the message and MAC.
        
        Args:
            message: Message to protect
            
        Returns:
            Tuple containing (message, mac_tag)
        """
        mac_tag = self.compute_mac(message)
        return message, mac_tag
    
    def verify_message(self, message: bytes, mac_tag: bytes) -> bool:
        """
        Verify the integrity of a message using its MAC tag.
        
        Args:
            message: Message to verify
            mac_tag: MAC tag to check against
            
        Returns:
            True if the message is authentic, False otherwise
        """
        return self.verify_mac(message, mac_tag)
    
    def rotate_key(self) -> None:
        """
        Generate a new random MAC key.
        """
        self.key = generate_mac_key()


class DiffieHellmanExchange:
    """
    Class for performing Diffie-Hellman key exchange.
    Provides an object-oriented interface for generating shared secrets.
    """
    
    def __init__(self, parameters: Optional[Dict[str, Any]] = None, 
                 private_key: Optional[Dict[str, Any]] = None):
        """
        Initialize a Diffie-Hellman exchange instance.
        
        Args:
            parameters: Optional DH parameters dictionary. If not provided, new ones will be generated.
            private_key: Optional private key dictionary. If not provided, a new one will be generated.
        """
        if parameters is None:
            self.parameters = generate_dh_parameters()
        else:
            self.parameters = parameters
            
        if private_key is None:
            self.private_key = generate_dh_key_pair(self.parameters)
        else:
            self.private_key = private_key
            
        # Calculate public key from private key
        public_key_int = pow(self.parameters["generator"], self.private_key["private_key"], self.parameters["prime"])
        self.public_key = {"public_key": public_key_int, "parameters": self.parameters}
    def get_public_bytes(self) -> bytes:
        """
        Get serialized public key for sharing with peers.
        
        Returns:
            Serialized public key as bytes
        """
        # In a real implementation, we'd properly serialize the public key
        # For now, serialize the public key as JSON
        public_key_data = {
            "public_key": self.public_key["public_key"],
            "parameters": {
                "prime": self.parameters["prime"],
                "generator": self.parameters["generator"],
                "key_size": self.parameters["key_size"]
            }
        }
        return json.dumps(public_key_data).encode('utf-8')
    
    @classmethod
    def from_public_bytes(cls, parameters: Dict[str, Any], public_bytes: bytes) -> Dict[str, Any]:
        """
        Create a public key from serialized bytes.
        
        Args:
            parameters: DH parameters dictionary to use
            public_bytes: Serialized public key bytes
            
        Returns:
            Dictionary containing the public key information
        """
        # In a real implementation, we'd properly deserialize the public key
        # This is a simplified version - we'll parse the JSON data
        try:
            public_key_data = json.loads(public_bytes.decode('utf-8'))
            return {
                "public_key": public_key_data.get("public_key"),
                "parameters": public_key_data.get("parameters", parameters)
            }
        except (json.JSONDecodeError, UnicodeDecodeError, KeyError):
            # Fallback for compatibility - create a dummy public key
            return {
                "public_key": int.from_bytes(hashlib.sha256(public_bytes).digest(), 'big'),
                "parameters": parameters
            }
    
    def compute_shared_key(self, peer_public_key: Dict[str, Any]) -> bytes:
        """
        Compute shared key using Diffie-Hellman key exchange.
        
        Args:
            peer_public_key: Peer's public key dictionary
            
        Returns:
            Shared key as bytes
        """
        # Extract the public key value
        if isinstance(peer_public_key, dict) and "public_key" in peer_public_key:
            peer_public_key_value = peer_public_key["public_key"]
        else:
            # Fallback for compatibility
            peer_public_key_value = peer_public_key
            
        # Calculate shared secret: (peer_public_key)^(private_key) mod p
        prime = self.parameters["prime"]
        private_key_value = self.private_key["private_key"]
        shared_secret = pow(peer_public_key_value, private_key_value, prime)
        
        # Convert to bytes and derive a suitable encryption key using SHA-256
        shared_secret_bytes = shared_secret.to_bytes((shared_secret.bit_length() + 7) // 8, 'big')
        derived_key = hashlib.sha256(shared_secret_bytes).digest()
        return derived_key
    
    def get_shared_key_with_peer(self, peer_public_bytes: bytes) -> bytes:
        """
        Convenient method to compute shared key from peer's serialized public key.
        
        Args:
            peer_public_bytes: Peer's serialized public key
            
        Returns:
            Shared key as bytes
        """
        peer_public_key = self.from_public_bytes(self.parameters, peer_public_bytes)
        return self.compute_shared_key(peer_public_key)
    
    def rotate_key_pair(self) -> None:
        """
        Generate a new DH key pair using the same parameters.
        """
        self.private_key = generate_dh_key_pair(self.parameters)
        # Calculate new public key from private key
        public_key_int = pow(self.parameters["generator"], self.private_key["private_key"], self.parameters["prime"])
        self.public_key = {"public_key": public_key_int, "parameters": self.parameters}


def generate_keys() -> Dict[str, str]:
    """
    Generate cryptographic keys for secure communication.
    
    Returns:
        A dictionary containing the generated keys:
        - private_key: The node's private key (hex-encoded)
        - encryption_key: 32-byte symmetric encryption key (hex-encoded)
    """
    # Generate a random encryption key for symmetric encryption
    encryption_key = os.urandom(AES_KEY_SIZE)
    
    # Generate a private key for asymmetric operations
    # We'll use the DiffieHellmanExchange to generate a private key
    dh = DiffieHellmanExchange()
    private_key = dh.private_key
    
    # Return the keys as hex-encoded strings
    return {
        "private_key": bytes(private_key).hex(),
        "encryption_key": encryption_key.hex()
    }

def encrypt_traffic(data: Union[bytes, str, Dict[str, Any]], key: str) -> str:
    """
    Encrypt traffic data using the provided encryption key.
    
    Args:
        data: Data to encrypt (bytes, string, or dictionary)
        key: Hex-encoded 32-byte encryption key
        
    Returns:
        Base64-encoded encrypted data with IV and MAC as JSON string
    """
    # Convert hex key to bytes
    key_bytes = bytes.fromhex(key) if isinstance(key, str) else key
    
    # Use the encrypt_data function to encrypt the traffic
    return encrypt_data(data, key_bytes)

def decrypt_traffic(encrypted_data: str, key: str) -> Union[bytes, Dict[str, Any]]:
    """
    Decrypt encrypted traffic data using the provided encryption key.
    
    Args:
        encrypted_data: Base64-encoded encrypted data with IV and MAC as JSON string
        key: Hex-encoded 32-byte encryption key
        
    Returns:
        The decrypted data
    """
    # Convert hex key to bytes
    key_bytes = bytes.fromhex(key) if isinstance(key, str) else key
    
    # Use the decrypt_data function to decrypt the traffic
    return decrypt_data(encrypted_data, key_bytes)
