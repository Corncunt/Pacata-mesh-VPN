"""
Cryptography module for the Pacata Mesh VPN - Key Management.

This module provides key management functionality for the Pacata Mesh VPN:
- Secure key storage and retrieval
- Key rotation mechanisms
- Support for symmetric, asymmetric, and Diffie-Hellman keys
"""

import os
import json
import base64
import logging
import datetime
from pathlib import Path
from typing import Dict, Tuple, Optional, Union, List, Any

# Third-party cryptography libraries
# All cryptographic implementations now come from our own encryption module

# Internal imports
from pacata_mesh_vpn.cryptography.encryption import (
    SymmetricCrypto,
    MessageAuthenticator,
    DiffieHellmanExchange,
    encrypt_data,
    decrypt_data,
    generate_rsa_key_pair,
    serialize_private_key,
    serialize_public_key
)

# Set up logger
logger = logging.getLogger(__name__)


class CryptoManager:
    """Manages secure storage and rotation of cryptographic keys."""
    
    def __init__(self, storage_path: str = ".keys"):
        """
        Initialize key manager with a storage path.
        
        Args:
            storage_path: Directory to store keys
        """
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(exist_ok=True, parents=True)
        
        # Create master key for encrypting stored keys if it doesn't exist
        self.master_key_path = self.storage_path / "master.key"
        if not self.master_key_path.exists():
            self._generate_master_key()
        
        # Load master key
        with open(self.master_key_path, 'rb') as f:
            self.master_key = f.read()
        
        # Use our SymmetricCrypto instead of Fernet
        self.symmetric_crypto = SymmetricCrypto(self.master_key[:32])
    
    def _generate_master_key(self):
        """Generate a new master key for encrypting other keys."""
        master_key = os.urandom(32)
        with open(self.master_key_path, 'wb') as f:
            f.write(master_key)
    
    def store_key(self, key_id: str, key_data: Dict[str, Any]) -> None:
        """
        Securely store a key with metadata.
        
        Args:
            key_id: Unique identifier for the key
            key_data: Dictionary containing key material and metadata
        """
        # Add creation timestamp if not present
        if 'created_at' not in key_data:
            key_data['created_at'] = datetime.datetime.now().isoformat()
        
        # Serialize and encrypt the key data
        serialized = json.dumps(key_data).encode('utf-8')
        encrypted = self.symmetric_crypto.encrypt(serialized).encode('utf-8')
        
        # Save to file
        key_path = self.storage_path / f"{key_id}.key"
        with open(key_path, 'wb') as f:
            f.write(encrypted)
    
    def retrieve_key(self, key_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve and decrypt a stored key.
        
        Args:
            key_id: Unique identifier for the key
            
        Returns:
            Dictionary with key data or None if not found
        """
        key_path = self.storage_path / f"{key_id}.key"
        
        if not key_path.exists():
            return None
        
        try:
            with open(key_path, 'rb') as f:
                encrypted = f.read()
            
            decrypted = self.symmetric_crypto.decrypt(encrypted.decode('utf-8'))
            if isinstance(decrypted, bytes):
                return json.loads(decrypted.decode('utf-8'))
            return decrypted
        except Exception as e:
            logger.error(f"Failed to retrieve key {key_id}: {e}")
            return None
    
    def rotate_key(self, key_id: str, rotation_period_days: int = 30) -> Optional[Dict[str, Any]]:
        """
        Check if a key needs rotation and generate a new one if necessary.
        
        Args:
            key_id: Unique identifier for the key
            rotation_period_days: Days after which key should be rotated
            
        Returns:
            New key data if rotated, None if rotation not needed
        """
        key_data = self.retrieve_key(key_id)
        
        if not key_data:
            return None
        
        created_at = datetime.datetime.fromisoformat(key_data['created_at'])
        now = datetime.datetime.now()
        
        if (now - created_at).days >= rotation_period_days:
            # Generate new key with same characteristics
            new_key_data = key_data.copy()
            
            # If it's a symmetric key, generate new random bytes
            if 'symmetric_key' in new_key_data:
                new_key_data['symmetric_key'] = base64.b64encode(os.urandom(32)).decode('utf-8')
            
            # If it's a DH key, generate new DH exchange
            elif 'dh_private_key' in new_key_data:
                dh_exchange = DiffieHellmanExchange()
                # Serialize the private key as JSON
                private_key_json = json.dumps(dh_exchange.private_key).encode('utf-8')
                new_key_data['dh_private_key'] = base64.b64encode(private_key_json).decode('utf-8')
                new_key_data['dh_public_key'] = base64.b64encode(dh_exchange.get_public_bytes()).decode('utf-8')
            
            # If it's an RSA key, generate new pair
            # If it's an RSA key, generate new pair
            elif 'rsa_private_key' in new_key_data:
                key_size = new_key_data.get('key_size', 2048)
                private_key, public_key = generate_rsa_key_pair()
                new_key_data['rsa_private_key'] = base64.b64encode(private_key).decode('utf-8')
                new_key_data['rsa_public_key'] = base64.b64encode(public_key).decode('utf-8')
            # Update creation and rotation timestamps
            new_key_data['created_at'] = now.isoformat()
            new_key_data['last_rotated'] = now.isoformat()
            new_key_data['previous_key_id'] = key_id
            
            # Generate new key ID with version increment
            version = key_data.get('version', 1)
            new_key_id = f"{key_id.split('_v')[0]}_v{version + 1}"
            
            # Store the new key
            self.store_key(new_key_id, new_key_data)
            
            # Update the old key to reference the new one
            key_data['rotated_to'] = new_key_id
            key_data['active'] = False
            self.store_key(key_id, key_data)
            
            logger.info(f"Key {key_id} rotated to {new_key_id}")
            return new_key_data
        
        return None
    
    def list_keys(self) -> List[str]:
        """
        List all keys stored in the key manager.
        
        Returns:
            List of key IDs
        """
        keys = []
        for key_file in self.storage_path.glob("*.key"):
            if key_file.name != "master.key":
                keys.append(key_file.stem)
        return keys
    
    def get_active_key(self, key_prefix: str) -> Optional[Tuple[str, Dict[str, Any]]]:
        """
        Get the most recent active key with a given prefix.
        
        Args:
            key_prefix: Prefix of the key to search for
            
        Returns:
            Tuple of (key_id, key_data) for the active key, or None if not found
        """
        matching_keys = [k for k in self.list_keys() if k.startswith(key_prefix)]
        if not matching_keys:
            return None
        
        # Sort by version number (assuming format prefix_vX)
        matching_keys.sort(key=lambda x: int(x.split('_v')[-1]) if '_v' in x else 0, reverse=True)
        
        # Get the most recent key that is active
        for key_id in matching_keys:
            key_data = self.retrieve_key(key_id)
            if key_data and key_data.get('active', True):
                return (key_id, key_data)
        
        return None
    
    def create_symmetric_key(self, key_prefix: str, key_length: int = 32) -> Tuple[str, Dict[str, Any]]:
        """
        Create a new symmetric key.
        
        Args:
            key_prefix: Prefix for the key ID
            key_length: Length of the key in bytes
            
        Returns:
            Tuple of (key_id, key_data)
        """
        key_id = f"{key_prefix}_v1"
        key_data = {
            'type': 'symmetric',
            'symmetric_key': base64.b64encode(os.urandom(key_length)).decode('utf-8'),
            'key_length': key_length,
            'created_at': datetime.datetime.now().isoformat(),
            'active': True,
            'version': 1
        }
        self.store_key(key_id, key_data)
        logger.info(f"Created new symmetric key: {key_id}")
        return (key_id, key_data)
    
    def create_dh_key_pair(self, key_prefix: str) -> Tuple[str, Dict[str, Any]]:
        """
        Create a new Diffie-Hellman key pair.
        
        Args:
            key_prefix: Prefix for the key ID
            
        Returns:
            Tuple of (key_id, key_data)
        """
        dh_exchange = DiffieHellmanExchange()
        # Serialize the private key as JSON
        private_key_json = json.dumps(dh_exchange.private_key).encode('utf-8')
        
        key_id = f"{key_prefix}_v1"
        key_data = {
            'type': 'dh',
            'dh_private_key': base64.b64encode(private_key_json).decode('utf-8'),
            'dh_public_key': base64.b64encode(dh_exchange.get_public_bytes()).decode('utf-8'),
            'created_at': datetime.datetime.now().isoformat(),
            'active': True,
            'version': 1
        }
        self.store_key(key_id, key_data)
        logger.info(f"Created new DH key pair: {key_id}")
        return (key_id, key_data)
    
    def create_rsa_key_pair(self, key_prefix: str, key_size: int = 2048) -> Tuple[str, Dict[str, Any]]:
        """
        Create a new RSA key pair.
        
        Args:
            key_prefix: Prefix for the key ID
            key_size: Size of the RSA key in bits
            
        Returns:
            Tuple of (key_id, key_data)
        """
        # Use our simplified RSA key pair generation
        private_key, public_key = generate_rsa_key_pair()
        
        key_id = f"{key_prefix}_v1"
        key_data = {
            'type': 'rsa',
            'rsa_private_key': base64.b64encode(private_key).decode('utf-8'),
            'rsa_public_key': base64.b64encode(public_key).decode('utf-8'),
            'key_size': key_size,
            'created_at': datetime.datetime.now().isoformat(),
            'active': True,
            'version': 1
        }
        self.store_key(key_id, key_data)
        logger.info(f"Created new RSA key pair: {key_id}")
        return (key_id, key_data)
    
    def get_symmetric_crypto(self, key_id: str) -> Optional[SymmetricCrypto]:
        """
        Get a SymmetricCrypto instance for a stored symmetric key.
        
        Args:
            key_id: ID of the key to use
            
        Returns:
            SymmetricCrypto instance or None if the key is not found or invalid
        """
        key_data = self.retrieve_key(key_id)
        if not key_data or 'symmetric_key' not in key_data:
            return None
        
        try:
            key_bytes = base64.b64decode(key_data['symmetric_key'])
            return SymmetricCrypto(key_bytes)
        except Exception as e:
            logger.error(f"Failed to create SymmetricCrypto for key {key_id}: {e}")
            return None
    
    def get_message_authenticator(self, key_id: str) -> Optional[MessageAuthenticator]:
        """
        Get a MessageAuthenticator instance for a stored key.
        
        Args:
            key_id: ID of the key to use
            
        Returns:
            MessageAuthenticator instance or None if the key is not found or invalid
        """

