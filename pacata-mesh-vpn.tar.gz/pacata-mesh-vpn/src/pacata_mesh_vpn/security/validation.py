import json
import re
import hashlib
from typing import Any, Dict, List, Optional, Union, Tuple, Set
import logging

logger = logging.getLogger(__name__)

def validate_data_structure(data: Any, expected_schema: Dict, path: str = "") -> Tuple[bool, List[str]]:
    """
    Validates that a data structure matches the expected schema.
    
    Args:
        data: The data to validate
        expected_schema: A schema definition dictionary
        path: Current path in the data structure (for error reporting)
        
    Returns:
        Tuple of (is_valid, error_messages)
    """
    errors = []
    
    # Check type
    if "type" in expected_schema:
        expected_type = expected_schema["type"]
        
        # Handle different type validations
        if expected_type == "object" and not isinstance(data, dict):
            errors.append(f"{path}: Expected object, got {type(data).__name__}")
        elif expected_type == "array" and not isinstance(data, list):
            errors.append(f"{path}: Expected array, got {type(data).__name__}")
        elif expected_type == "string" and not isinstance(data, str):
            errors.append(f"{path}: Expected string, got {type(data).__name__}")
        elif expected_type == "number" and not isinstance(data, (int, float)):
            errors.append(f"{path}: Expected number, got {type(data).__name__}")
        elif expected_type == "integer" and not isinstance(data, int):
            errors.append(f"{path}: Expected integer, got {type(data).__name__}")
        elif expected_type == "boolean" and not isinstance(data, bool):
            errors.append(f"{path}: Expected boolean, got {type(data).__name__}")
        elif expected_type == "null" and data is not None:
            errors.append(f"{path}: Expected null, got {type(data).__name__}")
    
    # If we're validating an object, check required properties and property formats
    if isinstance(data, dict) and expected_schema.get("type") == "object":
        # Check for required properties
        if "required" in expected_schema:
            for prop in expected_schema["required"]:
                if prop not in data:
                    errors.append(f"{path}: Missing required property '{prop}'")
        
        # Validate each property
        if "properties" in expected_schema:
            for prop, prop_schema in expected_schema["properties"].items():
                if prop in data:
                    prop_path = f"{path}.{prop}" if path else prop
                    valid, prop_errors = validate_data_structure(data[prop], prop_schema, prop_path)
                    errors.extend(prop_errors)
    
    # If we're validating an array, check its items
    if isinstance(data, list) and expected_schema.get("type") == "array":
        if "items" in expected_schema:
            for i, item in enumerate(data):
                item_path = f"{path}[{i}]"
                valid, item_errors = validate_data_structure(item, expected_schema["items"], item_path)
                errors.extend(item_errors)
    
    # Check string format
    if isinstance(data, str) and "format" in expected_schema:
        fmt = expected_schema["format"]
        if fmt == "date-time":
            # Basic ISO format check
            if not re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}", data):
                errors.append(f"{path}: Invalid date-time format")
        elif fmt == "email":
            if not re.match(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", data):
                errors.append(f"{path}: Invalid email format")
        elif fmt == "ipv4":
            if not re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", data):
                errors.append(f"{path}: Invalid IPv4 format")
        elif fmt == "hash":
            if not re.match(r"^[a-fA-F0-9]{64}$", data):
                errors.append(f"{path}: Invalid hash format (expected 64 hex characters)")
    
    # Check value constraints
    if isinstance(data, (int, float)) and expected_schema.get("type") in ("number", "integer"):
        if "minimum" in expected_schema and data < expected_schema["minimum"]:
            errors.append(f"{path}: Value {data} is less than minimum {expected_schema['minimum']}")
        if "maximum" in expected_schema and data > expected_schema["maximum"]:
            errors.append(f"{path}: Value {data} is greater than maximum {expected_schema['maximum']}")
    
    # Check string length
    if isinstance(data, str) and expected_schema.get("type") == "string":
        if "minLength" in expected_schema and len(data) < expected_schema["minLength"]:
            errors.append(f"{path}: String length {len(data)} is less than minimum {expected_schema['minLength']}")
        if "maxLength" in expected_schema and len(data) > expected_schema["maxLength"]:
            errors.append(f"{path}: String length {len(data)} is greater than maximum {expected_schema['maxLength']}")
    
    return (len(errors) == 0, errors)

def validate_hash(hash_str: str) -> bool:
    """
    Validates if a string is a valid SHA-256 hash.
    
    Args:
        hash_str: The hash string to validate
        
    Returns:
        True if valid, False otherwise
    """
    return bool(re.match(r"^[a-fA-F0-9]{64}$", hash_str))

def validate_signature(signature: str, public_key: str, message: str) -> bool:
    """
    Placeholder for signature validation.
    In a real implementation, this would validate a cryptographic signature.
    
    Args:
        signature: The signature to validate
        public_key: The public key to validate against
        message: The original message that was signed
        
    Returns:
        True if valid, False otherwise
    """
    # This would be replaced with actual cryptographic verification
    # e.g. using a library like pynacl, cryptography, or web3.py
    logger.warning("Using placeholder signature validation - replace with cryptographic verification!")
    return len(signature) > 0 and len(public_key) > 0

def sanitize_input(input_str: str) -> str:
    """
    Sanitizes user input to prevent injection attacks.
    
    Args:
        input_str: The input string to sanitize
        
    Returns:
        Sanitized string
    """
    # Remove any potentially harmful characters or sequences
    sanitized = re.sub(r"[;<>/\\'\"]", "", input_str)
    return sanitized

def validate_transaction_data(tx_data: Dict) -> Tuple[bool, List[str]]:
    """
    Validates that transaction data meets the required structure.
    
    Args:
        tx_data: The transaction data to validate
        
    Returns:
        Tuple of (is_valid, error_messages)
    """
    schema = {
        "type": "object",
        "required": ["sender", "recipient", "amount", "timestamp", "signature"],
        "properties": {
            "sender": {"type": "string", "minLength": 32, "maxLength": 256},
            "recipient": {"type": "string", "minLength": 32, "maxLength": 256},
            "amount": {"type": "number", "minimum": 0},
            "timestamp": {"type": "string", "format": "date-time"},
            "signature": {"type": "string", "minLength": 64},
            "data": {"type": "object"},  # Optional transaction data
        }
    }
    
    return validate_data_structure(tx_data, schema)

def validate_contract_call(call_data: Dict) -> Tuple[bool, List[str]]:
    """
    Validates that smart contract call data meets the required structure.
    
    Args:
        call_data: The contract call data to validate
        
    Returns:
        Tuple of (is_valid, error_messages)
    """
    schema = {
        "type": "object",
        "required": ["contract_id", "method", "caller", "timestamp", "signature"],
        "properties": {
            "contract_id": {"type": "string", "minLength": 32, "maxLength": 256},
            "method": {"type": "string", "minLength": 1, "maxLength": 64},
            "params": {"type": "object"},
            "caller": {"type": "string", "minLength": 32, "maxLength": 256},
            "timestamp": {"type": "string", "format": "date-time"},
            "gas_limit": {"type": "integer", "minimum": 1},
            "signature": {"type": "string", "minLength": 64}
        }
    }
    
    return validate_data_structure(call_data, schema)

def check_json_safety(json_str: str) -> Tuple[bool, Optional[Dict]]:
    """
    Safely parses and validates JSON input.
    
    Args:
        json_str: The JSON string to parse
        
    Returns:
        Tuple of (is_valid, parsed_data or None if invalid)
    """
    try:
        # Try to parse the JSON
        data = json.loads(json_str)
        return True, data
    except json.JSONDecodeError:
        return False, None

