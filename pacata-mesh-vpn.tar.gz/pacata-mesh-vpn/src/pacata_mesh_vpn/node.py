#!/usr/bin/env python3
"""
Pacata Mesh VPN Node Implementation

This module provides the core functionality for running a node in the Pacata mesh VPN network.
It handles peer discovery, secure tunneling, routing, and cryptocurrency integration.
"""

import asyncio
import logging
import os
import json
import time
import socket
import uuid
import ipaddress
from typing import Dict, List, Set, Optional, Tuple, Any
from dataclasses import dataclass, field
from pathlib import Path
import threading
import random

# Third-party imports
import nacl.public
import nacl.signing
import nacl.utils
import nacl.secret
import aiohttp
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

# Internal imports
from pacata_mesh_vpn.blockchain.wallet import PacataWallet
from pacata_mesh_vpn.networking import tunnel, dht, relay

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Constants
DEFAULT_PORT = 8765
DHT_PORT = 8766
BOOTSTRAP_NODES = [
    "bootstrap1.pacata.io:8765",
    "bootstrap2.pacata.io:8765",
    "bootstrap3.pacata.io:8765"
]
PEER_PING_INTERVAL = 60  # seconds
ROUTE_UPDATE_INTERVAL = 300  # seconds
BANDWIDTH_REWARD_INTERVAL = 3600  # seconds (1 hour)
DEVELOPER_FEE_PERCENTAGE = 0.01  # 1%
DEVELOPER_WALLET_ADDRESS = "pacata1qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq0uxfl2"


@dataclass
class Peer:
    """Represents a peer node in the Pacata Mesh VPN network."""
    id: str
    address: str
    port: int
    public_key: bytes
    routes: List[str] = field(default_factory=list)
    last_seen: float = field(default_factory=time.time)
    bandwidth_provided: int = 0  # in bytes
    latency: float = 0.0  # in milliseconds
    connection: Any = None  # Will hold the connection object


@dataclass
class Route:
    """Represents a route to a destination in the network."""
    destination: str  # IP or subnet
    next_hop: str  # Peer ID
    metric: int  # Routing metric (e.g., hop count)
    timestamp: float = field(default_factory=time.time)


class PacataNode:
    """
    Core implementation of a node in the Pacata mesh VPN network.
    
    This class handles:
    - Peer discovery and connection management
    - Secure tunnel establishment
    - Traffic routing through the mesh network
    - Integration with Pacata cryptocurrency for bandwidth incentives
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize a new Pacata VPN node.
        
        Args:
            config_path: Path to the configuration file. If None, default config is used.
        """
        self.node_id = str(uuid.uuid4())
        self.running = False
        self.peers: Dict[str, Peer] = {}
        self.routes: Dict[str, Route] = {}
        self.tunnel_manager = None
        self.dht = None
        self.relay = None
        
        # Load configuration
        self.config = self._load_config(config_path)
        
        # Initialize crypto keys
        self._init_keys()
        
        # Initialize wallet
        self.wallet = PacataWallet(self.config.get('wallet_path'))
        
        # Initialize networking components
        self._init_networking()
        
        # Stats tracking
        self.bytes_relayed = 0
        self.active_connections = 0
        self.start_time = 0
        
        logger.info(f"Pacata node initialized with ID: {self.node_id}")
    
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """
        Load configuration from file or use defaults.
        
        Args:
            config_path: Path to the configuration file
            
        Returns:
            Dict containing the configuration
        """
        default_config = {
            'node_name': f'pacata-node-{self.node_id[:8]}',
            'listen_port': DEFAULT_PORT,
            'dht_port': DHT_PORT,
            'max_peers': 50,
            'bootstrap_nodes': BOOTSTRAP_NODES,
            'data_dir': os.path.expanduser('~/.pacata'),
            'bandwidth_limit': 1024 * 1024 * 100,  # 100 MB/s
            'enable_relay': True,
            'enable_exit': False,  # Whether this node acts as an exit node
            'wallet_path': None,  # Will be set to data_dir/wallet.json below
            'log_level': 'INFO'
        }
        
        config = default_config.copy()
        
        if config_path:
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                    config.update(user_config)
                logger.info(f"Loaded configuration from {config_path}")
            except Exception as e:
                logger.error(f"Failed to load config from {config_path}: {e}")
                logger.info("Using default configuration")
        
        # Ensure data directory exists
        os.makedirs(config['data_dir'], exist_ok=True)
        
        # Set default wallet path if not provided
        if not config['wallet_path']:
            config['wallet_path'] = os.path.join(config['data_dir'], 'wallet.json')
        
        # Set log level
        logging.getLogger().setLevel(config['log_level'])
        
        return config
    
    def _init_keys(self):
        """Initialize or load cryptographic keys for the node."""
        keys_path = os.path.join(self.config['data_dir'], 'node_keys.json')
        
        if os.path.exists(keys_path):
            try:
                with open(keys_path, 'r') as f:
                    keys_data = json.load(f)
                
                self.signing_key = nacl.signing.SigningKey(
                    bytes.fromhex(keys_data['signing_key'])
                )
                self.verify_key = self.signing_key.verify_key
                
                self.private_key = nacl.public.PrivateKey(
                    bytes.fromhex(keys_data['encryption_key'])
                )
                self.public_key = self.private_key.public_key
                
                logger.info("Loaded existing cryptographic keys")
            except Exception as e:
                logger.error(f"Failed to load keys, generating new ones: {e}")
                self._generate_new_keys(keys_path)
        else:
            self._generate_new_keys(keys_path)
    
    def _generate_new_keys(self, keys_path: str):
        """Generate new cryptographic keys and save them."""
        # Generate signing key pair
        self.signing_key = nacl.signing.SigningKey.generate()
        self.verify_key = self.signing_key.verify_key
        
        # Generate encryption key pair
        self.private_key = nacl.public.PrivateKey.generate()
        self.public_key = self.private_key.public_key
        
        # Save keys
        keys_data = {
            'signing_key': self.signing_key.encode().hex(),
            'encryption_key': bytes(self.private_key).hex()
        }
        
        with open(keys_path, 'w') as f:
            json.dump(keys_data, f)
        
        logger.info("Generated and saved new cryptographic keys")
    
    def _init_networking(self):
        """Initialize networking components."""
        # Initialize tunnel interface
        self.tunnel_manager = tunnel.TunnelManager(
            node_id=self.node_id,
            private_key=self.private_key,
            config=self.config
        )
        
        # Initialize DHT for peer discovery
        self.dht = dht.DistributedHashTable(
            node_id=self.node_id,
            port=self.config['dht_port'],
            bootstrap_nodes=self.config['bootstrap_nodes']
        )
        
        # Initialize packet relay
        self.relay = relay.PacketRelay(
            node_id=self.node_id,
            routes=self.routes,
            bandwidth_limit=self.config['bandwidth_limit'],
            enable_relay=self.config['enable_relay'],
            enable_exit=self.config['enable_exit']
        )
    
    async def start(self):
        """Start the Pacata node and all its components."""
        if self.running:
            logger.warning("Node is already running")
            return
        
        self.running = True
        self.start_time = time.time()
        
        logger.info(f"Starting Pacata node {self.node_id}")
        
        # Start the tunnel interface
        await self.tunnel_manager.start()
        
        # Start DHT for peer discovery
        await self.dht.start()
        
        # Start packet relay
        await self.relay.start()
        
        # Start periodic tasks
        asyncio.create_task(self._periodic_peer_ping())
        asyncio.create_task(self._periodic_route_update())
        asyncio.create_task(self._periodic_bandwidth_reward())
        
        # Connect to bootstrap nodes
        await self._connect_to_bootstrap_nodes()
        
        logger.info("Pacata node started successfully")
    
    async def stop(self):
        """Stop the Pacata node and all its components."""
        if not self.running:
            logger.warning("Node is not running")
            return
        
        logger.info("Stopping Pacata node")
        self.running = False
        
        # Disconnect from all peers
        await self._disconnect_all_peers()
        
        # Stop packet relay
        await self.relay.stop()
        
        # Stop DHT
        await self.dht.stop()
        
        # Stop tunnel interface
        await self.tunnel_manager.stop()
        
        logger.info("Pacata node stopped")
    
    async def _connect_to_bootstrap_nodes(self):
        """Connect to the bootstrap nodes to join the network."""
        for bootstrap_node in self.config['bootstrap_nodes']:
            try:
                host, port_str = bootstrap_node.split(':')
                port = int(port_str)
                
                # Use the DHT to get node information
                node_info = await self.dht.lookup_node(host, port)
                
                if node_info:
                    await self.connect_to_peer(
                        node_info['id'],
                        node_info['address'],
                        node_info['port'],
                        node_info['public_key']
                    )
            except Exception as e:
                logger.error(f"Failed to connect to bootstrap node {bootstrap_node}: {e}")
    
    async def connect_to_peer(self, peer_id: str, address: str, port: int, public_key: bytes):
        """
        Establish a connection to a peer.
        
        Args:
            peer_id: Unique ID of the peer
            address: IP address or hostname of the peer
            port: Port number of the peer
            public_key: Public key of the peer for encryption
        """
        if peer_id == self.node_id:
            logger.debug("Ignoring connection to self")
            return
        
        if peer_id in self.peers:
            logger.debug(f"Already connected to peer {peer_id}")
            self.peers[peer_id].last_seen = time.time()
            return
        
        try:
            # Establish secure connection
            connection = await self._establish_secure_connection(address, port, public_key)
            
            # Create peer object
            peer = Peer(
                id=peer_id,
                address=address,
                port=port,
                public_key=public_key,
                connection=connection
            )
            
            # Add to peers dictionary
            self.peers[peer_id] = peer
            self.active_connections += 1
            
            # Exchange routing information
            await self._exchange_routes(peer)
            
            logger.info(f"Connected to peer {peer_id} at {address}:{port}")
        except Exception as e:
            logger.error(f"Failed to connect to peer {peer_id}: {e}")
    
    async def _establish_secure_connection(self, address: str, port: int, public_key: bytes):
        """
        Establish a secure encrypted connection to a peer.
        
        Args:
            address: IP address or hostname of the peer
            port: Port number of the peer
            public_key: Public key of the peer for encryption
            
        Returns:
            Connection object
        """
        # This would implement the actual secure connection establishment
        # For now, we'll just create a placeholder connection object
        connection = {
            "address": address,
            "port": port,
            "established_at": time.time(),
            "encrypted": True,
            "shared_key": None  # In a real implementation, this would be a derived shared key
        }
        
        # In a real implementation, we would:
        # 1. Establish a TCP/UDP connection
        # 2. Perform a key exchange (e.g., ECDH)
        # 3. Derive a shared secret
        # 4. Set up an encrypted channel
        
        return connection
    
    async def disconnect_from_peer(self, peer_id: str):
        """
        Disconnect from a peer.
        
        Args:
            peer_id: ID of the peer to disconnect from
        """
        if peer_id not in self.peers:
            logger.warning(f"Not connected to peer {peer_id}")
            return
        
        peer = self.peers[peer_id]
        
        # Close the connection (in a real implementation)
        # await peer.connection.close()
        
        # Remove routes through this peer
        routes_to_remove = []
        for dest, route in self.routes.items():
            if route.next_hop == peer_id:
                routes_to_remove.append(dest)
        
        for dest in routes_to_remove:
            del self.routes[dest]
        
        # Remove peer from peers dictionary
        del self.peers[peer_id]
        self.active_connections -= 1
        
        logger.info(f"Disconnected from peer {peer_id}")
    
    async def _disconnect_all_peers(self):
        """Disconnect from all peers."""
        peer_ids = list(self.peers.keys())
        for peer_id in peer_ids:
            await self.disconnect_from_peer(peer_id)
    
    async def _exchange_routes(self, peer: Peer):
        """
        Exchange routing information with a peer.
        
        Args:
            peer: Peer object to exchange

"""
Node implementation for the Pacata Mesh VPN network.

This module provides the PacataNode class which handles the core functionality
of a node in the Pacata mesh VPN network, including peer discovery, connection
management, tunneling, and participation in the blockchain network for rewards.
"""

import asyncio
import ipaddress
import json
import logging
import os
import random
import socket
import struct
import time
from typing import Dict, List, Optional, Set, Tuple, Union

import aiohttp
import click
import cryptography.hazmat.primitives.asymmetric.rsa as rsa
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

from pacata_mesh_vpn.blockchain.wallet import PacataWallet
from pacata_mesh_vpn.cryptography.encryption import encrypt_data, decrypt_data
from pacata_mesh_vpn.networking.dht import DistributedHashTable
from pacata_mesh_vpn.networking.tunnel import TunnelInterface

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class PacataNode:
    """
    Implementation of a node in the Pacata mesh VPN network.
    
    This class handles peer discovery, connection management, data forwarding,
    and participation in the Pacata cryptocurrency network.
    """
    
    def __init__(self, 
                 node_id: Optional[str] = None,
                 private_key: Optional[rsa.RSAPrivateKey] = None,
                 bootstrap_nodes: Optional[List[str]] = None,
                 wallet_path: Optional[str] = None,
                 ip_range: str = "10.10.0.0/16",
                 port: int = 8000,
                 enable_rewards: bool = True):
        """
        Initialize a Pacata VPN node.
        
        Args:
            node_id: Unique identifier for this node. If None, one will be generated.
            private_key: RSA private key for this node. If None, one will be generated.
            bootstrap_nodes: List of known nodes to connect to initially.
            wallet_path: Path to the wallet file. If None, a new wallet will be created.
            ip_range: IP range for the virtual network.
            port: Port to listen on for incoming connections.
            enable_rewards: Whether to enable Pacata cryptocurrency rewards.
        """
        # Generate or use provided node_id
        self.node_id = node_id or self._generate_node_id()
        logger.info(f"Initializing node with ID: {self.node_id}")
        
        # Generate or use provided private key
        self.private_key = private_key or self._generate_private_key()
        self.public_key = self.private_key.public_key()
        
        # Set up networking
        self.port = port
        self.ip_range = ipaddress.IPv4Network(ip_range)
        self.virtual_ip = None  # Will be assigned during network setup
        
        # Initialize peer tracking
        self.peers = {}  # node_id -> {address, public_key, virtual_ip, etc.}
        self.connections = {}  # node_id -> connection object
        self.routing_table = {}  # destination -> next_hop
        
        # Set up DHT for peer discovery
        self.bootstrap_nodes = bootstrap_nodes or ["bootstrap1.pacata.net:8000", 
                                                  "bootstrap2.pacata.net:8000"]
        self.dht = DistributedHashTable(self.node_id, self.bootstrap_nodes)
        
        # Initialize VPN tunnel interface
        self.tunnel = TunnelInterface(self.ip_range)
        
        # Set up cryptocurrency components
        self.enable_rewards = enable_rewards
        self.wallet = PacataWallet(wallet_path) if enable_rewards else None
        self.bandwidth_usage = {}  # peer_id -> bytes_forwarded
        self.last_reward_claim = time.time()
        
        # Runtime state
        self.running = False
        self.tasks = []
    
    def _generate_node_id(self) -> str:
        """Generate a unique node ID."""
        return f"node-{random.randint(1, 1000000):06d}"
    
    def _generate_private_key(self) -> rsa.RSAPrivateKey:
        """Generate a new RSA private key."""
        logger.info("Generating new RSA key pair")
        return rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
    
    async def start(self):
        """
        Start the node operation.
        
        This initiates the networking, discovery, and periodic tasks.
        """
        if self.running:
            logger.warning("Node is already running")
            return
        
        logger.info("Starting Pacata node")
        self.running = True
        
        # Initialize the tunnel interface
        await self.tunnel.setup()
        self.virtual_ip = await self.tunnel.assign_ip()
        logger.info(f"Assigned virtual IP: {self.virtual_ip}")
        
        # Start listening for incoming connections
        server = await asyncio.start_server(
            self._handle_connection, '0.0.0.0', self.port
        )
        
        # Start periodic tasks
        self.tasks = [
            asyncio.create_task(self._discover_peers_periodically()),
            asyncio.create_task(self._update_routing_table_periodically()),
            asyncio.create_task(self._process_vpn_traffic()),
        ]
        
        if self.enable_rewards:
            self.tasks.append(asyncio.create_task(self._claim_rewards_periodically()))
        
        # Connect to bootstrap nodes
        await self._connect_to_bootstrap_nodes()
        
        # Announce ourselves to the network
        await self.dht.announce(self.node_id, {
            'address': f"{socket.gethostbyname(socket.gethostname())}:{self.port}",
            'virtual_ip': str(self.virtual_ip),
            'public_key': self.public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ).decode('utf-8')
        })
        
        logger.info(f"Node started and listening on port {self.port}")
        
        # Keep the server running
        async with server:
            await server.serve_forever()
    
    async def stop(self):
        """
        Stop the node operation cleanly.
        """
        if not self.running:
            logger.warning("Node is not running")
            return
        
        logger.info("Stopping Pacata node")
        self.running = False
        
        # Cancel all tasks
        for task in self.tasks:
            task.cancel()
        
        # Close connections
        for conn in self.connections.values():
            conn.close()
        
        # Clean up tunnel
        await self.tunnel.teardown()
        
        # Update DHT to show we're offline
        await self.dht.remove(self.node_id)
        
        logger.info("Node stopped")
    
    async def _handle_connection(self, reader, writer):
        """
        Handle an incoming connection from another node.
        
        Args:
            reader: AsyncIO stream reader
            writer: AsyncIO stream writer
        """
        peer_address = writer.get_extra_info('peername')
        logger.info(f"New connection from {peer_address}")
        
        try:
            # Read initial message with peer info
            data = await reader.read(4096)
            message = json.loads(data.decode())
            
            # Verify signature if provided
            if 'signature' in message:
                # Skip signature verification for now, implement proper verification in production
                peer_id = message['node_id']
            else:
                peer_id = f"unknown-{random.randint(1, 1000):04d}"
            
            # Store connection
            self.connections[peer_id] = (reader, writer)
            self.peers[peer_id] = {
                'address': f"{peer_address[0]}:{peer_address[1]}",
                'virtual_ip': message.get('virtual_ip'),
                'public_key': message.get('public_key'),
                'last_seen': time.time()
            }
            
            # Update routing table
            if message.get('virtual_ip'):
                self.routing_table[message['virtual_ip']] = peer_id
            
            # Send our info
            response = {
                'node_id': self.node_id,
                'virtual_ip': str(self.virtual_ip),
                'public_key': self.public_key.public_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PublicFormat.SubjectPublicKeyInfo
                ).decode('utf-8')
            }
            writer.write(json.dumps(response).encode())
            await writer.drain()
            
            # Start listening for messages
            asyncio.create_task(self._listen_for_messages(peer_id, reader, writer))
            
        except Exception as e:
            logger.error(f"Error handling connection: {e}")
            writer.close()
    
    async def _listen_for_messages(self, peer_id, reader, writer):
        """
        Listen for messages from a connected peer.
        
        Args:
            peer_id: ID of the peer
            reader: AsyncIO stream reader
            writer: AsyncIO stream writer
        """
        try:
            while self.running:
                # Read message type and length
                header = await reader.read(8)
                if not header:
                    break
                
                msg_type, msg_len = struct.unpack('!II', header)
                
                # Read message data
                data = await reader.read(msg_len)
                if not data:
                    break
                
                # Process message based on type
                if msg_type == 1:  # VPN packet
                    await self._handle_vpn_packet(peer_id, data)
                elif msg_type == 2:  # Control message
                    await self._handle_control_message(peer_id, data)
                elif msg_type == 3:  # Transaction
                    await self._handle_transaction(peer_id, data)
                else:
                    logger.warning(f"Unknown message type {msg_type} from {peer_id}")
        
        except asyncio.CancelledError:
            logger.info(f"Connection listener for {peer_id} cancelled")
        except Exception as e:
            logger.error(f"Error listening for messages from {peer_id}: {e}")
        finally:
            # Clean up connection
            writer.close()
            try:
                await writer.wait_closed()
            except:
                pass
            
            if peer_id in self.connections:
                del self.connections[peer_id]
                logger.info(f"Connection to {peer_id} closed")
    
    async def _handle_vpn_packet(self, peer_id, data):
        """
        Handle a VPN data packet from a peer.
        
        Args:
            peer_id: ID of the peer that sent the packet
            data: Encrypted packet data
        """
        try:
            # Decrypt the packet
            packet = decrypt_data(data, self.private_key)
            
            # Extract destination IP from packet
            dst_ip = self._extract_destination_ip(packet)
            
            # Track bandwidth usage for rewards
            if peer_id in self.bandwidth_usage:
                self.bandwidth_usage[peer_id] += len(data)
            else:
                self.bandwidth_usage[peer_id] = len(data)
            
            # Forward or process packet
            if dst_ip == str(self.virtual_ip):
                # Packet is for us, send to tunnel
                await self.tunnel.write_packet(packet)
            else:
                # Forward packet to next hop
                await self._forward_packet(dst_ip, packet)
        
        except Exception as e:
            logger.error(f"Error handling VPN packet: {e}")
    
    def _extract_destination_ip(self, packet):
        """
        Extract the destination IP address from a packet.
        
        Args:
            packet: Raw packet data
            
        Returns:
            Destination IP address as string
        """
        # This is a simplified implementation
        # In a real implementation, proper IP packet parsing would be needed
        version = packet[0] >> 4
        if version == 4:
            # IPv4 packet
            dst_ip = socket.inet_ntoa(packet[16:20])
            return dst_ip
        elif version == 6:
            # IPv6 packet
            dst_ip = socket.inet_ntop(socket.AF_INET6, packet[24:40])
            return dst_ip
        else:
            raise ValueError(f"Unknown IP version: {version}")
    
    async def _forward_packet(self, dst_ip, packet):
        """
        Forward a packet to the next hop based on routing table.
        
        Args:
            dst_ip: Destination IP address
            packet: Packet data to forward
        """
        # Find next hop in routing table
        next_hop = self.routing_table.get(dst_ip)
        if not next_hop:
            logger.warning(f"No route to {dst_ip}")
            return
        
        # Get connection to next hop
        connection = self.connections.get(next_hop)
        if not connection:
            logger.warning(f"No connection to next hop {next_hop}")
            return
        
        _, writer = connection
        
        # Encrypt packet for next hop
        peer_key_pem = self.peers[next_hop]['public_key']
        peer_key = serialization.load_pem_public_key(peer_key_pem.encode())
        encrypted_packet = encrypt_data(packet, peer_key)
        
        # Create message header
        header = struct.pack('!II', 1, len(encrypted_packet))
        
        # Send packet
        writer.write(header + encrypted_packet)
        await writer.drain()
    
    async def _handle_control_message(self, peer_id, data):
        """
        Handle a control message from a peer.
        
        Args:
            peer_id: ID of the peer that sent the message
            data: Message data
        """
        try:
            message = json.loads(data.decode())
            msg_type = message.get('type')
            
            if msg_type == 'route_update':
                # Update routing table with routes from peer
                routes = message.get('routes', {})
                for dst, next_hop in routes.items():
                    if next_hop == self.node_id:
                        continue  # Skip routes through ourselves
                    self.routing_table[dst] = peer_id
            

#!/usr/bin/env python3
"""
Pacata Node - Core implementation of the Pacata mesh VPN node.

This module contains the implementation of a Pacata node that handles peer connections,
manages tunneling interfaces, and participates in the decentralized network while
earning Pacata tokens for providing bandwidth.
"""

import os
import sys
import time
import json
import logging
import argparse
import asyncio
import ipaddress
import hashlib
import random
from datetime import datetime, timedelta
from typing import Dict, List, Set, Tuple, Optional, Any

import aiohttp
import websockets
import nacl.signing
import nacl.encoding
import nacl.public

from .networking.tunnel import TunnelInterface
from .networking.discovery import PeerDiscovery
from .networking.nat import NATTraversal
from .networking.routing import MeshRouter
from .blockchain.transaction import Transaction
from .blockchain.wallet import Wallet
from .blockchain.ledger import DistributedLedger
from .cryptography.encryption import encrypt_data, decrypt_data
from .utils.config import Config
from .utils.constants import DEFAULT_PORT, DEFAULT_BOOTSTRAP_NODES, MIN_BANDWIDTH_FOR_REWARD


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(os.path.expanduser("~/.pacata/logs/node.log"), mode='a')
    ]
)
logger = logging.getLogger("pacata.node")


class PacataNode:
    """
    Implementation of a Pacata mesh VPN node that connects to peers,
    routes encrypted traffic, and earns Pacata tokens for providing bandwidth.
    """
    
    def __init__(self, config_path: str = None, wallet_path: str = None):
        """
        Initialize a new Pacata node.
        
        Args:
            config_path: Path to the configuration file
            wallet_path: Path to the wallet file
        """
        # Initialize configuration
        self.config = Config(config_path)
        
        # Node identity
        self.node_id = self.config.get("node_id")
        if not self.node_id:
            self.node_id = hashlib.sha256(os.urandom(32)).hexdigest()
            self.config.set("node_id", self.node_id)
            self.config.save()
            
        # Initialize wallet
        self.wallet = Wallet(wallet_path)
        
        # Node state
        self.running = False
        self.peers = {}  # node_id -> connection_info
        self.routing_table = {}  # destination -> next_hop
        self.bandwidth_usage = {}  # peer_id -> bytes_relayed
        self.last_reward_claim = datetime.now()
        
        # Components
        self.tunnel = TunnelInterface(self.config)
        self.discovery = PeerDiscovery(self.node_id, self.config)
        self.nat_traversal = NATTraversal(self.config)
        self.router = MeshRouter(self.node_id)
        self.ledger = DistributedLedger(self.config)
        
        # Periodic task handles
        self.periodic_tasks = []
        
    async def start(self):
        """Start the node and all its components."""
        logger.info(f"Starting Pacata node {self.node_id}")
        self.running = True
        
        # Start components
        await self.tunnel.start()
        await self.discovery.start()
        await self.ledger.start()
        
        # Connect to bootstrap nodes
        await self.connect_to_bootstrap_nodes()
        
        # Start periodic tasks
        self.start_periodic_tasks()
        
        logger.info("Pacata node started successfully")
        
    async def stop(self):
        """Stop the node and all its components."""
        logger.info("Stopping Pacata node")
        self.running = False
        
        # Cancel periodic tasks
        for task in self.periodic_tasks:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        
        # Stop components
        await self.ledger.stop()
        await self.discovery.stop()
        await self.tunnel.stop()
        
        logger.info("Pacata node stopped")
        
    async def connect_to_bootstrap_nodes(self):
        """Connect to bootstrap nodes to join the network."""
        bootstrap_nodes = self.config.get("bootstrap_nodes", DEFAULT_BOOTSTRAP_NODES)
        
        for node in bootstrap_nodes:
            try:
                logger.info(f"Connecting to bootstrap node: {node}")
                await self.discovery.connect_to_peer(node)
            except Exception as e:
                logger.error(f"Failed to connect to bootstrap node {node}: {str(e)}")
    
    def start_periodic_tasks(self):
        """Start periodic maintenance tasks."""
        # Peer discovery every 5 minutes
        self.periodic_tasks.append(
            asyncio.create_task(self._periodic_task(300, self._discover_peers))
        )
        
        # Routing table maintenance every 2 minutes
        self.periodic_tasks.append(
            asyncio.create_task(self._periodic_task(120, self._update_routing_table))
        )
        
        # Claim bandwidth rewards every hour
        self.periodic_tasks.append(
            asyncio.create_task(self._periodic_task(3600, self._claim_bandwidth_reward))
        )
        
        # Sync ledger every 10 minutes
        self.periodic_tasks.append(
            asyncio.create_task(self._periodic_task(600, self._sync_ledger))
        )
    
    async def _periodic_task(self, interval: int, coro):
        """Run a periodic task at the specified interval."""
        while self.running:
            try:
                await coro()
            except Exception as e:
                logger.error(f"Error in periodic task {coro.__name__}: {str(e)}")
            
            await asyncio.sleep(interval)
    
    async def _discover_peers(self):
        """Discover new peers in the network."""
        logger.debug("Running peer discovery")
        await self.discovery.discover_peers()
    
    async def _update_routing_table(self):
        """Update the routing table based on current peers."""
        logger.debug("Updating routing table")
        await self.router.update_routes(self.peers)
        self.routing_table = self.router.get_routing_table()
    
    async def _sync_ledger(self):
        """Synchronize the distributed ledger with peers."""
        logger.debug("Syncing ledger with peers")
        await self.ledger.sync_with_peers(self.peers)
    
    async def _claim_bandwidth_reward(self):
        """
        Claim rewards for bandwidth provided to the network.
        
        This method calculates the amount of bandwidth provided since the last claim,
        creates a bandwidth reward transaction, and submits it to the ledger.
        """
        logger.info("Claiming bandwidth rewards")
        
        # Calculate total bandwidth provided
        total_bandwidth = sum(self.bandwidth_usage.values())
        
        # Reset bandwidth usage counter
        self.bandwidth_usage = {}
        
        # Only claim rewards if we've provided enough bandwidth
        if total_bandwidth < MIN_BANDWIDTH_FOR_REWARD:
            logger.info(f"Not enough bandwidth provided for reward: {total_bandwidth} bytes")
            return
        
        # Calculate reward amount (simplified formula)
        # In a real implementation, this would involve a more complex economic model
        reward_amount = total_bandwidth / (1024 * 1024)  # Convert to MB
        
        # Create reward transaction
        try:
            tx = Transaction(
                sender="network",
                recipient=self.wallet.get_address(),
                amount=reward_amount,
                tx_type="bandwidth_reward",
                timestamp=datetime.now().isoformat(),
                metadata={
                    "bandwidth_bytes": total_bandwidth,
                    "node_id": self.node_id
                }
            )
            
            # Submit transaction to the ledger
            success = await self.ledger.submit_transaction(tx)
            
            if success:
                logger.info(f"Successfully claimed {reward_amount} Pacata for {total_bandwidth} bytes of bandwidth")
                self.last_reward_claim = datetime.now()
            else:
                logger.error("Failed to claim bandwidth reward")
                
        except Exception as e:
            logger.error(f"Error claiming bandwidth reward: {str(e)}")
    
    async def handle_packet(self, packet_data: bytes, source_addr: Tuple[str, int]) -> None:
        """
        Handle an incoming data packet from the network.
        
        Args:
            packet_data: The encrypted packet data
            source_addr: The source address (IP, port) of the packet
        """
        try:
            # Decrypt and authenticate packet
            decrypted_data = decrypt_data(packet_data, self.wallet.get_private_key())
            
            # Parse packet header
            packet = json.loads(decrypted_data)
            
            # Update bandwidth usage stats for the source
            peer_id = packet.get("sender_id")
            if peer_id in self.peers:
                self.bandwidth_usage[peer_id] = self.bandwidth_usage.get(peer_id, 0) + len(packet_data)
            
            # Handle packet based on type
            packet_type = packet.get("type")
            
            if packet_type == "data":
                # Forward data packets according to routing table
                await self._forward_packet(packet)
            elif packet_type == "discovery":
                # Handle peer discovery packet
                await self.discovery.handle_discovery_packet(packet, source_addr)
            elif packet_type == "ledger":
                # Handle ledger sync packet
                await self.ledger.handle_ledger_packet(packet)
            else:
                logger.warning(f"Unknown packet type: {packet_type}")
                
        except Exception as e:
            logger.error(f"Error handling packet: {str(e)}")
    
    async def _forward_packet(self, packet):
        """Forward a data packet to its destination according to the routing table."""
        destination = packet.get("destination_id")
        
        if destination == self.node_id:
            # Packet is for us, deliver to local interface
            await self.tunnel.write_to_tun(packet.get("payload"))
        elif destination in self.routing_table:
            # Forward to next hop
            next_hop = self.routing_table[destination]
            if next_hop in self.peers:
                peer_info = self.peers[next_hop]
                
                # Re-encrypt for the next hop
                encrypted_data = encrypt_data(
                    json.dumps(packet),
                    self.peers[next_hop]["public_key"]
                )
                
                # Send to next hop
                await self.discovery.send_to_peer(next_hop, encrypted_data)
                
                # Update bandwidth usage stats
                self.bandwidth_usage[next_hop] = self.bandwidth_usage.get(next_hop, 0) + len(encrypted_data)
            else:
                logger.warning(f"Next hop {next_hop} not in peers list")
        else:
            logger.warning(f"No route to destination {destination}")


def run_node():
    """
    Entry point for the pacata-node command.
    
    This function parses command-line arguments, initializes, and runs a Pacata node.
    """
    parser = argparse.ArgumentParser(description="Run a Pacata mesh VPN node")
    parser.add_argument("--config", "-c", type=str, help="Path to config file")
    parser.add_argument("--wallet", "-w", type=str, help="Path to wallet file")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable verbose logging")
    args = parser.parse_args()
    
    # Set up logging level
    if args.verbose:
        logger.setLevel(logging.DEBUG)
    
    # Ensure data directory exists
    data_dir = os.path.expanduser("~/.pacata")
    os.makedirs(os.path.join(data_dir, "logs"), exist_ok=True)
    
    # Initialize node
    node = PacataNode(config_path=args.config, wallet_path=args.wallet)
    
    # Start the event loop
    loop = asyncio.get_event_loop()
    
    # Handle graceful shutdown
    for signal_name in ('SIGINT', 'SIGTERM'):
        loop.add_signal_handler(
            getattr(signal, signal_name),
            lambda: asyncio.create_task(shutdown(loop, node))
        )
    
    try:
        # Start the node
        loop.run_until_complete(node.start())
        
        # Run forever
        loop.run_forever()
    finally:
        # Close the event loop
        loop.close()
        logger.info("Node shutdown complete")


async def shutdown(loop, node):
    """Gracefully shutdown the node and event loop."""
    logger.info("Shutdown signal received")
    
    # Stop the node
    await node.stop()
    
    # Stop the event loop
    loop.stop()


if __name__ == "__main__":
    run_node()

#!/usr/bin/env python3
"""
Pacata Mesh VPN Node Implementation

This module provides the functionality for running a Pacata mesh VPN node,
handling peer connections, managing the tunneling interface, and participating
in the decentralized network.
"""

import argparse
import asyncio
import ipaddress
import json
import logging
import os
import signal
import sys
import time
from typing import Dict, List, Optional, Set, Tuple

# Importing from other modules in the package
from pacata_mesh_vpn.networking import create_tunnel, peer_discovery, nat_traversal
from pacata_mesh_vpn.cryptography import generate_keys, encrypt_traffic, decrypt_traffic
from pacata_mesh_vpn.blockchain import transaction, consensus, blockchain

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(os.path.expanduser("~/.pacata/node.log"))
    ]
)
logger = logging.getLogger("pacata-node")


class PacataNode:
    """
    Main class for a Pacata mesh VPN node that manages peer connections,
    tunneling interfaces, and participates in the decentralized network.
    """
    
    def __init__(self, config_path: str = None):
        """
        Initialize a Pacata node with configuration.
        
        Args:
            config_path: Path to configuration file
        """
        self.running = False
        self.peers = {}  # Map of peer_id -> connection_info
        self.routes = {}  # Map of destination -> next_hop
        self.tunnel = None
        self.dht = None  # Distributed Hash Table for peer discovery
        self.blockchain = None
        self.wallet = None
        
        # Load configuration from file or use defaults
        self.config = self._load_config(config_path)
        
        # Set up event loop
        self.loop = asyncio.get_event_loop()
        
        # Initialize directories
        os.makedirs(os.path.expanduser("~/.pacata"), exist_ok=True)
    
    def _load_config(self, config_path: Optional[str]) -> Dict:
        """
        Load configuration from the specified path or use defaults.
        
        Args:
            config_path: Path to JSON configuration file
            
        Returns:
            Dict containing node configuration
        """
        default_config = {
            "listen_port": 9371,
            "tunnel_ip": "10.7.0.1/24",
            "bootstrap_nodes": [
                "dht.pacata-vpn.org:9371"
            ],
            "max_peers": 50,
            "data_dir": os.path.expanduser("~/.pacata"),
            "bandwidth_limit": 1024 * 1024,  # 1 MB/s
            "enable_blockchain": True,
            "enable_rewards": True
        }
        
        if not config_path:
            return default_config
        
        try:
            with open(config_path, 'r') as f:
                user_config = json.load(f)
                return {**default_config, **user_config}
        except (IOError, json.JSONDecodeError) as e:
            logger.error(f"Failed to load config: {e}")
            return default_config
    
    async def start(self):
        """Start the Pacata node and all its components."""
        if self.running:
            logger.warning("Node is already running")
            return
        
        logger.info("Starting Pacata node...")
        self.running = True
        
        # Generate or load cryptographic keys
        await self._setup_cryptography()
        
        # Set up the network tunnel
        self._setup_tunnel()
        
        # Initialize the DHT for peer discovery
        await self._setup_peer_discovery()
        
        # Set up blockchain components if enabled
        if self.config["enable_blockchain"]:
            await self._setup_blockchain()
        
        # Start listening for incoming connections
        await self._start_listener()
        
        # Connect to bootstrap nodes
        await self._connect_to_bootstrap_nodes()
        
        # Start periodic tasks
        self._start_periodic_tasks()
        
        logger.info("Pacata node started successfully")
    
    async def stop(self):
        """Stop the Pacata node and clean up resources."""
        if not self.running:
            logger.warning("Node is not running")
            return
        
        logger.info("Stopping Pacata node...")
        self.running = False
        
        # Cancel all tasks
        for task in asyncio.all_tasks(self.loop):
            if task is not asyncio.current_task():
                task.cancel()
        
        # Disconnect from peers
        await self._disconnect_from_peers()
        
        # Close the tunnel
        if self.tunnel:
            self.tunnel.close()
            self.tunnel = None
        
        # Save blockchain state if enabled
        if self.config["enable_blockchain"] and self.blockchain:
            await self.blockchain.save_state()
        
        logger.info("Pacata node stopped")
    
    async def _setup_cryptography(self):
        """Set up cryptographic keys for secure communication."""
        key_path = os.path.join(self.config["data_dir"], "keys.json")
        
        if os.path.exists(key_path):
            logger.info("Loading existing keys...")
            with open(key_path, 'r') as f:
                keys = json.load(f)
        else:
            logger.info("Generating new cryptographic keys...")
            keys = generate_keys()
            with open(key_path, 'w') as f:
                json.dump(keys, f)
        
        self.keys = keys
        logger.info("Cryptographic setup complete")
    
    def _setup_tunnel(self):
        """Set up the VPN tunnel interface."""
        logger.info("Creating tunnel interface...")
        try:
            ip_network = ipaddress.ip_network(self.config["tunnel_ip"], strict=False)
            self.tunnel = create_tunnel(ip_network)
            logger.info(f"Tunnel created with IP: {self.config['tunnel_ip']}")
        except Exception as e:
            logger.error(f"Failed to create tunnel: {e}")
            raise
    
    async def _setup_peer_discovery(self):
        """Initialize the distributed hash table for peer discovery."""
        logger.info("Initializing peer discovery...")
        self.dht = peer_discovery.create_dht(
            self.config["listen_port"],
            self.keys["node_id"]
        )
        await self.dht.start()
        logger.info("Peer discovery initialized")
    
    async def _setup_blockchain(self):
        """Initialize blockchain components if enabled."""
        logger.info("Initializing blockchain components...")
        blockchain_path = os.path.join(self.config["data_dir"], "blockchain")
        os.makedirs(blockchain_path, exist_ok=True)
        
        self.blockchain = blockchain.Blockchain(blockchain_path)
        self.wallet = self.blockchain.create_wallet(self.keys)
        
        await self.blockchain.initialize()
        logger.info("Blockchain components initialized")
    
    async def _start_listener(self):
        """Start listening for incoming peer connections."""
        logger.info(f"Starting listener on port {self.config['listen_port']}...")
        server = await asyncio.start_server(
            self._handle_incoming_connection,
            "0.0.0.0",
            self.config["listen_port"]
        )
        
        async def serve_forever():
            try:
                async with server:
                    await server.serve_forever()
            except asyncio.CancelledError:
                logger.info("Listener stopped")
        
        self.loop.create_task(serve_forever())
        logger.info(f"Listening on port {self.config['listen_port']}")
    
    async def _handle_incoming_connection(self, reader, writer):
        """
        Handle an incoming connection from a peer.
        
        Args:
            reader: StreamReader object for receiving data
            writer: StreamWriter object for sending data
        """
        peer_address = writer.get_extra_info("peername")
        logger.info(f"New connection from {peer_address}")
        
        try:
            # Perform handshake and authentication
            peer_id, encryption_key = await self._authenticate_peer(reader, writer)
            
            if peer_id:
                # Add to peers list
                self.peers[peer_id] = {
                    "reader": reader,
                    "writer": writer,
                    "address": peer_address,
                    "encryption_key": encryption_key,
                    "last_seen": time.time(),
                    "bandwidth_usage": 0
                }
                
                # Start processing messages from this peer
                self.loop.create_task(self._process_peer_messages(peer_id))
                
                # Announce the new peer to DHT
                await self.dht.announce_peer(peer_id, peer_address)
            else:
                writer.close()
                await writer.wait_closed()
                
        except Exception as e:
            logger.error(f"Error handling connection from {peer_address}: {e}")
            writer.close()
            await writer.wait_closed()
    
    async def _authenticate_peer(self, reader, writer) -> Tuple[str, bytes]:
        """
        Authenticate a peer using cryptographic signatures.
        
        Args:
            reader: StreamReader for the peer connection
            writer: StreamWriter for the peer connection
            
        Returns:
            Tuple of (peer_id, encryption_key) if authentication successful,
            (None, None) otherwise
        """
        try:
            # Send our authentication challenge
            challenge = os.urandom(32)
            writer.write(challenge)
            await writer.drain()
            
            # Receive and verify peer's response
            response_data = await reader.readexactly(256)  # Assuming RSA-2048 signature
            
            # Verify the signature and extract peer ID
            peer_id = "peer_id_placeholder"  # This would be extracted from the verified signature
            
            # Negotiate an encryption key
            encryption_key = os.urandom(32)  # In reality, this would be securely negotiated
            
            return peer_id, encryption_key
            
        except Exception as e:
            logger.error(f"Authentication failed: {e}")
            return None, None
    
    async def _process_peer_messages(self, peer_id: str):
        """
        Process messages from a specific peer.
        
        Args:
            peer_id: Identifier of the peer
        """
        if peer_id not in self.peers:
            logger.error(f"Unknown peer ID: {peer_id}")
            return
        
        peer = self.peers[peer_id]
        reader = peer["reader"]
        
        try:
            while self.running and not reader.at_eof():
                # Read message length (4 bytes, big-endian)
                length_bytes = await reader.readexactly(4)
                message_length = int.from_bytes(length_bytes, byteorder="big")
                
                # Read message data
                encrypted_data = await reader.readexactly(message_length)
                
                # Decrypt the message
                data = decrypt_traffic(encrypted_data, peer["encryption_key"])
                
                # Process the message
                await self._handle_message(peer_id, data)
                
                # Update last seen timestamp
                peer["last_seen"] = time.time()
                
        except asyncio.IncompleteReadError:
            logger.info(f"Peer {peer_id} disconnected")
        except Exception as e:
            logger.error(f"Error processing messages from peer {peer_id}: {e}")
        finally:
            # Clean up the connection
            if peer_id in self.peers:
                await self._disconnect_peer(peer_id)
    
    async def _handle_message(self, peer_id: str, data: bytes):
        """
        Handle a message received from a peer.
        
        Args:
            peer_id: Identifier of the peer who sent the message
            data: Decrypted message data
        """
        try:
            message = json.loads(data.decode("utf-8"))
            message_type = message.get("type")
            
            if message_type == "ping":
                await self._handle_ping(peer_id, message)
            elif message_type == "route_update":
                await self._handle_route_update(peer_id, message)
            elif message_type == "data":
                await self._handle_data_packet(peer_id, message)
            elif message_type == "transaction":
                await self._handle_transaction(peer_id, message)
            elif message_type == "block":
                await self._handle_block(peer_id, message)
            else:
                logger.warning(f"Unknown message type from {peer_id}: {message_type}")
                
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON message from peer {peer_id}")
        except Exception as e:
            logger.error(f"Error handling message from {peer_id}: {e}")
    
    async def _handle_ping(self, peer_id: str, message: Dict):
        """
        Handle a ping message from a peer.
        
        Args:
            peer_id: Identifier of the peer
            message: The ping message
        """
        # Send a pong response
        await self._send_message(peer_id, {
            "type": "pong",
            "id": message.get("id"),
            "timestamp": time.time()
        })
    
    async def _handle_route_update(self, peer_id: str, message: Dict):
        """
        Handle a route update message from a peer.
        
        Args:
            peer_id: Identifier of the peer
            message: The route update message
        """
        routes = message.get("routes", {})
        
        # Update routing table
        for destination, route_info in routes.items():
            if route_info["via"] == peer_id:
                self.routes[destination] = {
                    "next_hop": peer_id,
                    "metric": route_info["metric"],
                    "timestamp": time.time()
                }
        
        # Propagate route updates to other peers
        await self._propagate_routes()
    
    async def _handle_data_packet(self, peer_id: str, message: Dict):
        """
        Handle a data packet from a peer.
        
        Args:
            peer_id: Identifier of the peer
            message: The data packet message
        """
        destination = message.get("destination")
        source = message.get("source")
        data = message.get("data")
        
        # Check if this node is the destination
        if destination == self.keys["node_id"]:
            # Process the data locally
            await self._process_local_data(source, data)
        else:
            # Forward the packet
            await self._forward_data_packet(destination, message)
    
    async def _process_local_data(self, source: str, data: bytes):
        """
        Process data intended for this node.
        
        Args:
            source: Source node ID
            data: Data payload
        """
        # In a real implementation, this would:
        # 1. Process VPN packets
        # 2. Route traffic to the local network interface
        # 3. Handle control messages
        pass
    
    async def _forward_data_packet(self, destination: str, message: Dict):
        """
        Forward a data packet to its destination.
        
        Args:
            destination: Destination node ID
            message: The data packet message
        """
        # Check if we have a route to the destination
        if destination in self.routes:
            next_hop = self.routes[destination]["next_hop"]
            
            # Update bandwidth usage for billing
            if self.config["enable_blockchain"] and self.config["enable_rewards"]:
                data_size = len(json.dumps(message).encode("utf-8"))
                self.peers[next_hop]["bandwidth_usage"] += data_size
                
                # If bandwidth usage reaches threshold, create a payment transaction
                if self.peers[next_hop]["bandwidth_usage"] > 1024 * 1024:  # 1 MB
                    await self._create_bandwidth_payment(next_hop)
            
            # Forward the packet
            await self._send_message(next_hop, message)
            logger.debug(f"Forwarded packet to {destination} via {next_hop}")
        else:
            # No route found, try to discover one
            await self._discover_route(destination)
            logger.warning(f"No route to destination: {destination}")
    
    async def _discover_route(self, destination: str):
        """
        Attempt to discover a route to a destination.
        
        Args:
            destination: Destination node ID to find
        """
        logger.info(f"Attempting to discover route to {destination}")
        
        # Query the DHT for the destination
        results = await self.dht.find_node(destination)
        
        if results:
            for peer_info in results:
                # Try to connect to the peer
                success = await self._connect_to_peer(
                    peer_info["node_id"],
                    peer_info["address"],
                    peer_info["port"]
                )
                
                if success:
                    logger.info(f"Established new route to {destination}")
                    return True
        
        # Broadcast route request to all connected peers
        await self._broadcast_message({
            "type": "route_request",
            "destination": destination,
            "source": self.keys["node_id"],
            "timestamp": time.time()
        })
        
        return False
    
    async def _connect_to_bootstrap_nodes(self):
        """Connect to bootstrap nodes to join the network."""
        logger.info("Connecting to bootstrap nodes...")
        
        for bootstrap_node in self.config["bootstrap_nodes"]:
            try:
                # Parse host and port
                if ":" in bootstrap_node:
                    host, port_str = bootstrap_node.split(":")
                    port = int(port_str)
                else:
                    host = bootstrap_node
                    port = self.config["listen_port"]
                
                # Connect to the bootstrap node
                await self._connect_to_peer("bootstrap", host, port)
                
            except Exception as e:
                logger.error(f"Failed to connect to bootstrap node {bootstrap_node}: {e}")
    
    async def _connect_to_peer(self, peer_id: str, host: str, port: int) -> bool:
        """
        Establish a connection to a peer.
        
        Args:
            peer_id: Identifier for the peer
            host: Hostname or IP address
            port: Port number
            
        Returns:
            bool: True if connection was successful, False otherwise
        """
        logger.info(f"Connecting to peer {peer_id} at {host}:{port}...")
        
        try:
            # Create a connection
            reader, writer = await asyncio.open_connection(host, port)
            
            # Perform handshake and authentication
            authenticated_peer_id, encryption_key = await self._authenticate_peer(reader, writer)
            
            if authenticated_peer_id:
                # Add to peers list
                self.peers[authenticated_peer_id] = {
                    "reader": reader,
                    "writer": writer,
                    "address": (host, port),
                    "encryption_key": encryption_key,
                    "last_seen": time.time(),
                    "bandwidth_usage": 0
                }
                
                # Start processing messages from this peer
                self.loop.create_task(self._process_peer_messages(authenticated_peer_id))
                
                # Exchange routing information
                await self._exchange_routing_info(authenticated_peer_id)
                
                logger.info(f"Successfully connected to peer {authenticated_peer_id}")
                return True
            else:
                writer.close()
                await writer.wait_closed()
                logger.warning(f"Authentication failed with {host}:{port}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to connect to peer at {host}:{port}: {e}")
            return False
    
    async def _exchange_routing_info(self, peer_id: str):
        """
        Exchange routing information with a peer.
        
        Args:
            peer_id: Identifier of the peer
        """
        # Prepare our routing table
        routes_to_share = {}
        
        for dest, route_info in self.routes.items():
            # Don't share routes that go through this peer
            if route_info["next_hop"] != peer_id:
                routes_to_share[dest] = {
                    "via": self.keys["node_id"],
                    "metric": route_info["metric"] + 1  # Increase metric by 1
                }
        
        # Add ourselves to the routes
        routes_to_share[self.keys["node_id"]] = {
            "via": self.keys["node_id"],
            "metric": 0
        }
        
        # Send routing information
        await self._send_message(peer_id, {
            "type": "route_update",
            "routes": routes_to_share,
            "timestamp": time.time()
        })
    
    async def _broadcast_message(self, message: Dict):
        """
        Broadcast a message to all connected peers.
        
        Args:
            message: Message to broadcast
        """
        for peer_id in list(self.peers.keys()):
            try:
                await self._send_message(peer_id, message)
            except Exception as e:
                logger.error(f"Failed to send message to peer {peer_id}: {e}")
    
    async def _send_message(self, peer_id: str, message: Dict):
        """
        Send a message to a specific peer.
        
        Args:
            peer_id: Identifier of the peer
            message: Message to send
        """
        if peer_id not in self.peers:
            logger.error(f"Unknown peer ID: {peer_id}")
            return
        
        peer = self.peers[peer_id]
        writer = peer["writer"]
        
        try:
            # Convert message to JSON and encrypt
            data = json.dumps(message).encode("utf-8")
            encrypted_data = encrypt_traffic(data, peer["encryption_key"])
            
            # Write message length first (4 bytes, big-endian)
            writer.write(len(encrypted_data).to_bytes(4, byteorder="big"))
            
            # Write encrypted data
            writer.write(encrypted_data)
            await writer.drain()
            
        except Exception as e:
            logger.error(f"Error sending message to {peer_id}: {e}")
            await self._disconnect_peer(peer_id)
    
    async def _disconnect_peer(self, peer_id: str):
        """
        Disconnect from a specific peer.
        
        Args:
            peer_id: Identifier of the peer
        """
        if peer_id not in self.peers:
            return
        
        peer = self.peers[peer_id]
        
        try:
            peer["writer"].close()
            await peer["writer"].wait_closed()
        except Exception as e:
            logger.error(f"Error closing connection to peer {peer_id}: {e}")
        
        # Remove from peers dict
        del self.peers[peer_id]
        
        # Update routing table
        self._remove_routes_via_peer(peer_id)
        
        logger.info(f"Disconnected from peer {peer_id}")
    
    async def _disconnect_from_peers(self):
        """Disconnect from all peers."""
        logger.info(f"Disconnecting from {len(self.peers)} peers...")
        
        for peer_id in list(self.peers.keys()):
            await self._disconnect_peer(peer_id)
    
    def _remove_routes_via_peer(self, peer_id: str):
        """
        Remove routes that go through a specific peer.
        
        Args:
            peer_id: Identifier of the peer
        """
        routes_to_remove = []
        
        for dest, route_info in self.routes.items():
            if route_info["next_hop"] == peer_id:
                routes_to_remove.append(dest)
        
        for dest in routes_to_remove:
            del self.routes[dest]
            
        if routes_to_remove:
            logger.info(f"Removed {len(routes_to_remove)} routes via peer {peer_id}")
    
    def _start_periodic_tasks(self):
        """Start periodic tasks for maintenance."""
        logger.info("Starting periodic tasks...")
        
        # Create and schedule tasks
        self.loop.create_task(self._periodic_peer_cleanup())
        self.loop.create_task(self._periodic_route_updates())
        self.loop.create_task(self._periodic_dht_maintenance())
        
        if self.config["enable_blockchain"]:
            self.loop.create_task(self._periodic_blockchain_sync())
            
            if self.config["enable_rewards"]:
                self.loop.create_task(self._periodic_reward_claims())
    
    async def _periodic_peer_cleanup(self):
        """Periodically clean up inactive peers."""
        while self.running:
            try:
                # Find peers that haven't been seen recently
                current_time = time.time()
                inactive_peers = []
                
                for peer_id, peer_info in self.peers.items():
                    if current_time - peer_info["last_seen"] > 300:  # 5 minutes
                        inactive_peers.append(peer_id)
                
                # Disconnect from inactive peers
                for peer_id in inactive_peers:
                    logger.info(f"Peer {peer_id} inactive, disconnecting")
                    await self._disconnect_peer(peer_id)
                
            except Exception as e:
                logger.error(f"Error during peer cleanup: {e}")
            
            # Wait for next cleanup cycle
            await asyncio.sleep(60)  # Check every minute
    
    async def _periodic_route_updates(self):
        """Periodically send route updates to peers."""
        while self.running:
            try:
                # Prepare routing update
                await self._propagate_routes()
            except Exception as e:
                logger.error(f"Error during route updates: {e}")
            
            # Wait for next update cycle
            await asyncio.sleep(300)  # Send updates every 5 minutes
    
    async def _propagate_routes(self):
        """Propagate route updates to all peers."""
        for peer_id in list(self.peers.keys()):
            await self._exchange_routing_info(peer_id)
    
    async def _periodic_dht_maintenance(self):
        """Periodically perform DHT maintenance."""
        while self.running:
            try:
                if self.dht:
                    await self.dht.refresh_buckets()
            except Exception as e:
                logger.error(f"Error during DHT maintenance: {e}")
            
            # Wait for next maintenance cycle
            await asyncio.sleep(600)  # Every 10 minutes
    
    async def _periodic_blockchain_sync(self):
        """Periodically synchronize blockchain state."""
        while self.running and self.blockchain:
            try:
                await self.blockchain.sync()
            except Exception as e:
                logger.error(f"Error during blockchain sync: {e}")
            
            # Wait for next sync cycle
            await asyncio.sleep(300)  # Every 5 minutes
    
    async def _periodic_reward_claims(self):
        """Periodically claim rewards for bandwidth provision."""
        while self.running and self.blockchain and self.wallet:
            try:
                # Calculate total bandwidth provided
                total_bytes = sum(peer["bandwidth_usage"] for peer in self.peers.values())
                
                # Reset counters after claiming
                for peer_id in self.peers:
                    self.peers[peer_id]["bandwidth_usage"] = 0
                
                # Create a reward claim if bandwidth was provided
                if total_bytes > 0:
                    await self._claim_bandwidth_reward(total_bytes)
            except Exception as e:
                logger.error(f"Error during reward claiming: {e}")
            
            # Wait for next claim cycle
            await asyncio.sleep(3600)  # Claim rewards hourly
    
    async def _create_bandwidth_payment(self, peer_id: str):
        """
        Create a payment transaction for bandwidth usage.
        
        Args:
            peer_id: Identifier of the peer to pay
        """
        if not self.blockchain or not self.wallet:
            return
        
        peer = self.peers[peer_id]
        bandwidth_usage = peer["bandwidth_usage"]
        
        # Calculate payment amount based on bandwidth usage
        # (simple model: 1 Pacata per MB)
        amount = bandwidth_usage / (1024 * 1024)
        
        # Create and send transaction
        if amount >= 0.01:  # Minimum transaction amount
            try:
                tx = await self.blockchain.create_transaction(
                    self.wallet,
                    peer_id,
                    amount,
                    "bandwidth"
                )
                
                # Broadcast the transaction
                await self._broadcast_message({
                    "type": "transaction",
                    "transaction": tx.to_dict()
                })
                
                # Reset bandwidth counter
                peer["bandwidth_usage"] = 0
                
                logger.info(f"Created payment of {amount:.4f} Pacata to {peer_id} for bandwidth")
                
            except Exception as e:
                logger.error(f"Failed to create bandwidth payment: {e}")
    
    async def _claim_bandwidth_reward(self, total_bytes: int):
        """
        Claim rewards for providing bandwidth to the network.
        
        Args:
            total_bytes: Total bytes of bandwidth provided
        """
        if not self.blockchain or not self.wallet:
            return
        
        # Calculate reward based on provided bandwidth
        # (simple model: 0.5 Pacata per MB served)
        amount = (total_bytes / (1024 * 1024)) * 0.5
        
        if amount >= 0.01:  # Minimum claim amount
            try:
                # Create a reward claim transaction
                claim = await self.blockchain.create_reward_claim(
                    self.wallet,
                    amount,
                    
