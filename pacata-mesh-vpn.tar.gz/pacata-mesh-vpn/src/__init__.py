"""
Pacata Mesh VPN

A decentralized mesh VPN with integrated Pacata cryptocurrency that provides
secure, private networking with incentivized bandwidth sharing. This package
contains all the core modules required for the functioning of the system.
"""

__version__ = "0.1.0"

