"""
Cryptography module for the Pacata Mesh VPN.

This module provides cryptographic primitives for secure communication between nodes:
- Symmetric key generation and exchange (Diffie-Hellman)
- Encryption and decryption of data
- Message Authentication Codes (MACs) for integrity verification
- TLS integration for secure peer-to-peer connections
- Secure key storage and rotation mechanisms
"""

import os
import json
import base64
import secrets
import logging
import datetime
from pathlib import Path
from typing import Dict, Tuple, Optional, Union, List, Any

# Third-party cryptography libraries
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization, padding
from cryptography.hazmat.primitives.asymmetric import dh, rsa, padding as asym_padding
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.hmac import HMAC
from cryptography.fernet import Fernet
from cryptography.x509 import load_pem_x509_certificate
import ssl

# Set up logger
logger = logging.getLogger(__name__)


class DiffieHellmanExchange:
    """Handles Diffie-Hellman key exchange for symmetric encryption."""
    
    # Standard DH parameters (2048-bit)
    DH_PARAMETERS = dh.DHParameterNumbers(
        p=int(
            'FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74'
            '020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F1437'
            '4FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED'
            'EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF05'
            '98DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB'
            '9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B'
            'E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF695581718'
            '3995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF',
            16
        ),
        g=2,
        q=None
    ).parameters(default_backend())
    
    def __init__(self):
        """Initialize with new DH private key."""
        self.private_key = self.DH_PARAMETERS.generate_private_key()
        self.public_key = self.private_key.public_key()
    
    def get_public_bytes(self) -> bytes:
        """Return the public key in bytes format for transmission."""
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
    
    def generate_shared_key(self, peer_public_key_bytes: bytes, key_length: int = 32) -> bytes:
        """
        Generate a shared secret key from the peer's public key.
        
        Args:
            peer_public_key_bytes: The peer's public key as bytes
            key_length: Length of the derived key in bytes
            
        Returns:
            The derived shared key
        """
        # Load peer's public key
        peer_public_key = serialization.load_pem_public_key(
            peer_public_key_bytes,
            backend=default_backend()
        )
        
        # Compute shared key
        shared_key = self.private_key.exchange(peer_public_key)
        
        # Derive a symmetric key using HKDF
        derived_key = HKDF(
            algorithm=hashes.SHA256(),
            length=key_length,
            salt=None,
            info=b'pacata_mesh_vpn_key_derivation',
            backend=default_backend()
        ).derive(shared_key)
        
        return derived_key


class SymmetricCrypto:
    """Handles symmetric encryption and decryption operations."""
    
    def __init__(self, key: bytes):
        """
        Initialize with a symmetric key.
        
        Args:
            key: 32-byte symmetric key
        """
        if len(key) != 32:
            raise ValueError("Symmetric key must be 32 bytes")
        self.key = key
    
    def encrypt(self, plaintext: bytes) -> Dict[str, bytes]:
        """
        Encrypt data with AES-GCM.
        
        Args:
            plaintext: Data to encrypt
            
        Returns:
            Dictionary containing ciphertext, iv, and tag
        """
        # Generate a random 96-bit IV
        iv = os.urandom(12)
        
        # Create encryptor
        encryptor = Cipher(
            algorithms.AES(self.key),
            modes.GCM(iv),
            backend=default_backend()
        ).encryptor()
        
        # Encrypt the plaintext
        ciphertext = encryptor.update(plaintext) + encryptor.finalize()
        
        return {
            'ciphertext': ciphertext,
            'iv': iv,
            'tag': encryptor.tag
        }
    
    def decrypt(self, ciphertext: bytes, iv: bytes, tag: bytes) -> bytes:
        """
        Decrypt previously encrypted data.
        
        Args:
            ciphertext: Encrypted data
            iv: Initialization vector used during encryption
            tag: Authentication tag
            
        Returns:
            Decrypted plaintext
        """
        # Create decryptor
        decryptor = Cipher(
            algorithms.AES(self.key),
            modes.GCM(iv, tag),
            backend=default_backend()
        ).decryptor()
        
        # Decrypt the ciphertext
        return decryptor.update(ciphertext) + decryptor.finalize()


class MessageAuthenticator:
    """Provides message authentication code (MAC) functionality."""
    
    def __init__(self, key: bytes):
        """
        Initialize with a key for HMAC operations.
        
        Args:
            key: Secret key for HMAC
        """
        self.key = key
    
    def generate_mac(self, message: bytes) -> bytes:
        """
        Generate an HMAC for a message.
        
        Args:
            message: The message to authenticate
            
        Returns:
            HMAC digest
        """
        h = HMAC(self.key, hashes.SHA256(), backend=default_backend())
        h.update(message)
        return h.finalize()
    
    def verify_mac(self, message: bytes, mac: bytes) -> bool:
        """
        Verify an HMAC for a message.
        
        Args:
            message: The message that was authenticated
            mac: The HMAC to verify
            
        Returns:
            True if the MAC is valid, False otherwise
        """
        h = HMAC(self.key, hashes.SHA256(), backend=default_backend())
        h.update(message)
        try:
            h.verify(mac)
            return True
        except Exception:
            return False


class TLSManager:
    """Manages TLS connections for secure peer-to-peer communication."""
    
    def __init__(self, cert_path: Optional[str] = None, key_path: Optional[str] = None):
        """
        Initialize TLS manager with optional certificate and private key paths.
        
        Args:
            cert_path: Path to certificate file
            key_path: Path to private key file
        """
        self.cert_path = cert_path
        self.key_path = key_path
    
    def create_self_signed_cert(self, common_name: str, 
                               output_cert: str, output_key: str,
                               days_valid: int = 365) -> Tuple[str, str]:
        """
        Create a self-signed certificate for TLS communication.
        
        Args:
            common_name: Name for the certificate
            output_cert: Path to save the certificate
            output_key: Path to save the private key
            days_valid: Number of days the certificate will be valid
            
        Returns:
            Tuple of paths (cert_path, key_path)
        """
        # Generate private key
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )
        
        # Write private key to file
        with open(output_key, 'wb') as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            ))
        
        # Generate self-signed certificate
        # Note: In a real implementation, we would use cryptography.x509 to create
        # a proper certificate. This is simplified for this example.
        
        # For now, we'll just log a message:
        logger.info(f"Self-signed certificate would be created for {common_name}")
        logger.info(f"Certificate path: {output_cert}, Key path: {output_key}")
        
        self.cert_path = output_cert
        self.key_path = output_key
        
        return (output_cert, output_key)
    
    def create_ssl_context(self, verify_peer: bool = True) -> ssl.SSLContext:
        """
        Create an SSL context for secure connections.
        
        Args:
            verify_peer: Whether to verify peer certificates
            
        Returns:
            Configured SSL context
        """
        if not (self.cert_path and self.key_path):
            raise ValueError("Certificate and key paths must be set")
        
        context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
        
        if not verify_peer:
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        
        context.load_cert_chain(certfile=self.cert_path, keyfile=self.key_path)
        
        return context


class KeyManager:
    """Manages secure storage and rotation of cryptographic keys."""
    
    def __init__(self, storage_path: str = ".keys"):
        """
        Initialize key manager with a storage path.
        
        Args:
            storage_path: Directory to store keys
        """
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(exist_ok=True, parents=True)
        
        # Create master key for encrypting stored keys if it doesn't exist
        self.master_key_path = self.storage_path / "master.key"
        if not self.master_key_path.exists():
            self._generate_master_key()
        
        # Load master key
        with open(self.master_key_path, 'rb') as f:
            self.master_key = f.read()
        
        self.fernet = Fernet(base64.urlsafe_b64encode(self.master_key[:32]))
    
    def _generate_master_key(self):
        """Generate a new master key for encrypting other keys."""
        master_key = os.urandom(32)
        with open(self.master_key_path, 'wb') as f:
            f.write(master_key)
    
    def store_key(self, key_id: str, key_data: Dict[str, Any]) -> None:
        """
        Securely store a key with metadata.
        
        Args:
            key_id: Unique identifier for the key
            key_data: Dictionary containing key material and metadata
        """
        # Add creation timestamp if not present
        if 'created_at' not in key_data:
            key_data['created_at'] = datetime.datetime.now().isoformat()
        
        # Serialize and encrypt the key data
        serialized = json.dumps(key_data).encode('utf-8')
        encrypted = self.fernet.encrypt(serialized)
        
        # Save to file
        key_path = self.storage_path / f"{key_id}.key"
        with open(key_path, 'wb') as f:
            f.write(encrypted)
    
    def retrieve_key(self, key_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve and decrypt a stored key.
        
        Args:
            key_id: Unique identifier for the key
            
        Returns:
            Dictionary with key data or None if not found
        """
        key_path = self.storage_path / f"{key_id}.key"
        
        if not key_path.exists():
            return None
        
        try:
            with open(key_path, 'rb') as f:
                encrypted = f.read()
            
            decrypted = self.fernet.decrypt(encrypted)
            return json.loads(decrypted.decode('utf-8'))
        except Exception as e:
            logger.error(f"Failed to retrieve key {key_id}: {e}")
            return None
    
    def rotate_key(self, key_id: str, rotation_period_days: int = 30) -> Optional[Dict[str, Any]]:
        """
        Check if a key needs rotation and generate a new one if necessary.
        
        Args:
            key_id: Unique identifier for the key
            rotation_period_days: Days after which key should be rotated
            
        Returns:
            New key data if rotated, None if rotation not needed
        """
        key_data = self.retrieve_key(key_id)
        
        if not key_data:
            return None
        
        created_at = datetime.datetime.fromisoformat(key_data['created_at'])
        now = datetime.datetime.now()
        
        if (now - created_at).days >= rotation_period_days:
            # Generate new key with same characteristics
            new_key_data = key_data.copy()
            
            # If it's a symmetric key, generate new random bytes
            if 'symmetric_key' in new_key_data:
                new_key_data['symmetric_key'] = base64.b64encode(os.urandom(32)).decode('utf-8')
            
            # If it's a DH key, generate new DH exchange
            elif 'dh_private_key' in new_key_data:
                dh_exchange = DiffieHellmanExchange()
                new_key_data['dh_private_key'] = base64.b64encode(
                    dh_exchange.private_key.private_bytes(
                        encoding=serialization.Encoding.PEM,
                        format=serialization.PrivateFormat.PKCS8,
                        encryption_algorithm=serialization.NoEncryption()
                    )
                ).decode('utf-8')
                new_key_data['dh_public_key'] = base64.b64encode(dh_exchange.get_public_bytes()).decode('utf-8')
            
            # If it's an RSA key, generate new pair
            elif 'rsa_private_key' in new_key_data:
                private_key = rsa.generate_private_key(
                    public_exponent=65537,
                    key_size=new_key_data.get('key_size', 2048),
                    backend=default_backend()
                )
                new_key_data['rsa_private_key'] = base64.b64encode(
                    private_key.private_bytes(
                        encoding=serialization.Encoding.PEM,
                        format=serialization.PrivateFormat.PKCS8,
                        encryption_algorithm=serialization.NoEncryption()
                    )
                ).decode('utf-8')
                public_key = private_key.public_key()
                new_key_data['rsa_public_key'] = base64.b64encode(
                    public_key.public_bytes(
                        encoding=serialization.Encoding.PEM,
                        format=serialization.PublicFormat.SubjectPublicKeyInfo
                    )
                ).decode('utf-8')
            
            # Update creation and rotation timestamps
            new_key_data['created_at'] = now.isoformat()
            new_key_data['last_rotated'] = now.isoformat()
            new_key_data['previous_key_id'] = key_id
            
            # Generate new key ID with version increment
            version = key_data.get('version', 1)
            new_key_id = f"{key_id.split('_v')[0]}_v{version + 1}"
            
            # Store the new key
            self.store_key(new_key_id, new_key_data)
            
            # Update the old key to reference the new one
            key_data['rotated_to'] = new_key_id
            key_data['active'] = False
            self.store_key(key_id, key_data)
            
            logger.info(f"Key {key_id} rotated to {new_key_id}")
            return new_key_data
        
        return None
    
    def list_keys(self) -> List[str]:
        """
        List all keys stored in the key manager.
        
        Returns:
            List of key IDs
        """
        keys = []
        for key_file in self.storage_path.glob("*.key"):
            if key_file.name != "master.key":
                keys.append(key_file.stem)
        return keys
    
    def get_active_key(self, key_prefix: str) -> Optional[Tuple[str, Dict[str, Any]]]:
        """
        Get the most recent active key with a given prefix.
        
        Args:
            key_prefix: Prefix of the key to search for
            
        Returns:
            Tuple of (key_id, key_data) for the active key, or None if not found
        """
        matching_keys = [k for k in self.list_keys() if k.startswith(key_prefix)]
        if not matching_keys:
            return None
        
        # Sort by version number (assuming format prefix_vX)
        matching_keys.sort(key=lambda x: int(x.split('_v')[-1]) if '_v' in x else 0, reverse=True)
        
        # Get the most recent key that is active
        for key_id in matching_keys:
            key_data = self.retrieve_key(key_id)
            if key_data and key_data.get('active', True):
                return (key_id, key_data)
        
        return None
    
    def create_symmetric_key(self, key_prefix: str, key_length: int = 32) -> Tuple[str, Dict[str, Any]]:
        """
        Create a new symmetric key.
        
        Args:
            key_prefix: Prefix for the key ID
            key_length: Length of the key in bytes
            
        Returns:
            Tuple of (key_id, key_data)
        """
        key_id = f"{key_prefix}_v1"
        key_data = {
            'type': 'symmetric',
            'symmetric_key': base64.b64encode(os.urandom(key_length)).decode('utf-8'),
            'key_length': key_length,
            'created_at': datetime.datetime.now().isoformat(),
            'active': True,
            'version': 1
        }
        self.store_key(key_id, key_data)
        logger.info(f"Created new symmetric key: {key_id}")
        return (key_id, key_data)
    
    def create_dh_key_pair(self, key_prefix: str) -> Tuple[str, Dict[str, Any]]:
        """
        Create a new Diffie-Hellman key pair.
        
        Args:
            key_prefix: Prefix for the key ID
            
        Returns:
            Tuple of (key_id, key_data)
        """
        dh_exchange = DiffieHellmanExchange()
        private_key_bytes = dh_exchange.private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        key_id = f"{key_prefix}_v1"
        key_data = {
            'type': 'dh',
            'dh_private_key': base64.b64encode(private_key_bytes).decode('utf-8'),
            'dh_public_key': base64.b64encode(dh_exchange.get_public_bytes()).decode('utf-8'),
            'created_at': datetime.datetime.now().isoformat(),
            'active': True,
            'version': 1
        }
        self.store_key(key_id, key_data)
        logger.info(f"Created new DH key pair: {key_id}")
        return (key_id, key_data)
    
    def create_rsa_key_pair(self, key_prefix: str, key_size: int = 2048) -> Tuple[str, Dict[str, Any]]:
        """
        Create a new RSA key pair.
        
        Args:
            key_prefix: Prefix for the key ID
            key_size: Size of the RSA key in bits
            
        Returns:
            Tuple of (key_id, key_data)
        """
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=key_size,
            backend=default_backend()
        )
        
        private_key_bytes = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        public_key = private_key.public_key()
        public_key_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        key_id = f"{key_prefix}_v1"
        key_data = {
            'type': 'rsa',
            'rsa_private_key': base64.b64encode(private_key_bytes).decode('utf-8'),
            'rsa_public_key': base64.b64encode(public_key_bytes).decode('utf-8'),
            'key_size': key_size,
            'created_at': datetime.datetime.now().isoformat(),
            'active': True,
            'version': 1
        }
        self.store_key(key_id, key_data)
        logger.info(f"Created new RSA key pair: {key_id}")
        return (key_id, key_data)
    
    def get_symmetric_crypto(self, key_id: str) -> Optional[SymmetricCrypto]:
        """
        Get a SymmetricCrypto instance for a stored symmetric key.
        
        Args:
            key_id: ID of the key to use
            
        Returns:
            SymmetricCrypto instance or None if the key is not found or invalid
        """
        key_data = self.retrieve_key(key_id)
        if not key_data or 'symmetric_key' not in key_data:
            return None
        
        try:
            key_bytes = base64.b64decode(key_data['symmetric_key'])
            return SymmetricCrypto(key_bytes)
        except Exception as e:
            logger.error(f"Failed to create SymmetricCrypto for key {key_id}: {e}")
            return None
    
    def get_message_authenticator(self, key_id: str) -> Optional[MessageAuthenticator]:
        """
        Get a MessageAuthenticator instance for a stored key.
        
        Args:
            key_id: ID of the key to use
            
        Returns:
            MessageAuthenticator instance or None if the key is not found or invalid
        """
        key_data = self.retrieve_key(key_id)
        if not key_data:
            return None
        
        try:
            if 'symmetric_key' in key_data:
                key_bytes = base64.b64decode(key_data['symmetric_key'])
            elif 'mac_key' in key_data:
                key_bytes = base64.b64decode(key_data['mac_key'])
            else:
                return None
            
            return MessageAuthenticator(key_bytes)
        except Exception as e:
            logger.error(f"Failed to create MessageAuthenticator for key {key_id}: {e}")
            return None
    
    def check_key_rotation_needed(self, key_id: str, rotation_period_days: int = 30) -> bool:
        """
        Check if a key needs to be rotated.
        
        Args:
            key_id: ID of the key to check
            rotation_period_days: Days after which key should be rotated
            
        Returns:
            True if rotation is needed, False otherwise
        """
        key_data = self.retrieve_key(key_id)
        if not key_data:
            return False
        
        created_at = datetime.datetime.fromisoformat(key_data['created_at'])
        now = datetime.datetime.now()
        
        return (now - created_at).days >= rotation_period_days
    
    def delete_key(self, key_id: str) -> bool:
        """
        Delete a key from storage.
        
        Args:
            key_id: ID of the key to delete
            
        Returns:
            True if deletion was successful, False otherwise
        """
        key_path = self.storage_path / f"{key_id}.key"
        
        if not key_path.exists():
            return False
        
        try:
            key_path.unlink()
            logger.info(f"Deleted key: {key_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete key {key_id}: {e}")
            return False


class CryptoManager:
    """Main interface for cryptographic operations in the Pacata Mesh VPN."""
    
    def __init__(self, storage_path: str = ".keys", 
                 auto_rotate: bool = True, 
                 rotation_period_days: int = 30):
        """
        Initialize the crypto manager.
        
        Args:
            storage_path: Path to store keys
            auto_rotate: Whether to automatically rotate keys
            rotation_period_days: Days after which keys should be rotated
        """
        self.key_manager = KeyManager(storage_path)
        self.auto_rotate = auto_rotate
        self.rotation_period_days = rotation_period_days
        
        # Initialize default keys if they don't exist
        self._init_default_keys()
    
    def _init_default_keys(self):
        """Initialize default keys if they don't exist."""
        # Check for encryption key
        encryption_key = self.key_manager.get_active_key("encryption")
        if not encryption_key:
            self.key_manager.create_symmetric_key("encryption")
        
        # Check for MAC key
        mac_key = self.key_manager.get_active_key("mac")
        if not mac_key:
            self.key_manager.create_symmetric_key("mac")
        
        # Check for DH key pair
        dh_key = self.key_manager.get_active_key("dh")
        if not dh_key:
            self.key_manager.create_dh_key_pair("dh")
    
    def get_encryption_crypto(self) -> SymmetricCrypto:
        """
        Get a SymmetricCrypto instance for the active encryption key.
        
        Returns:
            SymmetricCrypto instance
        
        Raises:
            ValueError: If no valid encryption key is available
        """
        encryption_key = self.key_manager.get_active_key("encryption")
        
        # Auto-rotate if needed
        if (self.auto_rotate and encryption_key and 
            self.key_manager.check_key_rotation_needed(encryption_key[0], self.rotation_period_days)):
            new_key_data = self.key_manager.rotate_key(encryption_key[0], self.rotation_period_days)
            if new_key_data:
                # Find the new key ID
                for key_id in self.key_manager.list_keys():
                    if key_id.startswith("encryption") and key_id != encryption_key[0]:
                        key_data = self.key_manager.retrieve_key(key_id)
                        if key_data and key_data.get('active', True):
                            encryption_key = (key_id, key_data)
                            break
        
        if not encryption_key:
            encryption_key = self.key_manager.create_symmetric_key("encryption")
        
        symmetric_crypto = self.key_manager.get_symmetric_crypto(encryption_key[0])
        if not symmetric_crypto:
            raise ValueError("Failed to get valid encryption key")
        
        return symmetric_crypto
    
    def get_authenticator(self) -> MessageAuthenticator:
        """
        Get a MessageAuthenticator instance for the active MAC key.
        
        Returns:
            MessageAuthenticator instance
        
        Raises:
            ValueError: If no valid MAC key is available
        """
        mac_key = self.key_manager.get_active_key("mac")
        
        # Auto-rotate if needed
        if (self.auto_rotate and mac_key and 
            self.key_manager.check_key_rotation_needed(mac_key[0], self.rotation_period_days)):
            new_key_data = self.key_manager.rotate_key(mac_key[0], self.rotation_period_days)
            if new_key_data:
                # Find the new key ID
                for key_id in self.key_manager.list_keys():
                    if key_id.startswith("mac") and key_id != mac_key[0]:
                        key_data = self.key_manager.retrieve_key(key_id)
                        if key_data and key_data.get('active', True):
                            mac_key = (key_id, key_data)
                            break
        
        if not mac_key:
            mac_key = self.key_manager.create_symmetric_key("mac")
        
        authenticator = self.key_manager.get_message_authenticator(mac_key[0])
        if not authenticator:
            raise ValueError("Failed to get valid MAC key")
        
        return authenticator
    
    def get_dh_exchange(self) -> DiffieHellmanExchange:
        """
        Get a DiffieHellmanExchange instance for key exchange.
        
        Returns:
            DiffieHellmanExchange instance
        """
        # Always create a fresh DH exchange for new key exchanges
        return DiffieHellmanExchange()
    
    def encrypt_data(self, data: bytes) -> Dict[str, bytes]:
        """
        Encrypt data using the active encryption key.
        
        Args:
            data: Data to encrypt
            
        Returns:
            Dictionary containing ciphertext, iv, and tag
        """
        crypto = self.get_encryption_crypto()
        return crypto.encrypt(data)
    
    def decrypt_data(self, ciphertext: bytes, iv: bytes, tag: bytes) -> bytes:
        """
        Decrypt data using the active encryption key.
        
        Args:
            ciphertext: Encrypted data
            iv: Initialization vector used during encryption
            tag: Authentication tag
            
        Returns:
            Decrypted plaintext
        """
        crypto = self.get_encryption_crypto()
        return crypto.decrypt(ciphertext, iv, tag)
    
    def authenticate_message(self, message: bytes) -> bytes:
        """
        Generate a MAC for a message.
        
        Args:
            message: Message to authenticate
            
        Returns:
            HMAC digest
        """
        authenticator = self.get_authenticator()
        return authenticator.generate_mac(message)
    
    def verify_message(self, message: bytes, mac: bytes) -> bool:
        """
        Verify a MAC for a message.
        
        Args:
            message: Message that was authenticated
            mac: MAC to verify
            
        Returns:
            True if the MAC is valid, False otherwise
        """
        authenticator = self.get_authenticator()
        return authenticator.verify_mac(message, mac)
    
    def secure_packet(self, packet: bytes) -> Dict[str, bytes]:
        """
        Secure a packet for transmission with encryption and authentication.
        
        Args:
            packet: Original packet data
            
        Returns:
            Dictionary with encrypted packet and authentication data
        """
        # Encrypt the packet
        encrypted = self.encrypt_data(packet)
        
        # Create an authenticated packet format that includes:
        # - Encrypted data
        # - IV used for encryption
        # - MAC for authentication
        
        # Compute MAC over IV + ciphertext to ensure both are unmodified
        mac_data = encrypted['iv'] + encrypted['ciphertext'] + encrypted['tag']
        mac = self.authenticate_message(mac_data)
        
        return {
            'ciphertext': encrypted['ciphertext'],
            'iv': encrypted['iv'],
            'tag': encrypted['tag'],
            'mac': mac
        }
    
    def process_secure_packet(self, secure_packet: Dict[str, bytes]) -> Optional[bytes]:
        """
        Process a secure packet by verifying its authenticity and decrypting it.
        
        Args:
            secure_packet: Dictionary with encrypted packet and authentication data
            
        Returns:
            Decrypted packet data or None if verification fails
        """
        # Extract components
        ciphertext = secure_packet.get('ciphertext')
        iv = secure_packet.get('iv')
        tag = secure_packet.get('tag')
        mac = secure_packet.get('mac')
        
        if not all([ciphertext, iv, tag, mac]):
            logger.error("Incomplete secure packet received")
            return None
        
        # Verify MAC
        mac_data = iv + ciphertext + tag
        if not self.verify_message(mac_data, mac):
            logger.error("MAC verification failed - packet may be tampered with")
            return None
        
        # Decrypt the packet
        try:
            return self.decrypt_data(ciphertext, iv, tag)
        except Exception as e:
            logger.error(f"Failed to decrypt packet: {e}")
            return None
    
    def create_tls_manager(self, cert_path: Optional[str] = None, 
                         key_path: Optional[str] = None) -> TLSManager:
        """
        Create a TLSManager instance for secure connections.
        
        Args:
            cert_path: Path to certificate file
            key_path: Path to private key file
            
        Returns:
            Configured TLSManager instance
        """
        return TLSManager(cert_path, key_path)
    
    def setup_secure_identity(self, node_id: str, output_dir: str = None) -> Tuple[str, str]:
        """
        Set up a secure identity for a node, including a self-signed certificate.
        
        Args:
            node_id: Unique identifier for the node
            output_dir: Directory to save certificate and key files
            
        Returns:
            Tuple of paths (cert_path, key_path)
        """
        if not output_dir:
            output_dir = self.key_manager.storage_path
        
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True, parents=True)
        
        cert_path = str(output_dir / f"{node_id}.crt")
        key_path = str(output_dir / f"{node_id}.key")
        
        tls_manager = TLSManager()
        return tls_manager.create_self_signed_cert(
            common_name=node_id,
            output_cert=cert_path,
            output_key=key_path
        )
    
    def perform_key_exchange(self, peer_public_key: bytes) -> bytes:
        """
        Perform a Diffie-Hellman key exchange with a peer.
        
        Args:
            peer_public_key: Public key bytes from the peer
            
        Returns:
            Shared secret key
        """
        dh_exchange = self.get_dh_exchange()
        return dh_exchange.generate_shared_key(peer_public_key)
    
    def derive_session_keys(self, shared_secret: bytes) -> Dict[str, bytes]:
        """
        Derive session keys from a shared secret.
        
        Args:
            shared_secret: Shared secret from key exchange
            
        Returns:
            Dictionary containing encryption and MAC keys
        """
        # Use HKDF to derive multiple keys from the shared secret
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=80,  # We'll extract multiple keys
            salt=None,
            info=b'pacata_mesh_vpn_session_keys',
            backend=default_backend()
        )
        key_material = hkdf.derive(shared_secret)
        
        # Split the key material into different keys
        return {
            'encryption_key': key_material[0:32],
            'mac_key': key_material[32:64],
            'session_id': key_material[64:80]
        }
    
    def establish_secure_session(self, peer_public_key: bytes, session_id: str) -> str:
        """
        Establish a secure session with a peer.
        
        Args:
            peer_public_key: Public key bytes from the peer
            session_id: Unique identifier for the session
            
        Returns:
            ID of the created session key
        """
        # Perform DH key exchange
        shared_secret = self.perform_key_exchange(peer_public_key)
        
        # Derive session keys
        session_keys = self.derive_session_keys(shared_secret)
        
        # Store session keys securely
        key_data = {
            'type': 'session',
            'encryption_key': base64.b64encode(session_keys['encryption_key']).decode('utf-8'),
            'mac_key': base64.b64encode(session_keys['mac_key']).decode('utf-8'),
            'session_id': base64.b64encode(session_keys['session_id']).decode('utf-8'),
            'created_at': datetime.datetime.now().isoformat(),
            'active': True,
            'peer_id': session_id,
            'version': 1
        }
        
        key_id = f"session_{session_id}_v1"
        self.key_manager.store_key(key_id, key_data)
        
        logger.info(f"Established secure session with peer {session_id}")
        return key_id
