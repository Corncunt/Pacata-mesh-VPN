"""
Blockchain Module for Pacata Mesh VPN

This module implements a distributed ledger system powering the Pacata cryptocurrency,
which serves as the economic backbone of the Pacata Mesh VPN network.

The blockchain implementation provides incentives for node operators to maintain
the VPN infrastructure, creating a self-sustaining ecosystem where bandwidth
and routing services are compensated with Pacata tokens.

Key Components:
--------------

1. Core Blockchain (blockchain.py):
   - Implements a decentralized ledger using proof-of-work consensus
   - Manages blocks, chain validation, and transaction processing
   - Provides mining capabilities for node operators to earn Pacata tokens
   - Implements persistence to ensure blockchain data is stored securely

2. Wallet System (wallet.py):
   - PacataWallet class for managing user funds
   - Secure key generation and storage
   - Transaction creation and signing
   - Balance tracking and transaction history

3. Transaction Framework:
   - Secure, cryptographically signed transactions
   - Double-spending prevention
   - Transaction validation and verification

4. Incentive Mechanisms:
   - Mining rewards for block creation
   - Transaction fees for VPN service providers
   - Staking mechanisms for network security

5. Consensus Protocol:
   - Proof-of-work implementation for network consensus
   - Block validation rules
   - Chain selection for resolving forks

Integration with Pacata Mesh VPN:
--------------------------------
The blockchain module connects with other components of the VPN system:
- Authentication: Uses wallet addresses as node identifiers
- Bandwidth Accounting: Tracks bandwidth usage as blockchain transactions
- Route Discovery: Prioritizes routes through nodes with good reputation
- Payment System: Facilitates automatic micropayments for VPN services

This module is designed to be lightweight enough to run on various devices
while providing robust security and decentralization for the VPN ecosystem.
"""

# These imports make the module's components available at the package level
from .blockchain import Blockchain, Block, Transaction
from .wallet import PacataWallet

# Define what should be imported when using "from blockchain import *"
__all__ = ['Blockchain', 'Block', 'Transaction', 'PacataWallet']

