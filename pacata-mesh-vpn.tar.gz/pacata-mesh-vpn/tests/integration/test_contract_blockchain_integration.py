#!/usr/bin/env python3
"""
Integration test script demonstrating the use of smart contracts with the blockchain system.
This script shows the full lifecycle of smart contracts including:
- Creating different types of smart contracts
- Deploying contracts to the blockchain
- Executing contract methods and validating results
- Contract interactions
- Error handling and validation
"""

import sys
import os
import logging
import time
import uuid
import json
from datetime import datetime
from pacata_mesh_vpn.blockchain.blockchain import Blockchain, Transaction, Block
from pacata_mesh_vpn.blockchain.wallet import Wallet
from pacata_mesh_vpn.smart_contracts import (
    ContractRegistry, 
    ContractEngine,
    BandwidthSharingContract,
    NodeReputationContract,
    TokenPaymentContract,
    BANDWIDTH_SHARING_CONTRACT,
    NODE_REPUTATION_CONTRACT,
    TOKEN_PAYMENT_CONTRACT
)
from pacata_mesh_vpn.blockchain_network import BlockchainNetwork

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

def setup_test_environment():
    """Set up the test environment with blockchain and wallets."""
    logger.info("Setting up test environment...")
    
    # Create blockchain instance
    blockchain = Blockchain()
    
    # Create wallets for different roles
    node_operator_wallet = Wallet()
    user_wallet = Wallet()
    service_provider_wallet = Wallet()
    
    # Initialize blockchain network
    network = BlockchainNetwork(
        blockchain=blockchain,
        wallet=node_operator_wallet
    )
    
    # Initialize contract registry and engine
    registry = ContractRegistry()
    engine = ContractEngine()
    
    logger.info(f"Node operator wallet address: {node_operator_wallet.address}")
    logger.info(f"User wallet address: {user_wallet.address}")
    logger.info(f"Service provider wallet address: {service_provider_wallet.address}")
    
    return {
        'blockchain': blockchain,
        'network': network,
        'wallets': {
            'node_operator': node_operator_wallet,
            'user': user_wallet,
            'service_provider': service_provider_wallet
        },
        'registry': registry,
        'engine': engine
    }

def create_and_deploy_contracts(env):
    """Create and deploy various smart contracts to the blockchain."""
    logger.info("Creating and deploying smart contracts...")
    
    contracts = {}
    
    # Create a bandwidth sharing contract
    bandwidth_contract = BandwidthSharingContract(
        contract_id=str(uuid.uuid4()),
        owner_address=env['wallets']['node_operator'].address,
        node_address=env['wallets']['node_operator'].address,
        rate_per_gb=0.5,  # 0.5 tokens per GB
        minimum_bandwidth=100,  # 100 MB
        payment_address=env['wallets']['node_operator'].address
    )
    contracts['bandwidth'] = bandwidth_contract
    logger.info(f"Created bandwidth sharing contract: {bandwidth_contract.contract_id}")
    
    # Create a node reputation contract
    reputation_contract = NodeReputationContract(
        contract_id=str(uuid.uuid4()),
        owner_address=env['wallets']['service_provider'].address,
        node_address=env['wallets']['node_operator'].address,
        initial_score=50,  # Start with a neutral reputation
        min_uptime_percent=95.0
    )
    contracts['reputation'] = reputation_contract
    logger.info(f"Created node reputation contract: {reputation_contract.contract_id}")
    
    # Create a token payment contract
    payment_contract = TokenPaymentContract(
        contract_id=str(uuid.uuid4()),
        owner_address=env['wallets']['user'].address,
        sender_address=env['wallets']['user'].address,
        recipient_address=env['wallets']['node_operator'].address,
        amount=10.0,  # 10 tokens
        payment_for="VPN service for 1 month"
    )
    contracts['payment'] = payment_contract
    logger.info(f"Created token payment contract: {payment_contract.contract_id}")
    
    # Register all contracts with the registry
    for name, contract in contracts.items():
        env['registry'].register_contract(contract)
        logger.info(f"Registered {name} contract with ID {contract.contract_id}")
    
    # Deploy contracts to the blockchain by creating transactions
    for name, contract in contracts.items():
        # Serialize the contract
        contract_data = contract.serialize()
        
        # Get the appropriate wallet for signing the transaction
        wallet = env['wallets']['node_operator']
        if name == 'reputation':
            wallet = env['wallets']['service_provider']
        elif name == 'payment':
            wallet = env['wallets']['user']
        
        # Create a transaction with contract data
        tx = Transaction(
            sender=wallet.address,
            recipient="CONTRACT",
            amount=0.001,  # Small fee for contract deployment
            data={
                'type': 'contract_deploy',
                'contract_type': getattr(contract, 'contract_type'),
                'contract_id': contract.contract_id,
                'contract_data': contract_data
            }
        )
        # Sign the transaction
        wallet.sign_transaction(tx)
        
        # Add to the pending transactions
        env['blockchain'].add_transaction(tx)
        logger.info(f"Created transaction to deploy {name} contract: {tx.transaction_id}")
    
    # Mine a block to include all contract deployment transactions
    env['blockchain'].mine()
    latest_block = env['blockchain'].chain[-1]
    logger.info(f"Mined block {latest_block.index} with {len(latest_block.transactions)} transactions")
    
    return contracts

def execute_contract_operations(env, contracts):
    """Execute various operations on deployed contracts."""
    logger.info("Executing contract operations...")
    
    # Access the bandwidth contract
    bandwidth_contract = contracts['bandwidth']
    
    # Record bandwidth usage
    bandwidth_usage_data = {
        'timestamp': datetime.now().isoformat(),
        'bandwidth_used': 2.5,  # 2.5 GB
        'user_address': env['wallets']['user'].address
    }
    
    # Create a transaction to record bandwidth usage
    tx = Transaction(
        sender=env['wallets']['node_operator'].address,
        recipient="CONTRACT",
        amount=0,
        data={
            'type': 'contract_execute',
            'contract_id': bandwidth_contract.contract_id,
            'method': 'record_bandwidth_usage',
            'params': bandwidth_usage_data
        }
    )
    env['wallets']['node_operator'].sign_transaction(tx)
    env['blockchain'].add_transaction(tx)
    logger.info(f"Created transaction to record bandwidth usage: {tx.transaction_id}")
    
    # Execute the transaction using the contract engine
    result = env['engine'].execute_contract(
        contract=bandwidth_contract,
        method_name='record_bandwidth_usage',
        params=bandwidth_usage_data,
        blockchain=env['blockchain']
    )
    logger.info(f"Executed bandwidth usage recording: {result.success}")
    
    # Update reputation
    reputation_contract = contracts['reputation']
    reputation_update_data = {
        'timestamp': datetime.now().isoformat(),
        'uptime_percent': 99.5,
        'latency_ms': 25,
        'throughput_mbps': 95.0
    }
    
    # Create a transaction to update reputation
    tx = Transaction(
        sender=env['wallets']['service_provider'].address,
        recipient="CONTRACT",
        amount=0,
        data={
            'type': 'contract_execute',
            'contract_id': reputation_contract.contract_id,
            'method': 'update_reputation',
            'params': reputation_update_data
        }
    )
    env['wallets']['service_provider'].sign_transaction(tx)
    env['blockchain'].add_transaction(tx)
    logger.info(f"Created transaction to update node reputation: {tx.transaction_id}")
    
    # Execute the transaction using the contract engine
    result = env['engine'].execute_contract(
        contract=reputation_contract,
        method_name='update_reputation',
        params=reputation_update_data,
        blockchain=env['blockchain']
    )
    logger.info(f"Executed reputation update: {result.success}")
    
    # Process payment
    payment_contract = contracts['payment']
    
    # Create a transaction to process payment
    tx = Transaction(
        sender=env['wallets']['user'].address,
        recipient=env['wallets']['node_operator'].address,
        amount=payment_contract.amount,
        data={
            'type': 'contract_execute',
            'contract_id': payment_contract.contract_id,
            'method': 'process_payment',
            'params': {'confirmation_code': str(uuid.uuid4())}
        }
    )
    env['wallets']['user'].sign_transaction(tx)
    env['blockchain'].add_transaction(tx)
    logger.info(f"Created transaction to process payment: {tx.transaction_id}")
    
    # Execute the transaction using the contract engine
    result = env['engine'].execute_contract(
        contract=payment_contract,
        method_name='process_payment',
        params={'confirmation_code': str(uuid.uuid4())},
        blockchain=env['blockchain']
    )
    logger.info(f"Executed payment processing: {result.success}")
    
    # Mine a block to include all contract execution transactions
    env['blockchain'].mine()
    latest_block = env['blockchain'].chain[-1]
    logger.info(f"Mined block {latest_block.index} with {len(latest_block.transactions)} transactions")
    
    return latest_block

def query_contract_states(env, contracts):
    """Query and display the current state of all contracts."""
    logger.info("Querying contract states...")
    
    for name, contract in contracts.items():
        # Retrieve contract from registry
        retrieved_contract = env['registry'].get_contract(contract.contract_id)
        
        if retrieved_contract:
            logger.info(f"{name.capitalize()} Contract State:")
            logger.info(f"  Contract ID: {retrieved_contract.contract_id}")
            logger.info(f"  Owner: {retrieved_contract.owner_address}")
            logger.info(f"  State: {retrieved_contract.state.name}")
            
            # Contract-specific information
            if name == 'bandwidth':
                logger.info(f"  Rate per GB: {retrieved_contract.rate_per_gb}")
                logger.info(f"  Total bandwidth recorded: {retrieved_contract.total_bandwidth_used} GB")
            elif name == 'reputation':
                logger.info(f"  Node address: {retrieved_contract.node_address}")
                logger.info(f"  Current reputation score: {retrieved_contract.score}")
            elif name == 'payment':
                logger.info(f"  Amount: {retrieved_contract.amount} tokens")
                logger.info(f"  Status: {retrieved_contract.status}")
                logger.info(f"  Sender: {retrieved_contract.sender_address}")
                logger.info(f"  Recipient: {retrieved_contract.recipient_address}")
        else:
            logger.warning(f"Could not retrieve {name} contract from registry")

def demonstrate_error_handling(env, contracts):
    """Demonstrate error handling for contract operations."""
    logger.info("Demonstrating error handling...")
    
    # Attempt to execute a non-existent method
    payment_contract = contracts['payment']
    
    try:
        result = env['engine'].execute_contract(
            contract=payment_contract,
            method_name='non_existent_method',
            params={},
            blockchain=env['blockchain']
        )
        logger.info(f"Execution result: {result.success}")
    except Exception as e:
        logger.error(f"Error executing non-existent method: {str(e)}")
    
    # Attempt to update a contract with incorrect parameters
    reputation_contract = contracts['reputation']
    
    try:
        invalid_data = {
            'timestamp': datetime.now().isoformat(),
            'uptime_percent': 150.0,  # Invalid: over 100%
            'latency_ms': -10,  # Invalid: negative
            'throughput_mbps': 'not_a_number'  # Invalid: not a number
        }
        
        result = env['engine'].execute_contract(
            contract=reputation_contract,
            method_name='update_reputation',
            params=invalid_data,
            blockchain=env['blockchain']
        )
        logger.info(f"Execution result: {result.success}")
    except Exception as e:
        logger.error(f"Error updating reputation with invalid data: {str(e)}")

def verify_blockchain_integrity(env):
    """Verify the integrity of the blockchain after contract operations."""
    logger.info("Verifying blockchain integrity...")
    
    blockchain = env['blockchain']
    is_valid = blockchain.is_chain_valid()
    logger.info(f"Blockchain validity: {is_valid}")
    
    # Print blockchain stats
    num_blocks = len(blockchain.chain)
    total_transactions = sum(len(block.transactions) for block in blockchain.chain)
    logger.info(f"Blockchain stats: {num_blocks} blocks, {total_transactions} transactions")
    
    return is_valid

def main():
    """Main function to run the integration test."""
    logger.info("Starting smart contract blockchain integration test...")
    
    # Set up the test environment
    env = setup_test_environment()
    
    # Create and deploy contracts
    contracts = create_and_deploy_contracts(env)
    
    # Execute contract operations
    latest_block = execute_contract_operations(env, contracts)
    
    # Query contract states
    query_contract_states(env, contracts)
    
    # Demonstrate error handling
    demonstrate_error_handling(env, contracts)
    
    # Verify blockchain integrity
    blockchain_valid = verify_blockchain_integrity(env)
    
    # Print test summary
    logger.info("\n=== Smart Contract Integration Test Summary ===")
    logger.info(f"Contracts deployed: {len(contracts)}")
    logger.info(f"Blockchain blocks: {len(env['blockchain'].chain)}")
    logger.info(f"Latest block transactions: {len(latest_block.transactions)}")
    logger.info(f"Blockchain validity: {blockchain_valid}")
    logger.info("Test completed successfully!")

if __name__ == "__main__":
    main()

