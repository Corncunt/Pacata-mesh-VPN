# Pacata Mesh VPN Test Suite

This directory contains tests for the Pacata Mesh VPN system, ensuring all components work correctly both individually and together.

## Overview

The test suite is organized into different categories:

- **Integration Tests**: Tests that verify different components work together correctly
- **Unit Tests**: Tests for individual components and functions (to be added)
- **Performance Tests**: Tests to measure system performance under various conditions (to be added)

## Integration Tests

The `integration/` directory contains tests that verify different system components work together correctly. These tests are particularly important for complex interactions like the VPN-blockchain integration and smart contract operations.

### Current Integration Tests

- **Contract-Blockchain Integration Tests**: Verifies that smart contracts can be properly created, deployed, stored on the blockchain, and executed correctly.

## Running Tests

### Prerequisites

Before running the tests, ensure you have:

1. Python 3.8 or higher installed
2. All dependencies installed: `pip install -r requirements.txt`
3. The application installed in development mode: `pip install -e .`

### Running All Tests

To run all tests:

```bash
python -m pytest tests/
```

### Running Specific Test Categories

To run only integration tests:

```bash
python -m pytest tests/integration/
```

To run a specific test file:

```bash
python -m pytest tests/integration/test_contract_blockchain_integration.py
```

### Test Options

- Add `-v` for verbose output
- Add `-s` to see print statements
- Add `--cov=src/pacata_mesh_vpn` to generate a coverage report

## Writing New Tests

When adding new tests:

1. Place unit tests in a `unit/` directory organized by module
2. Place integration tests in the `integration/` directory
3. Follow the naming convention: `test_*.py` for test files
4. Use descriptive test function names prefixed with `test_`
5. Include docstrings explaining what each test is verifying

## Continuous Integration

These tests are automatically run in the CI pipeline whenever code is pushed to the repository. All tests must pass before code can be merged into the main branch.

